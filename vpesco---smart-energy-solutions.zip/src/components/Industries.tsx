import React from 'react';
import { Factory, Hospital, Building2, Database, Hotel, Landmark } from 'lucide-react';
import { motion } from 'motion/react';
import { EditableContent } from './EditableContent';

export default function IndustriesSection() {
  const industries = [
    { id: 'ind_1', name: 'Manufacturing', icon: Factory },
    { id: 'ind_2', name: 'Hospitals', icon: Hospital },
    { id: 'ind_3', name: 'Commercial Buildings', icon: Building2 },
    { id: 'ind_4', name: 'Data Centers', icon: Database },
    { id: 'ind_5', name: 'Hotels', icon: Hotel },
    { id: 'ind_6', name: 'Government Facilities', icon: Landmark },
  ];

  return (
    <section className="py-24 bg-slate-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="text-emerald-600 font-bold uppercase tracking-widest text-sm mb-4">
            <EditableContent id="industries_tag" defaultValue="Industries Served" />
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
            <EditableContent id="industries_title" defaultValue="Tailored Solutions for Every Sector" />
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            <EditableContent id="industries_description" defaultValue="We provide specialized energy efficiency solutions across a wide range of industries and commercial sectors." multiline />
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
          {industries.map((industry, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-xl hover:border-emerald-200 transition-all text-center group"
            >
              <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-6 transition-transform group-hover:scale-110 group-hover:bg-emerald-600 group-hover:text-white">
                <industry.icon className="w-8 h-8" />
              </div>
              <h3 className="text-sm font-bold text-slate-900 leading-tight">
                <EditableContent id={`${industry.id}_name`} defaultValue={industry.name} />
              </h3>
            </motion.div>
          ))}
        </div>

        <div className="mt-20 relative rounded-3xl overflow-hidden aspect-[21/9] shadow-2xl">
          <img 
            src="https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&q=80&w=2000" 
            alt="Modern industrial skyline" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900/80 to-transparent flex items-center px-12">
            <div className="max-w-md">
              <h3 className="text-3xl font-bold text-white mb-4">
                <EditableContent id="industries_cta_title" defaultValue="Ready to optimize your facility?" />
              </h3>
              <p className="text-white/80 mb-8">
                <EditableContent id="industries_cta_description" defaultValue="Join hundreds of businesses that have reduced their energy costs with VPESCO." multiline />
              </p>
              <button className="bg-emerald-600 text-white px-8 py-3 rounded-full font-bold hover:bg-emerald-700 transition-all">
                <EditableContent id="industries_cta_button" defaultValue="Contact Our Experts" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
