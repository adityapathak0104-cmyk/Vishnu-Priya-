import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Zap, TrendingUp, Clock, Leaf, ArrowRight, Calculator, Gauge, BarChart3 } from 'lucide-react';
import { EditableContent } from './EditableContent';

export default function SavingsEstimator() {
  const [bill, setBill] = useState(500000);
  const [usage, setUsage] = useState(75000);
  const [sector, setSector] = useState('Industrial');

  const savingsRate = sector === 'Industrial' ? 0.25 : sector === 'Commercial' ? 0.18 : 0.12;
  const annualSavings = bill * 12 * savingsRate;
  const roiMonths = sector === 'Industrial' ? 14 : sector === 'Commercial' ? 20 : 30;
  const co2Offset = (usage * 12 * 0.85) / 1000; // Simplified calculation

  return (
    <section className="py-32 bg-slate-950 relative overflow-hidden">
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-0 w-full h-full" style={{ backgroundImage: 'radial-gradient(circle, #10b981 1px, transparent 1px)', backgroundSize: '60px 60px' }} />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-20">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 mb-6">
            <Calculator className="w-4 h-4 text-emerald-400" />
            <span className="text-xs font-bold tracking-[0.2em] text-emerald-400 uppercase">
              <EditableContent id="se_tag" defaultValue="ROI Projection Tool" />
            </span>
          </div>
          <h2 className="text-4xl lg:text-6xl font-bold text-white mb-6 tracking-tight">
            <EditableContent id="se_title" defaultValue="Industrial Energy Savings Calculator" multiline />
          </h2>
          <p className="text-slate-400 text-lg max-w-2xl mx-auto">
            <EditableContent id="se_description" defaultValue="Estimate your potential annual savings and carbon reduction through VPESCO's engineering optimization strategies." multiline />
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-12 items-start">
          {/* Inputs */}
          <div className="lg:col-span-7 bg-slate-900/50 backdrop-blur-xl rounded-[2.5rem] p-10 md:p-16 border border-white/5 shadow-2xl">
            <div className="space-y-12">
              {/* Bill Slider */}
              <div className="space-y-6">
                <div className="flex justify-between items-end">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                    <EditableContent id="se_bill_label" defaultValue="Monthly Electricity Bill (₹)" />
                  </label>
                  <span className="text-3xl font-mono font-bold text-emerald-400">₹{bill.toLocaleString()}</span>
                </div>
                <input 
                  type="range" 
                  min="50000" 
                  max="5000000" 
                  step="50000"
                  value={bill}
                  onChange={(e) => setBill(parseInt(e.target.value))}
                  className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                />
                <div className="flex justify-between text-[10px] font-bold text-slate-600 uppercase tracking-widest">
                  <span>
                    <EditableContent id="se_bill_min" defaultValue="₹50k" />
                  </span>
                  <span>
                    <EditableContent id="se_bill_max" defaultValue="₹50L" />
                  </span>
                </div>
              </div>

              {/* Usage Input */}
              <div className="space-y-4">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <EditableContent id="se_usage_label" defaultValue="Monthly Energy Consumption (kWh)" />
                </label>
                <div className="relative">
                  <input 
                    type="number"
                    value={usage}
                    onChange={(e) => setUsage(parseInt(e.target.value) || 0)}
                    className="w-full bg-slate-800/50 border border-white/10 rounded-2xl px-6 py-5 text-2xl font-mono font-bold text-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
                  />
                  <div className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-500 font-bold">
                    <EditableContent id="se_usage_unit" defaultValue="kWh" />
                  </div>
                </div>
              </div>

              {/* Sector Selection */}
              <div className="space-y-4">
                <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <EditableContent id="se_sector_label" defaultValue="Operation Sector" />
                </label>
                <div className="grid grid-cols-3 gap-4">
                  {['Textile', 'Commercial', 'Industrial'].map((s) => (
                    <button
                      key={s}
                      onClick={() => setSector(s)}
                      className={`py-4 rounded-xl font-bold text-sm transition-all border ${
                        sector === s 
                          ? 'bg-emerald-600 border-emerald-500 text-white shadow-[0_0_20px_rgba(16,185,129,0.2)]' 
                          : 'bg-slate-800/50 border-white/5 text-slate-500 hover:bg-slate-800'
                      }`}
                    >
                      <EditableContent id={`se_sector_btn_${s.toLowerCase()}`} defaultValue={s} />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Results */}
          <div className="lg:col-span-5 space-y-6">
            {/* Main Savings Card */}
            <motion.div 
              key={annualSavings}
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="bg-emerald-600 rounded-[2.5rem] p-12 text-white relative overflow-hidden shadow-[0_20px_50px_rgba(16,185,129,0.2)]"
            >
              <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
              <TrendingUp className="w-10 h-10 text-white mb-8 relative z-10" />
              <div className="text-xs font-bold text-emerald-100/60 uppercase tracking-[0.2em] mb-4 relative z-10">
                <EditableContent id="se_savings_label" defaultValue="Projected Annual Savings" />
              </div>
              <div className="text-5xl lg:text-6xl font-bold mb-6 relative z-10 tracking-tight">
                ₹{Math.round(annualSavings).toLocaleString()}
              </div>
              <p className="text-emerald-100/80 text-sm font-medium relative z-10 leading-relaxed">
                <EditableContent id="se_savings_desc_prefix" defaultValue="Estimated based on" /> {Math.round(savingsRate * 100)}% <EditableContent id="se_savings_desc_suffix" defaultValue="efficiency improvement through system optimization." />
              </p>
            </motion.div>

            <div className="grid grid-cols-2 gap-6">
              {/* ROI Card */}
              <div className="bg-slate-900/50 backdrop-blur-xl rounded-[2rem] p-8 border border-white/5">
                <Clock className="w-6 h-6 text-emerald-500 mb-6" />
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">
                  <EditableContent id="se_payback_label" defaultValue="Est. Payback" />
                </div>
                <div className="text-3xl font-bold text-white">
                  {roiMonths} <span className="text-sm font-medium text-slate-500">
                    <EditableContent id="se_payback_unit" defaultValue="Months" />
                  </span>
                </div>
              </div>

              {/* CO2 Card */}
              <div className="bg-slate-900/50 backdrop-blur-xl rounded-[2rem] p-8 border border-white/5">
                <Leaf className="w-6 h-6 text-emerald-500 mb-6" />
                <div className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">
                  <EditableContent id="se_co2_label" defaultValue="Carbon Offset" />
                </div>
                <div className="text-3xl font-bold text-white">
                  {co2Offset.toFixed(1)} <span className="text-sm font-medium text-slate-500">
                    <EditableContent id="se_co2_unit" defaultValue="Tons" />
                  </span>
                </div>
              </div>
            </div>

            {/* CTA Button */}
            <button className="w-full bg-white text-slate-950 py-6 rounded-2xl font-bold text-lg flex items-center justify-center gap-3 hover:bg-emerald-50 transition-all group shadow-xl">
              <EditableContent id="se_cta_btn" defaultValue="Get Detailed Audit Report" />
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>
            
            <p className="text-center text-xs text-slate-500">
              <EditableContent id="se_disclaimer" defaultValue="*Preliminary estimates. Actual savings depend on detailed site audit." />
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
