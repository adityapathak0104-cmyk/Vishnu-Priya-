import React from 'react';
import { 
  Activity, 
  Zap, 
  TrendingUp, 
  Camera, 
  Cpu, 
  Leaf, 
  ArrowRight,
  BarChart3,
  LineChart as LineChartIcon,
  ShieldCheck,
  LayoutDashboard,
  Database,
  Globe,
  Gauge
} from 'lucide-react';
import { motion } from 'motion/react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar
} from 'recharts';
import { EditableContent } from './EditableContent';

const powerUsageData = [
  { time: '00:00', usage: 450 },
  { time: '04:00', usage: 420 },
  { time: '08:00', usage: 850 },
  { time: '12:00', usage: 980 },
  { time: '16:00', usage: 890 },
  { time: '20:00', usage: 600 },
  { time: '23:59', usage: 480 },
];

const demandTrendData = [
  { day: 'Mon', demand: 820, target: 800 },
  { day: 'Tue', demand: 850, target: 800 },
  { day: 'Wed', demand: 780, target: 800 },
  { day: 'Thu', demand: 910, target: 800 },
  { day: 'Fri', demand: 840, target: 800 },
  { day: 'Sat', demand: 450, target: 500 },
  { day: 'Sun', demand: 400, target: 500 },
];

const dashboardCards = [
  {
    id: 'ei_card_1',
    title: 'Energy Consumption Monitoring',
    description: 'Real-time electricity usage analysis across plant operations.',
    icon: Activity,
    color: 'emerald'
  },
  {
    id: 'ei_card_2',
    title: 'Power Quality Analytics',
    description: 'Voltage, current, harmonic distortion, and power factor monitoring.',
    icon: Zap,
    color: 'blue'
  },
  {
    id: 'ei_card_3',
    title: 'Demand Optimization',
    description: 'Peak demand forecasting and load pattern analysis.',
    icon: TrendingUp,
    color: 'purple'
  },
  {
    id: 'ei_card_4',
    title: 'Thermal Loss Detection',
    description: 'AI-assisted thermographic analysis of electrical panels and equipment.',
    icon: Camera,
    color: 'orange'
  },
  {
    id: 'ei_card_5',
    title: 'Equipment Efficiency Monitoring',
    description: 'Performance tracking of HVAC systems, pumps, motors, and compressors.',
    icon: Cpu,
    color: 'cyan'
  },
  {
    id: 'ei_card_6',
    title: 'Renewable Energy Integration',
    description: 'Solar generation monitoring and grid interaction analytics.',
    icon: Leaf,
    color: 'green'
  }
];

const benefits = [
  { id: 'ei_benefit_1', title: 'Operational Cost Reduction', icon: ShieldCheck },
  { id: 'ei_benefit_2', title: 'Predictive Maintenance', icon: Database },
  { id: 'ei_benefit_3', title: 'Energy Efficiency Optimization', icon: Gauge },
  { id: 'ei_benefit_4', title: 'Regulatory Compliance', icon: Globe }
];

export default function EnergyIntelligence() {
  return (
    <section className="bg-[#0a0f1e] text-white py-24 lg:py-32 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 z-0">
        <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_30%_30%,#1e293b_0%,transparent_50%)] opacity-40" />
        <div className="absolute bottom-0 right-0 w-full h-full bg-[radial-gradient(circle_at_70%_70%,#064e3b_0%,transparent_50%)] opacity-20" />
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:40px_40px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-4xl mx-auto mb-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-500/10 text-emerald-400 text-xs font-black uppercase tracking-[0.2em] mb-8 border border-emerald-500/20"
          >
            <LayoutDashboard className="w-4 h-4" />
            <EditableContent id="ei_tag" defaultValue="Next-Gen Analytics" />
          </motion.div>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.1 }}
            className="text-5xl lg:text-7xl font-bold mb-8 tracking-tight"
          >
            <EditableContent id="ei_title" defaultValue="Energy Intelligence Platform" />
          </motion.h2>
          <motion.h3
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-xl lg:text-2xl text-slate-300 font-light mb-8 italic"
          >
            <EditableContent id="ei_subtitle" defaultValue="Transforming Industrial Energy Data into Strategic Business Decisions." />
          </motion.h3>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.3 }}
            className="text-lg text-slate-400 leading-relaxed"
          >
            <EditableContent 
              id="ei_description" 
              defaultValue="VPESCO combines advanced measurement systems, IoT-enabled monitoring, and engineering analytics to provide real-time insights into industrial energy consumption, system performance, and cost optimization opportunities." 
              multiline
            />
          </motion.p>
        </div>

        {/* Dashboard Cards Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-32">
          {dashboardCards.map((card, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1 }}
              className="group p-8 rounded-[2.5rem] bg-white/5 border border-white/10 hover:bg-white/10 hover:border-emerald-500/30 transition-all duration-500 relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
              <div className={`w-14 h-14 rounded-2xl bg-emerald-500/10 flex items-center justify-center mb-8 group-hover:scale-110 transition-transform duration-500`}>
                <card.icon className="w-7 h-7 text-emerald-400" />
              </div>
              <h4 className="text-xl font-bold mb-4 tracking-tight group-hover:text-emerald-400 transition-colors">
                <EditableContent id={`${card.id}_title`} defaultValue={card.title} />
              </h4>
              <p className="text-slate-400 text-sm leading-relaxed">
                <EditableContent id={`${card.id}_desc`} defaultValue={card.description} multiline />
              </p>
              
              {/* Decorative Glow */}
              <div className="absolute -bottom-12 -right-12 w-24 h-24 bg-emerald-500/10 rounded-full blur-2xl group-hover:bg-emerald-500/20 transition-all" />
            </motion.div>
          ))}
        </div>

        {/* Feature Highlight: Dashboard Visual */}
        <div className="mb-32">
          <div className="text-center mb-16">
            <h3 className="text-3xl lg:text-4xl font-bold mb-4">
              <EditableContent id="ei_visual_title" defaultValue="Real-Time Industrial Energy Analytics" />
            </h3>
            <p className="text-slate-400">
              <EditableContent id="ei_visual_subtitle" defaultValue="Live monitoring and predictive insights for operational excellence." />
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8">
            {/* Main Chart Card */}
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="lg:col-span-2 p-8 rounded-[3rem] bg-slate-900/50 border border-white/10 backdrop-blur-xl"
            >
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h4 className="text-xl font-bold flex items-center gap-2">
                    <Activity className="w-5 h-5 text-emerald-500" />
                    <EditableContent id="ei_chart_title" defaultValue="Live Power Usage (kW)" />
                  </h4>
                  <p className="text-xs text-slate-500 mt-1 uppercase tracking-widest">
                    <EditableContent id="ei_chart_subtitle" defaultValue="Real-time telemetry from main busbar" />
                  </p>
                </div>
                <div className="flex gap-4">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-emerald-500" />
                    <span className="text-xs font-bold text-slate-400">
                      <EditableContent id="ei_chart_status" defaultValue="Active" />
                    </span>
                  </div>
                </div>
              </div>

              <div className="h-[300px] w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={powerUsageData}>
                    <defs>
                      <linearGradient id="colorUsage" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                    <XAxis 
                      dataKey="time" 
                      stroke="#64748b" 
                      fontSize={10} 
                      tickLine={false} 
                      axisLine={false} 
                    />
                    <YAxis 
                      stroke="#64748b" 
                      fontSize={10} 
                      tickLine={false} 
                      axisLine={false} 
                      tickFormatter={(value) => `${value}kW`}
                    />
                    <Tooltip 
                      contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #ffffff20', borderRadius: '12px' }}
                      itemStyle={{ color: '#10b981' }}
                    />
                    <Area 
                      type="monotone" 
                      dataKey="usage" 
                      stroke="#10b981" 
                      strokeWidth={3}
                      fillOpacity={1} 
                      fill="url(#colorUsage)" 
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </motion.div>

            {/* Side Stats */}
            <div className="space-y-8">
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                className="p-8 rounded-[2.5rem] bg-emerald-600 text-white shadow-2xl shadow-emerald-900/20"
              >
                <div className="flex items-center justify-between mb-6">
                  <TrendingUp className="w-8 h-8 opacity-50" />
                  <div className="px-3 py-1 rounded-full bg-white/20 text-[10px] font-black uppercase tracking-widest">
                    <EditableContent id="ei_stat1_tag" defaultValue="Live" />
                  </div>
                </div>
                <div className="text-4xl font-bold mb-2">
                  <EditableContent id="ei_stat1_value" defaultValue="18.4%" />
                </div>
                <div className="text-sm font-bold uppercase tracking-widest opacity-80">
                  <EditableContent id="ei_stat1_label" defaultValue="Energy Savings Indicator" />
                </div>
                <div className="mt-6 pt-6 border-t border-white/10 text-xs opacity-70">
                  <EditableContent id="ei_stat1_note" defaultValue="Projected monthly savings: $12,450" />
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 }}
                className="p-8 rounded-[2.5rem] bg-slate-900/50 border border-white/10 backdrop-blur-xl"
              >
                <div className="flex items-center justify-between mb-6">
                  <Leaf className="w-8 h-8 text-emerald-500 opacity-50" />
                  <div className="text-[10px] font-black uppercase tracking-widest text-emerald-400">
                    <EditableContent id="ei_stat2_tag" defaultValue="Environment" />
                  </div>
                </div>
                <div className="text-4xl font-bold mb-2">
                  <EditableContent id="ei_stat2_value" defaultValue="42.5" /> <span className="text-lg font-light">Tons</span>
                </div>
                <div className="text-sm font-bold uppercase tracking-widest text-slate-400">
                  <EditableContent id="ei_stat2_label" defaultValue="Carbon Reduction Tracker" />
                </div>
                <div className="mt-6 pt-6 border-t border-white/10 text-xs text-slate-500">
                  <EditableContent id="ei_stat2_note" defaultValue="Equivalent to 1,240 trees planted" />
                </div>
              </motion.div>
            </div>
          </div>

          {/* Secondary Chart: Demand Trend */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="mt-8 p-8 rounded-[3rem] bg-slate-900/50 border border-white/10 backdrop-blur-xl"
          >
            <div className="flex items-center justify-between mb-8">
              <div>
                <h4 className="text-xl font-bold flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-blue-400" />
                  <EditableContent id="ei_chart2_title" defaultValue="Demand Trend vs Target" />
                </h4>
                <p className="text-xs text-slate-500 mt-1 uppercase tracking-widest">
                  <EditableContent id="ei_chart2_subtitle" defaultValue="Weekly peak demand analysis" />
                </p>
              </div>
            </div>

            <div className="h-[250px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={demandTrendData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#ffffff10" vertical={false} />
                  <XAxis 
                    dataKey="day" 
                    stroke="#64748b" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false} 
                  />
                  <YAxis 
                    stroke="#64748b" 
                    fontSize={10} 
                    tickLine={false} 
                    axisLine={false} 
                  />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#0f172a', border: '1px solid #ffffff20', borderRadius: '12px' }}
                  />
                  <Bar dataKey="demand" fill="#3b82f6" radius={[4, 4, 0, 0]} barSize={30} />
                  <Bar dataKey="target" fill="#ffffff10" radius={[4, 4, 0, 0]} barSize={30} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </motion.div>
        </div>

        {/* Benefits Section */}
        <div className="mb-32">
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {benefits.map((benefit, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: idx * 0.1 }}
                className="p-8 rounded-3xl bg-white/5 border border-white/10 flex flex-col items-center text-center group hover:bg-emerald-500/5 transition-all"
              >
                <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                  <benefit.icon className="w-6 h-6 text-emerald-400" />
                </div>
                <h4 className="font-bold text-slate-200 group-hover:text-white transition-colors">
                  <EditableContent id={`${benefit.id}_title`} defaultValue={benefit.title} />
                </h4>
              </motion.div>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative p-12 lg:p-24 rounded-[4rem] bg-gradient-to-br from-slate-900 to-[#0a0f1e] border border-white/10 text-center overflow-hidden"
        >
          <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2" />
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-500/5 rounded-full blur-[100px] translate-y-1/2 -translate-x-1/2" />
          
          <div className="relative z-10">
            <h2 className="text-4xl lg:text-6xl font-bold mb-8 tracking-tight">
              <EditableContent id="ei_cta_title" defaultValue="Start Your Smart Energy Transformation with VPESCO." multiline />
            </h2>
            <p className="text-xl text-slate-400 mb-12 max-w-2xl mx-auto font-light leading-relaxed">
              <EditableContent 
                id="ei_cta_description" 
                defaultValue="Our Phase 2: Detailed Energy Audit integrates seamlessly with this platform, providing the engineering depth needed to execute on the insights discovered." 
                multiline
              />
            </p>
            <button className="group bg-emerald-600 text-white px-12 py-5 rounded-full font-bold text-xl hover:bg-emerald-500 transition-all shadow-2xl shadow-emerald-900/40 flex items-center gap-3 mx-auto">
              <EditableContent id="ei_cta_button" defaultValue="Request Energy Intelligence Demo" />
              <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform" />
            </button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
