import React from 'react';
import { CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';
import { EditableContent } from './EditableContent';

export default function AboutSection() {
  const benefits = [
    { id: 'benefit_1', default: 'BEE Certified Energy Auditors' },
    { id: 'benefit_2', default: 'ISO 50001 Implementation Experts' },
    { id: 'benefit_3', default: 'Advanced IoT Monitoring Systems' },
    { id: 'benefit_4', default: 'Measurable ROI & Carbon Offsets' },
    { id: 'benefit_5', default: 'Global Industrial Compliance' },
    { id: 'benefit_6', default: 'Renewable Energy Integration' },
  ];

  return (
    <section className="py-32 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-24 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="text-[#15803d] font-black uppercase tracking-[0.3em] text-xs mb-8">
              <EditableContent id="about_tag" defaultValue="Corporate Profile" />
            </div>
            <h2 className="text-5xl lg:text-7xl font-serif text-slate-900 mb-10 leading-[1.1] tracking-tight">
              <EditableContent id="about_title" defaultValue="Pioneering Industrial Efficiency Standards" multiline />
            </h2>
            <div className="space-y-6 text-lg text-slate-600 leading-relaxed font-light">
              <EditableContent 
                as="p" 
                id="about_p1" 
                defaultValue="Vishnu Priya Energy Solutions Company (VPESCO) stands at the forefront of global energy management, providing high-precision engineering solutions for complex industrial ecosystems. We are dedicated to optimizing energy consumption and reducing operational costs for a diverse range of sectors." 
                multiline 
              />
              <EditableContent 
                as="p" 
                id="about_p2" 
                defaultValue="With a legacy of technical excellence, we specialize in identifying hidden energy leakages and transforming them into measurable financial growth. Our approach integrates deep engineering audits with state-of-the-art IoT monitoring technologies, providing real-time data and actionable insights." 
                multiline 
              />
              <EditableContent 
                as="p" 
                id="about_p3" 
                defaultValue="Our team of BEE Certified Energy Auditors and ISO 50001 experts work closely with clients to develop customized energy management strategies that align with their operational goals and sustainability targets. From forensic bill audits to large-scale renewable energy integration, we provide end-to-end support." 
                multiline 
              />
              <div className="font-serif italic text-slate-900 border-l-4 border-emerald-100 pl-6 py-2">
                <EditableContent 
                  id="about_quote" 
                  defaultValue='"Our vision is to bridge the gap between industrial productivity and environmental stewardship, ensuring a carbon-neutral future for the next generation of global manufacturing through innovation and engineering excellence."' 
                  multiline 
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4 mt-12">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-center gap-4 group cursor-default">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 group-hover:scale-150 transition-transform" />
                  <span className="font-bold text-slate-900 text-sm tracking-tight">
                    <EditableContent id={benefit.id} defaultValue={benefit.default} />
                  </span>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl">
              <img 
                src="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=1000" 
                alt="Industrial facility engineering" 
                className="w-full h-full object-cover aspect-[4/3]"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-emerald-600/10" />
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -bottom-8 -right-8 w-48 h-48 bg-emerald-600/5 rounded-full blur-2xl" />
            <div className="absolute -top-8 -left-8 w-32 h-32 bg-blue-600/5 rounded-full blur-xl" />
          </motion.div>
        </div>
      </div>
    </section>
  );
}
