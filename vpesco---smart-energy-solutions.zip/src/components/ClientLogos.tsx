import React from 'react';
import { motion } from 'motion/react';
import { EditableContent } from './EditableContent';

const logos = [
  { name: 'Tata Steel', url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/b/b8/Tata_logo.svg/1200px-Tata_logo.svg.png' },
  { name: 'Reliance', url: 'https://upload.wikimedia.org/wikipedia/en/thumb/9/99/Reliance_Industries_Logo.svg/1200px-Reliance_Industries_Logo.svg.png' },
  { name: 'Adani', url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Adani_Group_logo.svg/1200px-Adani_Group_logo.svg.png' },
  { name: 'JSW', url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3b/JSW_Group_logo.svg/1200px-JSW_Group_logo.svg.png' },
  { name: 'L&T', url: 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e5/Larsen_%26_Toubro_logo.svg/1200px-Larsen_%26_Toubro_logo.svg.png' },
  { name: 'BHEL', url: 'https://upload.wikimedia.org/wikipedia/en/thumb/f/f2/BHEL_logo.svg/1200px-BHEL_logo.svg.png' },
];

export default function ClientLogos() {
  return (
    <div className="py-12 bg-white border-b border-slate-100 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-center text-xs font-bold text-slate-400 uppercase tracking-[0.3em] mb-10">
          <EditableContent id="client_logos_title" defaultValue="Trusted by Industrial Leaders Worldwide" />
        </p>
        
        <div className="flex flex-wrap justify-center items-center gap-12 md:gap-20 opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
          {logos.map((logo, i) => (
            <motion.img
              key={i}
              src={logo.url}
              alt={logo.name}
              className="h-8 md:h-10 object-contain"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              referrerPolicy="no-referrer"
            />
          ))}
        </div>
      </div>
    </div>
  );
}
