import React, { useState } from 'react';
import { 
  Zap, 
  BarChart3, 
  Flame, 
  Snowflake, 
  Settings, 
  Activity, 
  Camera, 
  Database, 
  Waves, 
  Cpu, 
  CheckCircle2, 
  ArrowRight,
  TrendingDown,
  ShieldCheck,
  Target,
  FileCheck,
  Droplets,
  Wind,
  Leaf,
  X,
  LineChart,
  PieChart,
  Activity as ActivityIcon,
  Search,
  ClipboardCheck,
  Lightbulb
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { EditableContent } from './EditableContent';

interface ModuleDetailProps {
  module: any;
  onClose: () => void;
}

function ModuleDetail({ module, onClose }: ModuleDetailProps) {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-8 bg-slate-900/95 backdrop-blur-xl overflow-y-auto"
    >
      <motion.div 
        initial={{ scale: 0.9, opacity: 0, y: 20 }}
        animate={{ scale: 1, opacity: 1, y: 0 }}
        exit={{ scale: 0.9, opacity: 0, y: 20 }}
        className="bg-white w-full max-w-6xl rounded-[2.5rem] overflow-hidden shadow-2xl relative"
      >
        <button 
          onClick={onClose}
          className="absolute top-8 right-8 z-10 p-2 bg-slate-100 rounded-full hover:bg-emerald-500 hover:text-white transition-all"
        >
          <X className="w-6 h-6" />
        </button>

        <div className="grid lg:grid-cols-2">
          {/* Left Side: Content */}
          <div className="p-8 md:p-16 overflow-y-auto max-h-[90vh]">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-16 h-16 rounded-2xl bg-emerald-50 flex items-center justify-center">
                <module.icon className="w-8 h-8 text-emerald-600" />
              </div>
              <div>
                <div className="text-emerald-600 font-black uppercase tracking-[0.2em] text-[10px] mb-1">
                  <EditableContent id={`module_tag_${module.id}`} defaultValue="Engineering Module" />
                </div>
                <h2 className="text-3xl font-bold text-slate-900 tracking-tight">
                  <EditableContent id={`module_title_${module.id}`} defaultValue={module.detailTitle || module.title} />
                </h2>
              </div>
            </div>

            <div className="prose prose-slate max-w-none">
              <div className="text-lg text-slate-600 leading-relaxed mb-10">
                <EditableContent id={`module_desc_${module.id}`} defaultValue={module.description} multiline />
              </div>

              {/* Engineering Analysis Methodology */}
              <div className="mb-10">
                <h3 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-1.5 h-6 bg-emerald-500 rounded-full" />
                  <EditableContent id={`module_meth_title_${module.id}`} defaultValue="Engineering Analysis Methodology" />
                </h3>
                <div className="grid sm:grid-cols-2 gap-4">
                  {module.methodology.map((item: string, i: number) => (
                    <div key={i} className="flex items-center gap-3 p-4 rounded-xl bg-slate-50 border border-slate-100">
                      <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span className="text-sm font-medium text-slate-700">
                        <EditableContent id={`module_meth_${module.id}_${i}`} defaultValue={item} />
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Parameters Checked */}
              <div className="mb-10">
                <h3 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-1.5 h-6 bg-emerald-500 rounded-full" />
                  <EditableContent id={`module_param_title_${module.id}`} defaultValue="Parameters Checked" />
                </h3>
                <div className="grid sm:grid-cols-2 gap-4">
                  {module.parameters.map((item: string, i: number) => (
                    <div key={i} className="flex items-center gap-3 p-4 rounded-xl bg-slate-50 border border-slate-100">
                      <ActivityIcon className="w-4 h-4 text-emerald-500 shrink-0" />
                      <span className="text-sm font-medium text-slate-700">
                        <EditableContent id={`module_param_${module.id}_${i}`} defaultValue={item} />
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Savings Opportunities */}
              <div className="mb-10">
                <h3 className="text-xl font-bold text-slate-900 mb-6 flex items-center gap-3">
                  <div className="w-1.5 h-6 bg-emerald-500 rounded-full" />
                  <EditableContent id={`module_savings_title_${module.id}`} defaultValue="Savings Opportunities" />
                </h3>
                <div className="grid sm:grid-cols-2 gap-4">
                  {module.savings.map((item: string, i: number) => (
                    <div key={i} className="flex items-center gap-3 p-4 rounded-xl bg-emerald-50 border border-emerald-100">
                      <TrendingDown className="w-4 h-4 text-emerald-600 shrink-0" />
                      <span className="text-sm font-medium text-emerald-900">
                        <EditableContent id={`module_savings_${module.id}_${i}`} defaultValue={item} />
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="p-8 rounded-[2rem] bg-slate-900 text-white mb-10">
                <h3 className="text-xl font-bold mb-6 flex items-center gap-3">
                  <FileCheck className="w-6 h-6 text-emerald-400" />
                  <EditableContent id={`module_deliv_title_${module.id}`} defaultValue="Deliverables" />
                </h3>
                <div className="space-y-4">
                  {module.deliverables.map((item: string, i: number) => (
                    <div key={i} className="flex items-center gap-4 text-slate-300 text-sm">
                      <div className="w-1 h-1 rounded-full bg-emerald-500 shrink-0" />
                      <EditableContent id={`module_deliv_${module.id}_${i}`} defaultValue={item} />
                    </div>
                  ))}
                </div>
              </div>

              <button className="w-full py-6 rounded-2xl bg-emerald-600 text-white font-bold text-xl hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-900/20 flex items-center justify-center gap-3">
                <EditableContent id={`module_cta_${module.id}`} defaultValue="Request Detailed Audit" />
                <ArrowRight className="w-6 h-6" />
              </button>
            </div>
          </div>

          {/* Right Side: Visuals */}
          <div className="hidden lg:block bg-slate-50 p-16 relative overflow-hidden">
            <div className="absolute inset-0 opacity-10 pointer-events-none">
              <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(#0f172a_1px,transparent_1px)] [background-size:30px_30px]" />
            </div>
            
            <div className="relative z-10 h-full flex flex-col gap-8">
              <div className="rounded-3xl overflow-hidden shadow-2xl border-4 border-white aspect-video">
                <img 
                  src={module.image} 
                  alt={module.title} 
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* Engineering Graph Mockup */}
              <div className="bg-white p-8 rounded-3xl shadow-xl border border-slate-100 flex-grow">
                <div className="flex items-center justify-between mb-8">
                  <h4 className="font-bold text-slate-900 flex items-center gap-2">
                    <ActivityIcon className="w-5 h-5 text-emerald-500" />
                    <EditableContent id={`module_graph_title_${module.id}`} defaultValue="Technical Performance Graph" />
                  </h4>
                  <div className="flex gap-2">
                    <div className="w-3 h-3 rounded-full bg-emerald-500" />
                    <div className="w-3 h-3 rounded-full bg-slate-200" />
                  </div>
                </div>
                
                <div className="h-48 flex items-end gap-2 px-4">
                  {[40, 70, 45, 90, 65, 80, 55, 95, 75, 85, 60, 100].map((h, i) => (
                    <div key={i} className="flex-grow bg-slate-100 rounded-t-lg relative group">
                      <motion.div 
                        initial={{ height: 0 }}
                        animate={{ height: `${h}%` }}
                        transition={{ duration: 1, delay: i * 0.05 }}
                        className="absolute bottom-0 left-0 right-0 bg-emerald-500 rounded-t-lg group-hover:bg-emerald-600 transition-colors"
                      />
                    </div>
                  ))}
                </div>
                <div className="flex justify-between mt-4 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  <span>00:00</span>
                  <span>06:00</span>
                  <span>12:00</span>
                  <span>18:00</span>
                  <span>24:00</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="bg-emerald-600 p-6 rounded-2xl text-white">
                  <div className="text-3xl font-bold mb-1">
                    <EditableContent id={`module_stat_val_${module.id}`} defaultValue="24%" />
                  </div>
                  <div className="text-[10px] font-bold uppercase tracking-widest opacity-80">
                    <EditableContent id={`module_stat_label_${module.id}`} defaultValue="Avg. Efficiency Gain" />
                  </div>
                </div>
                <div className="bg-slate-900 p-6 rounded-2xl text-white">
                  <div className="text-3xl font-bold mb-1">
                    <EditableContent id={`module_roi_val_${module.id}`} defaultValue="ROI" />
                  </div>
                  <div className="text-[10px] font-bold uppercase tracking-widest opacity-80">
                    <EditableContent id={`module_roi_label_${module.id}`} defaultValue="Under 18 Months" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function AuditMethodology() {
  const [selectedModule, setSelectedModule] = useState<any>(null);

  const phase1Services = [
    { id: 'bill_audit', title: 'Electricity Bill Forensic Audit', icon: Search },
    { id: 'tariff_opt', title: 'Tariff Optimization Advisory', icon: TrendingDown },
    { id: 'demand_restruct', title: 'Contract Demand Restructuring', icon: Settings },
    { id: 'load_profile', title: 'Load Profile Analysis', icon: BarChart3 },
    { id: 'solar_feasibility', title: 'Solar Feasibility Study', icon: Leaf },
    { id: 'benchmarking', title: 'Energy Cost Benchmarking', icon: Target }
  ];

  const phase2Modules = [
    {
      id: 'power-quality',
      title: 'Power Quality',
      detailTitle: 'Power Quality Engineering Analysis',
      icon: Zap,
      description: 'Comprehensive electrical power quality analysis to identify harmonics, voltage disturbances, power factor issues and demand inefficiencies affecting plant reliability.',
      image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc51?auto=format&fit=crop&q=80&w=1000',
      methodology: [
        'Power quality measurement using Class A power analyzer',
        'Voltage imbalance analysis',
        'Current unbalance measurement',
        'Total Harmonic Distortion measurement',
        'Power factor assessment',
        'Transient disturbance monitoring',
        'Electrical panel thermography inspection',
        'Demand load pattern recording',
        'IEEE-519 compliance verification'
      ],
      parameters: [
        'Voltage profile',
        'Current profile',
        'THD levels',
        'Power Factor',
        'Maximum Demand',
        'Load Factor',
        'KVA vs KW pattern'
      ],
      savings: [
        'PF penalty reduction',
        'Demand optimization',
        'Harmonic loss reduction',
        'Transformer loss reduction',
        'Electrical reliability improvement'
      ],
      deliverables: [
        'Power quality diagnostic report',
        'Energy loss analysis',
        'Corrective engineering recommendations',
        'Electrical system optimization roadmap'
      ]
    },
    {
      id: 'water-system',
      title: 'Water System',
      detailTitle: 'Water System Efficiency Audit',
      icon: Droplets,
      description: 'Detailed audit of industrial water pumping, distribution and cooling systems to identify flow inefficiencies and excess energy consumption.',
      image: 'https://images.unsplash.com/photo-1581094288338-2314dddb7ecb?auto=format&fit=crop&q=80&w=1000',
      methodology: [
        'Pump efficiency testing',
        'Flow rate measurement',
        'Pressure drop analysis',
        'Pipeline leakage inspection',
        'Cooling tower performance evaluation',
        'Hydraulic load calculation',
        'Pump motor energy analysis',
        'Water balance preparation',
        'Optimization opportunity mapping'
      ],
      parameters: [
        'Pump efficiency %',
        'Flow rate',
        'Head pressure',
        'Motor loading',
        'Cooling tower performance',
        'Specific energy consumption'
      ],
      savings: [
        'Pump resizing',
        'VFD installation',
        'Flow optimization',
        'Leakage reduction',
        'Energy reduction in pumping'
      ],
      deliverables: [
        'Water-energy nexus report',
        'Pumping system optimization plan',
        'Water conservation strategies'
      ]
    },
    {
      id: 'hvac-optimization',
      title: 'HVAC Optimization',
      detailTitle: 'HVAC System Engineering',
      icon: Wind,
      description: 'Performance assessment of HVAC systems to improve cooling efficiency and reduce electrical consumption.',
      image: 'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?auto=format&fit=crop&q=80&w=1000',
      methodology: [
        'Chiller COP calculation',
        'Air flow measurement',
        'Cooling load analysis',
        'Compressor efficiency testing',
        'Temperature mapping',
        'Duct leakage inspection',
        'AHU performance testing',
        'HVAC energy modelling'
      ],
      parameters: [
        'COP',
        'TR vs kW ratio',
        'Air flow CFM',
        'Temperature difference',
        'Motor loading',
        'Compressor efficiency'
      ],
      savings: [
        'Chiller optimization',
        'Air balancing',
        'Temperature optimization',
        'Compressor efficiency improvement',
        'Energy reduction opportunities'
      ],
      deliverables: [
        'HVAC efficiency scorecard',
        'Thermal load modeling',
        'Retro-commissioning roadmap'
      ]
    },
    {
      id: 'thermography',
      title: 'Thermography',
      detailTitle: 'Advanced Thermal Diagnostics',
      icon: Camera,
      description: 'Infrared thermal inspection to identify abnormal heating in electrical and mechanical systems.',
      image: 'https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&q=80&w=1000',
      methodology: [
        'Infrared scanning of panels',
        'Hotspot detection',
        'Cable heating analysis',
        'Transformer thermal loss study',
        'Motor temperature inspection',
        'Bearing overheating detection',
        'Preventive failure identification',
        'Risk classification'
      ],
      parameters: [
        'Temperature rise',
        'Hotspot severity',
        'Cable heating',
        'Breaker temperature',
        'Motor bearing temperature',
        'Thermal risk level'
      ],
      savings: [
        'Failure prevention',
        'Maintenance planning',
        'Loss reduction',
        'Downtime prevention',
        'Safety improvement'
      ],
      deliverables: [
        'Thermal anomaly report',
        'High-resolution IR imagery',
        'Preventive maintenance schedule'
      ]
    },
    {
      id: 'pat-compliance',
      title: 'PAT Compliance',
      detailTitle: 'PAT Cycle Advisory',
      icon: FileCheck,
      description: 'Energy performance assessment aligned with Perform Achieve Trade compliance requirements.',
      image: 'https://images.unsplash.com/photo-1454165833767-027ff33027ef?auto=format&fit=crop&q=80&w=1000',
      methodology: [
        'SEC calculation',
        'Baseline energy preparation',
        'Energy performance indicator calculation',
        'Saving verification methodology',
        'PAT documentation preparation',
        'Compliance verification',
        'Audit readiness assessment'
      ],
      parameters: [
        'Specific Energy Consumption',
        'Baseline energy',
        'Energy savings %',
        'Target compliance',
        'PAT cycle data'
      ],
      savings: [
        'PAT compliance benefits',
        'Energy saving certification',
        'Penalty avoidance',
        'Efficiency improvements'
      ],
      deliverables: [
        'Form 1 & Form A preparation',
        'M&V audit report',
        'Target achievement strategy'
      ]
    },
    {
      id: 'green-energy',
      title: 'Green Energy',
      detailTitle: 'Green Energy Integration',
      icon: Leaf,
      description: 'Assessment of renewable integration opportunities including solar power and energy transition strategies.',
      image: 'https://images.unsplash.com/photo-1509391366360-fe5bb58583bb?auto=format&fit=crop&q=80&w=1000',
      methodology: [
        'Solar feasibility study',
        'Shadow analysis',
        'Plant generation simulation',
        'Grid interaction study',
        'ROI calculation',
        'Carbon reduction analysis',
        'Net metering study',
        'Renewable integration planning'
      ],
      parameters: [
        'Solar generation potential',
        'CUF',
        'ROI',
        'Payback period',
        'Carbon savings',
        'Grid dependency'
      ],
      savings: [
        'Grid cost reduction',
        'Solar ROI benefits',
        'Carbon reduction',
        'Energy independence'
      ],
      deliverables: [
        'Net-zero roadmap',
        'Solar yield simulation',
        'PPA advisory report'
      ]
    }
  ];

  return (
    <div className="bg-white">
      <AnimatePresence>
        {selectedModule && (
          <ModuleDetail 
            module={selectedModule} 
            onClose={() => setSelectedModule(null)} 
          />
        )}
      </AnimatePresence>

      {/* SECTION 1 – Hero */}
      <section className="relative py-32 lg:py-48 overflow-hidden bg-white border-b border-slate-100">
        <div className="absolute inset-0 z-0">
          <div className="absolute top-0 left-0 w-full h-full bg-[linear-gradient(to_right,#f1f5f9_1px,transparent_1px),linear-gradient(to_bottom,#f1f5f9_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)]" />
        </div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="max-w-4xl"
          >
            <div className="inline-flex items-center gap-3 px-4 py-1.5 rounded-full bg-emerald-50 text-emerald-700 text-xs font-black uppercase tracking-[0.2em] mb-8 border border-emerald-100">
              <ShieldCheck className="w-4 h-4" />
              <EditableContent id="meth_hero_tag" defaultValue="Engineering Standard ISO 50001" />
            </div>
            <h1 className="text-6xl lg:text-8xl font-bold text-[#0f172a] mb-8 leading-[0.9] tracking-tight">
              <EditableContent id="meth_hero_title_1" defaultValue="Energy Audit" /> <br />
              <span className="italic font-serif text-emerald-600">
                <EditableContent id="meth_hero_title_2" defaultValue="Methodology" />
              </span>
            </h1>
            <div className="text-2xl text-slate-600 font-light mb-10 leading-relaxed max-w-2xl">
              <EditableContent id="meth_hero_desc" defaultValue="A structured 2-phase engineering process for industrial energy optimization." multiline />
            </div>
          </motion.div>
        </div>
      </section>

      {/* PHASE 1: Technical Energy Analysis */}
      <section className="py-32 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-24 items-start">
            <div>
              <div className="text-emerald-600 font-black uppercase tracking-[0.3em] text-xs mb-6">
                <EditableContent id="meth_p1_tag" defaultValue="Phase 01" />
              </div>
              <h2 className="text-4xl lg:text-5xl font-bold text-[#0f172a] mb-4">
                <EditableContent id="meth_p1_title" defaultValue="Technical Energy Analysis" />
              </h2>
              <h3 className="text-xl text-emerald-600 font-bold mb-8 italic">
                <EditableContent id="meth_p1_subtitle" defaultValue="Pre-Audit Strategic Energy Assessment" />
              </h3>
              
              <div className="text-lg text-slate-600 mb-10 leading-relaxed">
                <EditableContent id="meth_p1_desc" defaultValue="In this stage VPESCO analyzes electricity bills, operational patterns, and system performance before conducting on-site engineering audits. The objective is to identify high-impact cost reduction opportunities while ensuring compliance with national and state energy regulations." multiline />
              </div>

              <div className="p-8 rounded-[2rem] bg-slate-50 border border-slate-100 mb-12">
                <h4 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400 mb-6">
                  <EditableContent id="meth_compliance_title" defaultValue="Regulatory Compliance" />
                </h4>
                <div className="flex flex-wrap gap-4">
                  {['BEE', 'CERC', 'SERC'].map((org) => (
                    <div key={org} className="px-6 py-3 rounded-xl bg-white border border-slate-200 text-slate-900 font-bold text-sm shadow-sm">
                      <EditableContent id={`meth_compliance_${org}`} defaultValue={`${org} Compliance`} />
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-emerald-600 p-10 rounded-[2.5rem] text-white shadow-2xl shadow-emerald-900/20 relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-10">
                  <Lightbulb className="w-24 h-24" />
                </div>
                <div className="relative z-10">
                  <div className="text-xs font-black uppercase tracking-[0.2em] text-emerald-200 mb-4">
                    <EditableContent id="meth_p1_outcome_tag" defaultValue="Strategic Outcome" />
                  </div>
                  <div className="text-2xl font-bold leading-tight">
                    "<EditableContent id="meth_p1_outcome_text" defaultValue="Data-driven energy optimization strategy with projected ROI and savings potential." multiline />"
                  </div>
                </div>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-6">
              {phase1Services.map((service, idx) => (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: idx * 0.1 }}
                  className="p-8 rounded-3xl bg-white border border-slate-100 shadow-sm hover:shadow-xl transition-all group"
                >
                  <div className="w-12 h-12 rounded-xl bg-slate-50 flex items-center justify-center mb-6 group-hover:bg-emerald-50 transition-colors">
                    <service.icon className="w-6 h-6 text-slate-400 group-hover:text-emerald-600 transition-colors" />
                  </div>
                  <h4 className="font-bold text-slate-900 leading-tight">
                    <EditableContent id={`meth_p1_service_${service.id}`} defaultValue={service.title} />
                  </h4>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* PHASE 2: Detailed Energy Audit */}
      <section className="py-32 bg-[#0f172a] text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-20 pointer-events-none">
          <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,#1e293b_1px,transparent_1px)] [background-size:24px_24px]" />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center max-w-3xl mx-auto mb-24">
            <div className="text-emerald-400 font-black uppercase tracking-[0.3em] text-xs mb-6">
              <EditableContent id="meth_p2_tag" defaultValue="Phase 02" />
            </div>
            <h2 className="text-4xl lg:text-6xl font-bold mb-6 tracking-tight">
              <EditableContent id="meth_p2_title" defaultValue="Detailed Energy Audit" />
            </h2>
            <h3 className="text-xl text-emerald-400 font-bold mb-8 italic">
              <EditableContent id="meth_p2_subtitle" defaultValue="Advanced Engineering Diagnostics" />
            </h3>
            <div className="text-slate-400 text-lg font-light leading-relaxed">
              <EditableContent id="meth_p2_desc" defaultValue="After client agreement, VPESCO performs an on-site engineering energy audit using advanced instruments and thermal diagnostics to evaluate system efficiency and identify technical energy losses." multiline />
            </div>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {phase2Modules.map((module, idx) => (
              <motion.button
                key={module.id}
                onClick={() => setSelectedModule(module)}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="p-10 rounded-[2.5rem] bg-white/5 border border-white/10 text-left group hover:bg-white/10 transition-all relative overflow-hidden"
              >
                <div className="absolute top-0 right-0 p-8 opacity-0 group-hover:opacity-10 transition-opacity">
                  <module.icon className="w-24 h-24" />
                </div>
                <div className="w-14 h-14 rounded-2xl bg-emerald-500/20 flex items-center justify-center mb-8 group-hover:bg-emerald-500 transition-colors duration-500">
                  <module.icon className="w-7 h-7 text-emerald-400 group-hover:text-white transition-colors" />
                </div>
                <h4 className="text-2xl font-bold mb-4 tracking-tight">
                  <EditableContent id={`meth_p2_module_title_${module.id}`} defaultValue={module.title} />
                </h4>
                <div className="text-slate-400 text-sm leading-relaxed mb-8 line-clamp-2">
                  <EditableContent id={`meth_p2_module_desc_${module.id}`} defaultValue={module.description} multiline />
                </div>
                <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-[0.2em]">
                  <EditableContent id={`meth_p2_module_cta_${module.id}`} defaultValue="Explore Engineering Details" />
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-2 transition-transform" />
                </div>
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-slate-900 rounded-[3rem] p-12 md:p-24 text-center relative overflow-hidden">
            <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2" />
            <div className="relative z-10">
              <h2 className="text-4xl lg:text-5xl font-bold text-white mb-8">
                <EditableContent id="meth_cta_title" defaultValue="Ready to Optimize Your Energy Systems?" />
              </h2>
              <div className="text-xl text-slate-400 mb-12 max-w-2xl mx-auto font-light">
                <EditableContent id="meth_cta_desc" defaultValue="Partner with VPESCO to transform your energy data into measurable financial growth and sustainability impact." multiline />
              </div>
              <div className="flex flex-col sm:flex-row gap-6 justify-center">
                <button className="bg-emerald-600 text-white px-10 py-4 rounded-full font-bold text-lg hover:bg-emerald-700 transition-all shadow-xl shadow-emerald-900/20">
                  <EditableContent id="meth_cta_btn_1" defaultValue="Schedule a Consultation" />
                </button>
                <button className="bg-transparent text-white border border-white/20 px-10 py-4 rounded-full font-bold text-lg hover:bg-white/10 transition-all">
                  <EditableContent id="meth_cta_btn_2" defaultValue="Download Methodology PDF" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
