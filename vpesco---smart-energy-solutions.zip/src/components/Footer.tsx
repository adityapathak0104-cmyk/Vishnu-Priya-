import React from 'react';
import { Mail, Phone, MapPin, Facebook, Twitter, Linkedin, Instagram, Zap } from 'lucide-react';
import { Logo } from './Navbar';
import { EditableContent } from './EditableContent';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-white pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <button onClick={() => window.scrollTo(0, 0)} className="block">
              <Logo className="brightness-0 invert" />
            </button>
            <div className="text-slate-400 leading-relaxed font-serif italic text-sm">
              <EditableContent id="footer_about" defaultValue="Vishnu Priya Energy Solutions Company (VPESCO) is committed to delivering innovative energy efficiency solutions for industries and commercial facilities." multiline />
            </div>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-emerald-600 transition-all">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-emerald-600 transition-all">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-emerald-600 transition-all">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-emerald-600 transition-all">
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-8">
              <EditableContent id="footer_links_title" defaultValue="Quick Links" />
            </h3>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_link_home" defaultValue="Home" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_link_about" defaultValue="About Us" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_link_services" defaultValue="Services" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_link_audits" defaultValue="Energy Audits" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_link_projects" defaultValue="Projects" /></a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-8">
              <EditableContent id="footer_services_title" defaultValue="Services" />
            </h3>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_service_1" defaultValue="Power Factor Correction" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_service_2" defaultValue="Compressed Air Optimization" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_service_3" defaultValue="Lighting Retrofits" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_service_4" defaultValue="Motor & Drive Upgrades" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_service_5" defaultValue="Solar Rooftop Advisory" /></a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-8">
              <EditableContent id="footer_contact_title" defaultValue="Contact Us" />
            </h3>
            <ul className="space-y-6 text-slate-400">
              <li className="flex items-start gap-4">
                <MapPin className="w-6 h-6 text-emerald-500 shrink-0" />
                <span><EditableContent id="footer_address" defaultValue="123 Energy Plaza, Industrial Area, Hyderabad, India" multiline /></span>
              </li>
              <li className="flex items-center gap-4">
                <Phone className="w-6 h-6 text-emerald-500 shrink-0" />
                <span><EditableContent id="footer_phone" defaultValue="+91 123 456 7890" /></span>
              </li>
              <li className="flex items-center gap-4">
                <Mail className="w-6 h-6 text-emerald-500 shrink-0" />
                <span><EditableContent id="footer_email" defaultValue="info@vpescoenergy.com" /></span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-12 border-t border-slate-800 flex flex-col md:row justify-between items-center gap-6 text-slate-500 text-sm">
          <p>© {currentYear} <EditableContent id="footer_copyright" defaultValue="Vishnu Priya Energy Solutions Company. All rights reserved." /></p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors"><EditableContent id="footer_privacy" defaultValue="Privacy Policy" /></a>
            <a href="#" className="hover:text-white transition-colors"><EditableContent id="footer_terms" defaultValue="Terms of Service" /></a>
            <a href="#" className="hover:text-white transition-colors"><EditableContent id="footer_cookie" defaultValue="Cookie Policy" /></a>
          </div>
        </div>
      </div>
    </footer>
  );
}
