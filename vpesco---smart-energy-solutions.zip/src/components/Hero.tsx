import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ArrowRight, Zap, Activity, Shield, BarChart3, Globe, Cpu, Gauge, ChevronLeft, ChevronRight, Sun, Wind, Droplets, Flame, Atom, Factory, Edit2, Check, X } from 'lucide-react';
import { motion, useScroll, useTransform, useInView, AnimatePresence } from 'motion/react';
import { useEdit } from '../context/EditContext';
import { EditableContent } from './EditableContent';

interface HeroProps {
  setActivePage: (page: string) => void;
}

interface StatItem {
  id: string;
  label: string;
  value: number;
  suffix: string;
  prefix: string;
  icon: any;
}

const Counter = ({ value, suffix = "", prefix = "", decimals = 0 }: { value: number, suffix?: string, prefix?: string, decimals?: number }) => {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const end = value;
      const duration = 2000;
      const increment = end / (duration / 16);
      
      const timer = setInterval(() => {
        start += increment;
        if (start >= end) {
          setCount(end);
          clearInterval(timer);
        } else {
          setCount(start);
        }
      }, 16);
      return () => clearInterval(timer);
    }
  }, [isInView, value]);

  return (
    <span ref={ref}>
      {prefix}{count.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}{suffix}
    </span>
  );
};

const HERO_IMAGES = [
  {
    id: 'solar',
    title: 'Solar Power Plant',
    url: 'https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&q=80&w=2000',
    icon: Sun,
    label: 'Solar'
  },
  {
    id: 'wind',
    title: 'Wind Power Plant',
    url: 'https://images.unsplash.com/photo-1466611653911-95281773ad90?auto=format&fit=crop&q=80&w=2000',
    icon: Wind,
    label: 'Wind'
  },
  {
    id: 'thermal',
    title: 'Thermal Power Plant',
    url: 'https://images.unsplash.com/photo-1513828583688-c52646db42da?auto=format&fit=crop&q=80&w=2000',
    icon: Flame,
    label: 'Thermal'
  },
  {
    id: 'hydro',
    title: 'Hydro Power Plant',
    url: 'https://images.unsplash.com/photo-1518005020250-675f04031729?auto=format&fit=crop&q=80&w=2000',
    icon: Droplets,
    label: 'Hydro'
  },
  {
    id: 'nuclear',
    title: 'Nuclear Power Plant',
    url: 'https://images.unsplash.com/photo-1517089596392-fb9a9033e05b?auto=format&fit=crop&q=80&w=2000',
    icon: Atom,
    label: 'Nuclear'
  },
  {
    id: 'industrial',
    title: 'Industrial Energy Systems',
    url: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=2000',
    icon: Factory,
    label: 'Green Future'
  }
];

const FileCheck = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export default function Hero({ setActivePage }: HeroProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const { isEditMode, getContent, setContent } = useEdit();
  const [editingStatId, setEditingStatId] = useState<string | null>(null);
  
  const [stats, setStats] = useState<StatItem[]>([
    { id: 'audits', label: 'Energy Audits', value: 500, suffix: '+', prefix: '', icon: FileCheck },
    { id: 'clients', label: 'Industrial Clients', value: 120, suffix: '+', prefix: '', icon: Shield },
    { id: 'saved', label: 'Energy Saved', value: 25, suffix: 'M kWh', prefix: '', icon: Zap },
    { id: 'carbon', label: 'Carbon Reduction', value: 18000, suffix: ' Tons', prefix: '', icon: Globe },
    { id: 'cost', label: 'Cost Savings', value: 12, suffix: ' Cr+', prefix: '₹', icon: BarChart3 },
    { id: 'load', label: 'Load Factor', value: 78, suffix: '%', prefix: '', icon: Activity },
  ]);

  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 200]);

  const nextSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % HERO_IMAGES.length);
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + HERO_IMAGES.length) % HERO_IMAGES.length);
  }, []);

  useEffect(() => {
    if (isAutoPlaying) {
      const interval = setInterval(nextSlide, 5000);
      return () => clearInterval(interval);
    }
  }, [isAutoPlaying, nextSlide]);

  // Load stats from localStorage if available
  useEffect(() => {
    const savedStats = localStorage.getItem('vpesco_stats');
    if (savedStats) {
      try {
        const parsed = JSON.parse(savedStats);
        // Map icons back as they are lost in JSON
        const iconMap: Record<string, any> = {
          audits: FileCheck,
          clients: Shield,
          saved: Zap,
          carbon: Globe,
          cost: BarChart3,
          load: Activity
        };
        const restored = parsed.map((s: any) => ({
          ...s,
          icon: iconMap[s.id] || FileCheck
        }));
        setStats(restored);
      } catch (e) {
        console.error("Failed to restore stats", e);
      }
    }
  }, []);

  const updateStat = (id: string, newValue: number) => {
    const updated = stats.map(s => s.id === id ? { ...s, value: newValue } : s);
    setStats(updated);
    localStorage.setItem('vpesco_stats', JSON.stringify(updated.map(({ icon, ...rest }) => rest)));
    setEditingStatId(null);
  };

  return (
    <section 
      className="relative min-h-screen flex flex-col justify-center overflow-hidden bg-[#020617]"
      onMouseEnter={() => setIsAutoPlaying(false)}
      onMouseLeave={() => setIsAutoPlaying(true)}
    >
      {/* Background Image Slider */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1.05 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className="absolute inset-0"
          >
            <img
              src={HERO_IMAGES[currentIndex].url}
              alt={HERO_IMAGES[currentIndex].title}
              className="w-full h-full object-cover"
              loading="lazy"
            />
          </motion.div>
        </AnimatePresence>
        <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-[1px]" />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/40 via-transparent to-slate-950" />
      </div>

      {/* SCADA Style Overlay */}
      <div className="absolute inset-0 z-1 pointer-events-none opacity-20">
        <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle, #10b981 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
        <svg className="w-full h-full">
          <defs>
            <pattern id="grid" width="100" height="100" patternUnits="userSpaceOnUse">
              <path d="M 100 0 L 0 0 0 100" fill="none" stroke="#10b981" strokeWidth="0.5" strokeOpacity="0.3" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
          
          <motion.path
            d="M 100 100 L 300 100 L 300 300"
            fill="none"
            stroke="#10b981"
            strokeWidth="1"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          />
          <motion.circle
            r="3"
            fill="#10b981"
            animate={{ cx: [100, 300, 300], cy: [100, 100, 300] }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          />
        </svg>
      </div>

      {/* Energy Particles */}
      <div className="absolute inset-0 z-1 pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-emerald-400 rounded-full shadow-[0_0_10px_#10b981]"
            initial={{ 
              x: Math.random() * 100 + "%", 
              y: Math.random() * 100 + "%",
              opacity: 0 
            }}
            animate={{ 
              y: [null, "-10%"],
              opacity: [0, 1, 0]
            }}
            transition={{ 
              duration: Math.random() * 5 + 5, 
              repeat: Infinity, 
              delay: Math.random() * 5 
            }}
          />
        ))}
      </div>

      {/* Manual Controls */}
      <div className="absolute inset-y-0 left-4 flex items-center z-30">
        <button 
          onClick={prevSlide}
          className="p-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white transition-all backdrop-blur-md"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
      </div>
      <div className="absolute inset-y-0 right-4 flex items-center z-30">
        <button 
          onClick={nextSlide}
          className="p-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white transition-all backdrop-blur-md"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      {/* Indicator Dots */}
      <div className="absolute bottom-24 left-1/2 -translate-x-1/2 flex gap-3 z-30">
        {HERO_IMAGES.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentIndex(i)}
            className={`h-1 transition-all duration-500 rounded-full ${currentIndex === i ? 'w-8 bg-emerald-500' : 'w-2 bg-white/30 hover:bg-white/50'}`}
          />
        ))}
      </div>

      {/* Energy Tabs Interaction */}
      <div className="absolute top-32 left-1/2 -translate-x-1/2 z-30 hidden md:flex items-center gap-2 p-1 bg-slate-900/40 backdrop-blur-xl border border-white/10 rounded-2xl">
        {HERO_IMAGES.map((tab, i) => (
          <button
            key={tab.id}
            onClick={() => setCurrentIndex(i)}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              currentIndex === i 
                ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20' 
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            <tab.icon className={`w-4 h-4 ${currentIndex === i ? 'text-white' : 'text-emerald-500/50'}`} />
            {tab.label}
          </button>
        ))}
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full pt-48 pb-20">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <motion.div
            key={`content-${currentIndex}`}
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 backdrop-blur-sm">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-bold tracking-[0.2em] text-emerald-400 uppercase">
                <EditableContent id="hero_platform_tag" defaultValue="Engineering Intelligence Platform" />
              </span>
            </div>

            <h1 className="text-5xl lg:text-7xl font-bold text-white leading-[1.1] tracking-tight">
              <EditableContent id="hero_title" defaultValue="Engineering Intelligence for Industrial Energy Optimization" multiline />
            </h1>

            <p className="text-2xl text-emerald-100/80 font-medium leading-relaxed">
              <EditableContent id="hero_subtitle" defaultValue="Transforming Energy Data into Measurable Business Savings." />
            </p>

            <p className="text-lg text-slate-400 leading-relaxed max-w-xl">
              <EditableContent id="hero_description" defaultValue="VPESCO delivers advanced energy analytics, detailed audits, and smart monitoring solutions to reduce industrial power costs and improve operational efficiency." multiline />
            </p>
            
            <div className="flex flex-col sm:flex-row gap-6 pt-4">
              <button 
                onClick={() => setActivePage('audits')}
                className="relative group overflow-hidden bg-emerald-600 text-white px-10 py-5 rounded-xl font-bold transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] flex items-center justify-center gap-3 text-lg"
              >
                <div className="absolute inset-0 bg-gradient-to-r from-emerald-400/0 via-white/20 to-emerald-400/0 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
                <EditableContent id="hero_cta_audit" defaultValue="Get Energy Audit" />
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </button>
              <button 
                onClick={() => setActivePage('intelligence')}
                className="bg-white/5 backdrop-blur-md text-white border border-white/10 px-10 py-5 rounded-xl font-bold hover:bg-white/10 transition-all flex items-center justify-center text-lg"
              >
                <EditableContent id="hero_cta_platform" defaultValue="View Intelligence Platform" />
              </button>
            </div>
          </motion.div>

          {/* Live Data Counters Grid */}
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="grid grid-cols-2 gap-4"
          >
            {stats.map((stat, i) => (
              <div key={i} className="relative p-6 rounded-2xl bg-slate-900/40 backdrop-blur-md border border-white/5 hover:border-emerald-500/30 transition-all group overflow-hidden">
                {isEditMode && (
                  <div className="absolute top-2 right-2 z-20">
                    <button 
                      onClick={() => setEditingStatId(stat.id)}
                      className="p-1.5 bg-emerald-500 rounded-md text-white hover:bg-emerald-400 transition-colors"
                    >
                      <Edit2 className="w-3 h-3" />
                    </button>
                  </div>
                )}

                <stat.icon className="w-6 h-6 text-emerald-500 mb-4 group-hover:scale-110 transition-transform" />
                
                {editingStatId === stat.id ? (
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <span className="text-white font-mono">{stat.prefix}</span>
                      <input 
                        type="number"
                        defaultValue={stat.value}
                        autoFocus
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') updateStat(stat.id, Number(e.currentTarget.value));
                          if (e.key === 'Escape') setEditingStatId(null);
                        }}
                        className="w-full bg-slate-800 border border-emerald-500 rounded px-2 py-1 text-white font-bold"
                      />
                      <span className="text-white font-mono">{stat.suffix}</span>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => {
                          const input = document.querySelector(`input`) as HTMLInputElement;
                          updateStat(stat.id, Number(input.value));
                        }}
                        className="flex-1 bg-emerald-600 py-1 rounded text-[10px] font-bold uppercase"
                      >
                        Save
                      </button>
                      <button 
                        onClick={() => setEditingStatId(null)}
                        className="flex-1 bg-slate-700 py-1 rounded text-[10px] font-bold uppercase"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="text-3xl font-bold text-white mb-1">
                    <Counter value={stat.value} prefix={stat.prefix} suffix={stat.suffix} />
                  </div>
                )}
                
                <p className="text-xs uppercase tracking-widest text-slate-500 font-bold">
                  <EditableContent id={`hero_stat_label_${stat.id}`} defaultValue={stat.label} />
                </p>
              </div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Carbon Reduction Ticker */}
      <div className="absolute bottom-0 left-0 w-full bg-slate-950/80 backdrop-blur-xl border-t border-white/5 py-4 overflow-hidden z-20">
        <div className="flex whitespace-nowrap animate-marquee">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex items-center gap-12 px-6">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <EditableContent id="ticker_label_1" defaultValue="Carbon Saved Today:" />
                </span>
                <span className="text-sm font-mono text-emerald-400">
                  <EditableContent id="ticker_value_1" defaultValue="+2.4 Tons CO₂" />
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <EditableContent id="ticker_label_2" defaultValue="Energy Optimized:" />
                </span>
                <span className="text-sm font-mono text-blue-400">
                  <EditableContent id="ticker_value_2" defaultValue="+18,500 kWh" />
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <EditableContent id="ticker_label_3" defaultValue="Savings Generated:" />
                </span>
                <span className="text-sm font-mono text-amber-400">
                  <EditableContent id="ticker_value_3" defaultValue="₹3,25,000" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-33.33%); }
        }
        .animate-marquee {
          animation: marquee 30s linear infinite;
        }
        .animate-spin-slow {
          animation: spin 8s linear infinite;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}} />
    </section>
  );
}
