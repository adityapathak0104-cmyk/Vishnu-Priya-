import React from 'react';
import { Menu, X, Zap } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { EditableContent } from './EditableContent';

interface NavbarProps {
  activePage: string;
  setActivePage: (page: string) => void;
}

export function Logo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <div className="relative flex items-center justify-center w-12 h-12 shrink-0">
        {/* Main Green Circle */}
        <div className="relative w-10 h-10 bg-[#74c947] rounded-full flex items-center justify-center shadow-sm overflow-visible">
          <span className="text-white font-black text-xl tracking-tighter">VP</span>
          
          {/* Yellow Bolt Icon - Upper Right */}
          <div className="absolute -top-1.5 -right-1.5 bg-[#facc15] w-5 h-5 rounded-md shadow-sm flex items-center justify-center border border-white/20">
            <Zap className="w-3.5 h-3.5 text-white fill-white" />
          </div>
          
          {/* Dark Green Base/Shadow */}
          <div className="absolute -bottom-1 w-6 h-1 bg-[#14532d] rounded-full opacity-80" />
        </div>
      </div>
      <div className="flex flex-col text-left">
        <span className="text-2xl font-black tracking-tight text-[#1e40af] leading-none">
          <EditableContent id="logo_main" defaultValue="Vishnu Priya" />
        </span>
        <span className="text-[9px] font-bold tracking-[0.2em] text-[#15803d] uppercase mt-1">
          <EditableContent id="logo_sub" defaultValue="Energy Solutions Company" />
        </span>
      </div>
    </div>
  );
}

export default function Navbar({ activePage, setActivePage }: NavbarProps) {
  const [isOpen, setIsOpen] = React.useState(false);

  const navLinks = [
    { name: 'Home', id: 'home' },
    { name: 'About Us', id: 'about' },
    { name: 'Services', id: 'services' },
    { name: 'Audit Methodology', id: 'audits' },
    { name: 'Energy Intelligence', id: 'intelligence' },
    { name: 'Industries', id: 'industries' },
    { name: 'Contact', id: 'contact' },
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-white/90 backdrop-blur-md border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <button 
            className="cursor-pointer" 
            onClick={() => setActivePage('home')}
          >
            <Logo />
          </button>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => setActivePage(link.id)}
                className={`text-sm font-medium transition-colors ${
                  activePage === link.id 
                    ? 'text-emerald-600' 
                    : 'text-slate-600 hover:text-emerald-600'
                }`}
              >
                {link.name}
              </button>
            ))}
            <button 
              onClick={() => setActivePage('contact')}
              className="bg-emerald-600 text-white px-5 py-2.5 rounded-full text-sm font-semibold hover:bg-emerald-700 transition-all shadow-sm"
            >
              <EditableContent id="nav_cta" defaultValue="Get Audit" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="text-slate-600 hover:text-emerald-600 p-2"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-b border-slate-100 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-1">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => {
                    setActivePage(link.id);
                    setIsOpen(false);
                  }}
                  className={`block w-full text-left px-3 py-3 text-base font-medium rounded-md ${
                    activePage === link.id
                      ? 'text-emerald-600 bg-emerald-50'
                      : 'text-slate-600 hover:text-emerald-600 hover:bg-slate-50'
                  }`}
                >
                  {link.name}
                </button>
              ))}
              <div className="pt-4">
                <button 
                  onClick={() => {
                    setActivePage('contact');
                    setIsOpen(false);
                  }}
                  className="w-full bg-emerald-600 text-white px-5 py-3 rounded-xl text-center font-semibold"
                >
                  <EditableContent id="nav_cta_mobile" defaultValue="Book Energy Audit" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
