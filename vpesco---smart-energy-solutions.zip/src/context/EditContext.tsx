import React, { createContext, useContext, useState, useEffect } from 'react';

interface EditContextType {
  isEditMode: boolean;
  setIsEditMode: (mode: boolean) => void;
  getContent: (id: string, defaultValue: string) => string;
  setContent: (id: string, value: string) => void;
}

const EditContext = createContext<EditContextType | undefined>(undefined);

export const EditProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isEditMode, setIsEditMode] = useState(false);
  const [contentStore, setContentStore] = useState<Record<string, string>>({});

  // Load from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('vpesco_editable_content');
    if (saved) {
      try {
        setContentStore(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to load content store", e);
      }
    }
  }, []);

  const getContent = (id: string, defaultValue: string) => {
    return contentStore[id] || defaultValue;
  };

  const setContent = (id: string, value: string) => {
    const newStore = { ...contentStore, [id]: value };
    setContentStore(newStore);
    localStorage.setItem('vpesco_editable_content', JSON.stringify(newStore));
  };

  return (
    <EditContext.Provider value={{ isEditMode, setIsEditMode, getContent, setContent }}>
      {children}
    </EditContext.Provider>
  );
};

export const useEdit = () => {
  const context = useContext(EditContext);
  if (!context) {
    throw new Error('useEdit must be used within an EditProvider');
  }
  return context;
};
