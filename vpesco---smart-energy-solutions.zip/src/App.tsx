import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ClientLogos from './components/ClientLogos';
import SavingsEstimator from './components/SavingsEstimator';
import AboutSection from './components/About';
import ServicesSection from './components/Services';
import AuditMethodology from './components/AuditMethodology';
import IndustriesSection from './components/Industries';
import EnergyIntelligence from './components/EnergyIntelligence';
import Contact from './components/Contact';
import Footer from './components/Footer';
import PerformanceAnalysis from './components/PerformanceAnalysis';
import CompanyJourney from './components/CompanyJourney';
import { motion, AnimatePresence } from 'motion/react';
import { EditProvider, useEdit } from './context/EditContext';
import { Settings } from 'lucide-react';
import { EditableContent } from './components/EditableContent';

const EditToggle = () => {
  const { isEditMode, setIsEditMode } = useEdit();
  return (
    <div className="fixed top-24 right-8 z-[100]">
      <button 
        onClick={() => setIsEditMode(!isEditMode)}
        className={`p-3 rounded-full backdrop-blur-md border transition-all flex items-center gap-2 ${
          isEditMode 
            ? 'bg-emerald-500 border-emerald-400 text-white shadow-[0_0_20px_rgba(16,185,129,0.4)]' 
            : 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10'
        }`}
        title={isEditMode ? "Exit Edit Mode" : "Enter Edit Mode"}
      >
        <Settings className={`w-5 h-5 ${isEditMode ? 'animate-spin-slow' : ''}`} />
        {isEditMode && <span className="text-xs font-bold uppercase tracking-widest">Editing Mode</span>}
      </button>
    </div>
  );
};

function AppContent() {
  const [activePage, setActivePage] = useState('home');

  // Scroll to top when page changes
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [activePage]);

  const renderPage = () => {
    switch (activePage) {
      case 'home':
        return (
          <>
            <Hero setActivePage={setActivePage} />
            <ClientLogos />
            <AboutSection />
            <ServicesSection />
            <PerformanceAnalysis />
            <SavingsEstimator />
            <EnergyIntelligence />
            <AuditMethodology />
            <IndustriesSection />
            <Contact />
          </>
        );
      case 'intelligence':
        return (
          <div className="pt-20">
            <EnergyIntelligence />
          </div>
        );
      case 'about':
        return (
          <div className="pt-20">
            <AboutSection />
            <div className="py-24 bg-slate-50">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <h3 className="text-3xl font-bold text-slate-900 mb-8 text-center">
                  <EditableContent id="app_about_mv_title" defaultValue="Our Mission & Vision" />
                </h3>
                <div className="grid md:grid-cols-2 gap-12">
                  <div className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100">
                    <h4 className="text-xl font-bold text-emerald-600 mb-4 uppercase tracking-wider">
                      <EditableContent id="app_about_mission_title" defaultValue="Mission" />
                    </h4>
                    <p className="text-slate-600 leading-relaxed">
                      <EditableContent id="app_about_mission_desc" defaultValue="To reduce energy waste, improve operational efficiency, and support organizations in achieving sustainability goals through innovative engineering and data-driven solutions." multiline />
                    </p>
                  </div>
                  <div className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100">
                    <h4 className="text-xl font-bold text-emerald-600 mb-4 uppercase tracking-wider">
                      <EditableContent id="app_about_vision_title" defaultValue="Vision" />
                    </h4>
                    <p className="text-slate-600 leading-relaxed">
                      <EditableContent id="app_about_vision_desc" defaultValue="To be the global leader in energy efficiency consulting, empowering industries to thrive in a carbon-neutral future while maximizing their operational profitability." multiline />
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <CompanyJourney />
          </div>
        );
      case 'services':
        return (
          <div className="pt-20">
            <ServicesSection />
            <div className="py-24 bg-white">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid lg:grid-cols-2 gap-16 items-center">
                  <div className="rounded-3xl overflow-hidden shadow-2xl">
                    <img 
                      src="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80&w=1000" 
                      alt="Advanced monitoring systems" 
                      className="w-full h-full object-cover aspect-video"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div>
                    <h3 className="text-3xl font-bold text-slate-900 mb-6">
                      <EditableContent id="app_services_tech_title" defaultValue="Innovative Technology Integration" />
                    </h3>
                    <p className="text-slate-600 mb-8 leading-relaxed">
                      <EditableContent id="app_services_tech_desc" defaultValue="We don't just provide consulting; we integrate the latest IoT and AI-driven monitoring technologies to give you real-time visibility into your energy consumption." multiline />
                    </p>
                    <ul className="space-y-4">
                      <li className="flex items-center gap-3 font-semibold text-slate-800">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                        <EditableContent id="app_services_tech_i1" defaultValue="Customized Energy Management Systems" />
                      </li>
                      <li className="flex items-center gap-3 font-semibold text-slate-800">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                        <EditableContent id="app_services_tech_i2" defaultValue="Predictive Maintenance Analytics" />
                      </li>
                      <li className="flex items-center gap-3 font-semibold text-slate-800">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                        <EditableContent id="app_services_tech_i3" defaultValue="Automated Reporting & Compliance" />
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      case 'audits':
        return (
          <div className="pt-20">
            <AuditMethodology />
          </div>
        );
      case 'industries':
        return (
          <div className="pt-20">
            <IndustriesSection />
          </div>
        );
      case 'contact':
        return (
          <div className="pt-20">
            <Contact />
          </div>
        );
      default:
        return <Hero setActivePage={setActivePage} />;
    }
  };

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900 selection:bg-emerald-100 selection:text-emerald-900">
      <Navbar activePage={activePage} setActivePage={setActivePage} />
      <EditToggle />
      <main>
        <AnimatePresence mode="wait">
          <motion.div
            key={activePage}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>

      <Footer />
    </div>
  );
}

export default function App() {
  return (
    <EditProvider>
      <AppContent />
    </EditProvider>
  );
}
