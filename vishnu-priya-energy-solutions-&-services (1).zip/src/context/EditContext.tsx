import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut,
  User
} from 'firebase/auth';
import { 
  doc, 
  onSnapshot, 
  setDoc, 
  serverTimestamp,
  getDocFromServer,
  collection,
  query
} from 'firebase/firestore';
import { auth, db } from '../firebase';

import { toast } from 'sonner';

interface EditContextType {
  isEditMode: boolean;
  setIsEditMode: (mode: boolean) => void;
  getContent: (id: string, defaultValue: string) => string;
  setContent: (id: string, value: string) => Promise<void>;
  getImage: (id: string, defaultUrl: string) => string;
  setImage: (id: string, url: string) => Promise<void>;
  user: User | null;
  login: () => Promise<void>;
  logout: () => Promise<void>;
  isAdmin: boolean;
  isAuthReady: boolean;
  highlightMode: boolean;
  setHighlightMode: (mode: boolean) => void;
}

const EditContext = createContext<EditContextType | undefined>(undefined);

const ADMIN_EMAIL = "adityapathak0104@gmail.com";

export const EditProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [isEditMode, setIsEditMode] = useState(false);
  const [contentStore, setContentStore] = useState<Record<string, string>>({});
  const [imageStore, setImageStore] = useState<Record<string, string>>({});
  const [user, setUser] = useState<User | null>(null);
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [highlightMode, setHighlightMode] = useState(false);

  const isAdmin = user?.email === ADMIN_EMAIL && user?.emailVerified === true;

  // Handle Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setIsAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  // Test connection to Firestore
  useEffect(() => {
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(db, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.error("Please check your Firebase configuration. The client is offline.");
        }
      }
    };
    testConnection();
  }, []);

  // Sync Content from Firestore
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'content'), (snapshot) => {
      const newStore: Record<string, string> = {};
      snapshot.forEach((doc) => {
        const data = doc.data();
        if (data.id && data.value) {
          newStore[data.id] = data.value;
        }
      });
      setContentStore(newStore);
    }, (error) => {
      console.error("Firestore Content Sync Error:", error);
    });
    return () => unsubscribe();
  }, []);

  // Sync Images from Firestore
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, 'images'), (snapshot) => {
      const newStore: Record<string, string> = {};
      snapshot.forEach((doc) => {
        const data = doc.data();
        if (data.id && data.url) {
          newStore[data.id] = data.url;
        }
      });
      setImageStore(newStore);
    }, (error) => {
      console.error("Firestore Image Sync Error:", error);
    });
    return () => unsubscribe();
  }, []);

  const getContent = React.useCallback((id: string, defaultValue: string) => {
    return contentStore[id] || defaultValue;
  }, [contentStore]);

  const setContent = async (id: string, value: string) => {
    if (!isAdmin) return;
    try {
      await setDoc(doc(db, 'content', id), {
        id,
        value,
        updatedAt: serverTimestamp()
      });
      toast.success('Content saved successfully');
    } catch (error) {
      console.error("Failed to save content to Firestore", error);
      toast.error('Failed to save content');
    }
  };

  const getImage = React.useCallback((id: string, defaultUrl: string) => {
    return imageStore[id] || defaultUrl;
  }, [imageStore]);

  const setImage = async (id: string, url: string) => {
    if (!isAdmin) return;
    try {
      await setDoc(doc(db, 'images', id), {
        id,
        url,
        updatedAt: serverTimestamp()
      });
      toast.success('Image saved successfully');
    } catch (error) {
      console.error("Failed to save image to Firestore", error);
      toast.error('Failed to save image');
    }
  };

  const login = async () => {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const loggedInUser = result.user;
      
      if (loggedInUser.email === ADMIN_EMAIL) {
        toast.success('Admin login successful');
      } else {
        // Notify Aditya via mailto link as a fallback for real email service
        const subject = encodeURIComponent("Admin Access Request - VPESCO");
        const body = encodeURIComponent(`Hello Aditya,\n\nUser ${loggedInUser.displayName} (${loggedInUser.email}) has logged in and is requesting admin access to the VPESCO website.\n\nPlease approve their request in the Firebase Console if appropriate.\n\nUser UID: ${loggedInUser.uid}`);
        
        toast.info("Login successful. Please notify the founder for admin approval.", {
          duration: 10000,
          action: {
            label: "Notify Founder",
            onClick: () => window.location.href = `mailto:${ADMIN_EMAIL}?subject=${subject}&body=${body}`
          }
        });
      }
    } catch (error) {
      console.error("Login failed", error);
      toast.error("Login failed. Please try again.");
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
      setIsEditMode(false);
    } catch (error) {
      console.error("Logout failed", error);
    }
  };

  return (
    <EditContext.Provider value={{ 
      isEditMode, 
      setIsEditMode, 
      getContent, 
      setContent,
      getImage,
      setImage,
      user,
      login,
      logout,
      isAdmin,
      isAuthReady,
      highlightMode,
      setHighlightMode
    }}>
      {children}
    </EditContext.Provider>
  );
};

export const useEdit = () => {
  const context = useContext(EditContext);
  if (!context) {
    throw new Error('useEdit must be used within an EditProvider');
  }
  return context;
};
