import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import SavingsEstimator from './components/SavingsEstimator';
import AboutSection from './components/About';
import ServicesSection from './components/Services';
import AuditMethodology from './components/AuditMethodology';
import IndustriesSection from './components/Industries';
import EnergyIntelligence from './components/EnergyIntelligence';
import Contact from './components/Contact';
import Footer from './components/Footer';
import PerformanceAnalysis from './components/PerformanceAnalysis';
import CompanyJourney from './components/CompanyJourney';
import BillAudit from './components/BillAudit';
import VisitorsData from './components/VisitorsData';
import SocialSidebar from './components/SocialSidebar';
import TeamSection from './components/Team';
import { motion, AnimatePresence } from 'motion/react';
import { EditProvider, useEdit } from './context/EditContext';
import { Settings, LogIn, LogOut, User as UserIcon, Share2, LayoutDashboard } from 'lucide-react';
import { EditableContent } from './components/EditableContent';
import { EditableImage } from './components/EditableImage';

const EditToggle = () => {
  const { isEditMode, setIsEditMode, user, login, logout, isAdmin, isAuthReady, highlightMode, setHighlightMode } = useEdit();
  const [showLogin, setShowLogin] = useState(false);
  const [showHelp, setShowHelp] = useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl + Alt + A to show login
      if (e.ctrlKey && e.altKey && e.key === 'a') {
        setShowLogin(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  if (!isAuthReady) return null;

  // Only show if user is logged in (admin) OR if the secret shortcut was used
  if (!user && !showLogin) return null;

  return (
    <div className="fixed top-24 right-8 z-[100] flex flex-col gap-3 items-end">
      {user ? (
        <div className="flex flex-col gap-2 items-end">
          <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md border border-white/10 px-3 py-1.5 rounded-full text-white text-xs">
            <UserIcon className="w-3 h-3" />
            <span className="max-w-[120px] truncate">{user.email}</span>
            {isAdmin && <span className="bg-emerald-500 text-[10px] px-1.5 py-0.5 rounded-full font-bold uppercase ml-1">Admin</span>}
          </div>
          
          <div className="flex gap-2">
            {isAdmin && (
              <>
                <a 
                  href="/vpesco-admin.html"
                  target="_blank"
                  className="p-3 rounded-full bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 transition-all flex items-center gap-2"
                  title="Admin Dashboard"
                >
                  <LayoutDashboard className="w-5 h-5" />
                  {isEditMode && <span className="text-xs font-bold uppercase tracking-widest">Dashboard</span>}
                </a>

                <button 
                  onClick={() => setHighlightMode(!highlightMode)}
                  className={`p-3 rounded-full backdrop-blur-md border transition-all flex items-center gap-2 ${
                    highlightMode 
                      ? 'bg-blue-500 border-blue-400 text-white shadow-[0_0_20px_rgba(59,130,246,0.4)]' 
                      : 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10'
                  }`}
                  title={highlightMode ? "Hide Editable Areas" : "Highlight Editable Areas"}
                >
                  <Share2 className="w-5 h-5" />
                  {highlightMode && <span className="text-xs font-bold uppercase tracking-widest">Highlighting</span>}
                </button>

                <button 
                  onClick={() => setIsEditMode(!isEditMode)}
                  className={`p-3 rounded-full backdrop-blur-md border transition-all flex items-center gap-2 ${
                    isEditMode 
                      ? 'bg-emerald-500 border-emerald-400 text-white shadow-[0_0_20px_rgba(16,185,129,0.4)]' 
                      : 'bg-white/5 border-white/10 text-slate-400 hover:text-white hover:bg-white/10'
                  }`}
                  title={isEditMode ? "Exit Edit Mode" : "Enter Edit Mode"}
                >
                  <Settings className={`w-5 h-5 ${isEditMode ? 'animate-spin-slow' : ''}`} />
                  {isEditMode && <span className="text-xs font-bold uppercase tracking-widest">Editing Mode</span>}
                </button>
              </>
            )}
            
            <button 
              onClick={logout}
              className="p-3 rounded-full bg-white/5 border border-white/10 text-slate-400 hover:text-white hover:bg-red-500/20 hover:border-red-500/30 transition-all"
              title="Logout"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>

          {isEditMode && isAdmin && (
            <div className="bg-slate-900/80 backdrop-blur-md border border-emerald-500/30 p-4 rounded-2xl text-white text-xs max-w-[200px] shadow-2xl mt-2">
              <p className="font-bold text-emerald-400 mb-2 uppercase tracking-widest">Editing Guide:</p>
              <ul className="space-y-2 text-slate-300">
                <li className="flex gap-2">
                  <span className="text-emerald-500 font-bold">•</span>
                  Click any text to change it.
                </li>
                <li className="flex gap-2">
                  <span className="text-emerald-500 font-bold">•</span>
                  Hover over images to upload new ones.
                </li>
                <li className="flex gap-2">
                  <span className="text-emerald-500 font-bold">•</span>
                  Use the blue button to see all editable areas.
                </li>
              </ul>
            </div>
          )}
        </div>
      ) : (
        <div className="flex flex-col gap-2 items-end">
          <button 
            onClick={login}
            className="p-3 rounded-full bg-white/10 backdrop-blur-md border border-emerald-500/50 text-emerald-400 hover:text-white hover:bg-emerald-600 transition-all flex items-center gap-2 shadow-[0_0_20px_rgba(16,185,129,0.2)]"
            title="Login to Edit"
          >
            <LogIn className="w-5 h-5" />
            <span className="text-xs font-bold uppercase tracking-widest">Admin Login</span>
          </button>
          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest bg-slate-900/50 px-2 py-1 rounded-full">
            Login to edit website content
          </p>
        </div>
      )}
    </div>
  );
};

import { Toaster } from 'sonner';

function AppContent() {
  const [activePage, setActivePage] = useState('home');
  const { isEditMode, isAdmin, getContent, setContent } = useEdit();
  const [showSocial, setShowSocial] = useState(getContent('show_social_sidebar', 'true') === 'true');

  const toggleSocial = async () => {
    const newVal = !showSocial;
    setShowSocial(newVal);
    await setContent('show_social_sidebar', newVal.toString());
  };

  // Scroll to top when page changes
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [activePage]);

  // Sync showSocial with Firestore
  useEffect(() => {
    setShowSocial(getContent('show_social_sidebar', 'true') === 'true');
  }, [getContent]);

  const renderPage = () => {
    switch (activePage) {
      case 'home':
        return (
          <>
            <Hero setActivePage={setActivePage} />
            <AboutSection />
            <ServicesSection />
            <PerformanceAnalysis />
            <SavingsEstimator setActivePage={setActivePage} />
            <EnergyIntelligence setActivePage={setActivePage} />
            <TeamSection />
            <AuditMethodology />
            <IndustriesSection />
            <Contact />
          </>
        );
      case 'intelligence':
        return (
          <div className="pt-20">
            <EnergyIntelligence setActivePage={setActivePage} />
          </div>
        );
      case 'team':
        return (
          <div className="pt-20">
            <TeamSection />
          </div>
        );
      case 'about':
        return (
          <div className="pt-20">
            <AboutSection />
            <div className="py-24 bg-slate-50">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <h3 className="text-3xl font-bold text-slate-900 mb-8 text-center">
                  <EditableContent id="app_about_mv_title" defaultValue="Our Mission & Vision" />
                </h3>
                <div className="grid md:grid-cols-2 gap-12">
                  <div className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100">
                    <h4 className="text-xl font-bold text-emerald-600 mb-4 uppercase tracking-wider">
                      <EditableContent id="app_about_mission_title" defaultValue="Mission" />
                    </h4>
                    <ul className="text-slate-600 leading-relaxed space-y-2 list-disc pl-5">
                      <li>Deliver high-precision financial and regulatory analysis of electricity costs.</li>
                      <li>Improve awareness of tariff structures and contract demand optimization.</li>
                      <li>Support data-driven decisions for renewable energy and open access.</li>
                      <li>Build long-term relationships based on independent, vendor-neutral advisory.</li>
                    </ul>
                  </div>
                  <div className="bg-white p-10 rounded-3xl shadow-sm border border-slate-100">
                    <h4 className="text-xl font-bold text-emerald-600 mb-4 uppercase tracking-wider">
                      <EditableContent id="app_about_vision_title" defaultValue="Vision" />
                    </h4>
                    <p className="text-slate-600 leading-relaxed">
                      <EditableContent id="app_about_vision_desc" defaultValue="To build a multi-state advisory platform that empowers industrial decision-makers with the intelligence needed to manage electricity as a strategic financial asset." multiline />
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <CompanyJourney />
          </div>
        );
      case 'services':
        return (
          <div className="pt-20">
            <ServicesSection />
            <div className="py-24 bg-white">
              <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <div className="grid lg:grid-cols-2 gap-16 items-center">
                  <div className="rounded-3xl overflow-hidden shadow-2xl aspect-video">
                    <EditableImage 
                      id="app_services_tech_image"
                      defaultUrl="https://images.unsplash.com/photo-1504384308090-c894fdcc538d?auto=format&fit=crop&q=80&w=1000" 
                      alt="Advanced monitoring systems" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="text-3xl font-bold text-slate-900 mb-6">
                      <EditableContent id="app_services_tech_title" defaultValue="Strategic Cost Risk Management" />
                    </h3>
                    <p className="text-slate-600 mb-8 leading-relaxed">
                      <EditableContent id="app_services_tech_desc" defaultValue="We don't just provide consulting; we integrate financial modeling with regulatory intelligence to give you a clear roadmap for electricity cost optimization." multiline />
                    </p>
                    <ul className="space-y-4">
                      <li className="flex items-center gap-3 font-semibold text-slate-800">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                        <EditableContent id="app_services_tech_i1" defaultValue="Forensic Billing Analysis" />
                      </li>
                      <li className="flex items-center gap-3 font-semibold text-slate-800">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                        <EditableContent id="app_services_tech_i2" defaultValue="Regulatory Risk Assessment" />
                      </li>
                      <li className="flex items-center gap-3 font-semibold text-slate-800">
                        <div className="w-2 h-2 bg-emerald-500 rounded-full" />
                        <EditableContent id="app_services_tech_i3" defaultValue="Independent Financial Modeling" />
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );
      case 'audits':
        return (
          <div className="pt-20">
            <AuditMethodology />
          </div>
        );
      case 'industries':
        return (
          <div className="pt-20">
            <IndustriesSection />
          </div>
        );
      case 'bill-audit':
        return (
          <div className="pt-20">
            <BillAudit />
          </div>
        );
      case 'visitors-data':
        return (
          <div className="pt-20">
            <VisitorsData />
          </div>
        );
      case 'contact':
        return (
          <div className="pt-20">
            <Contact />
          </div>
        );
      default:
        return <Hero setActivePage={setActivePage} />;
    }
  };

  return (
    <div className="min-h-screen bg-white font-sans text-slate-900 selection:bg-emerald-100 selection:text-emerald-900">
      <Toaster position="bottom-right" theme="dark" />
      <Navbar activePage={activePage} setActivePage={setActivePage} />
      <EditToggle />
      
      {/* Sidebar Toggle (Admin only) */}
      {isEditMode && isAdmin && (
        <div className="fixed top-44 left-8 z-50">
          <button
            onClick={toggleSocial}
            className="flex items-center gap-2 px-4 py-2 bg-slate-900/80 backdrop-blur-md border border-white/10 rounded-xl text-white text-xs font-bold hover:bg-white/10 transition-all shadow-xl"
          >
            <Share2 className="w-4 h-4 text-emerald-400" />
            {showSocial ? 'Hide Social Sidebar' : 'Show Social Sidebar'}
          </button>
        </div>
      )}

      {showSocial && <SocialSidebar />}
      <main>
        <AnimatePresence mode="wait">
          <motion.div
            key={activePage}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.3 }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>

      <Footer setActivePage={setActivePage} />
    </div>
  );
}

export default function App() {
  return (
    <EditProvider>
      <AppContent />
    </EditProvider>
  );
}
