import React from 'react';
import { motion } from 'motion/react';
import { Info, Target, TrendingUp, ShieldCheck, Cpu, BarChart3, Users } from 'lucide-react';
import { EditableContent } from './EditableContent';

export default function CompanyJourney() {
  const phases = [
    {
      id: 'phase_1',
      title: 'Phase 1',
      subtitle: 'Analytical Framework Setup',
      status: 'Completed'
    },
    {
      id: 'phase_2',
      title: 'Phase 2',
      subtitle: 'Multi-State Regulatory Mapping',
      status: 'In Progress'
    },
    {
      id: 'phase_3',
      title: 'Phase 3',
      subtitle: 'Formal Incorporation & Expansion',
      status: 'Planned'
    },
    {
      id: 'phase_4',
      title: 'Phase 4',
      subtitle: 'National Advisory Platform',
      status: 'Planned'
    }
  ];

  const trustPoints = [
    { id: 'trust_1', title: 'Finance-Driven Analysis', icon: Cpu },
    { id: 'trust_2', title: 'Independent Advisory', icon: BarChart3 },
    { id: 'trust_3', title: 'Regulatory Intelligence', icon: Target },
    { id: 'trust_4', title: 'Strategic Risk Management', icon: Users }
  ];

  return (
    <section className="py-24 bg-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="relative p-8 md:p-12 rounded-3xl bg-gradient-to-br from-slate-50 to-white border-l-4 border-emerald-500 shadow-sm overflow-hidden"
        >
          {/* Background Decoration */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
          
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-8">
              <div className="p-2 bg-emerald-100 rounded-lg">
                <TrendingUp className="w-5 h-5 text-emerald-600" />
              </div>
              <h2 className="text-2xl font-bold text-slate-900 tracking-tight">
                <EditableContent id="journey_title" defaultValue="VPESCO Development Roadmap" />
              </h2>
            </div>

            <div className="grid lg:grid-cols-12 gap-12">
              <div className="lg:col-span-7 space-y-6">
                <div className="prose prose-slate max-w-none">
                  <EditableContent 
                    as="p" 
                    id="journey_p1" 
                    defaultValue="Vishnu Priya Energy Solutions & Services (VPESCO) is a specialized advisory platform focused on industrial electricity cost optimization, tariff intelligence, and regulatory analysis." 
                    className="text-lg text-slate-700 leading-relaxed font-medium"
                    multiline 
                  />
                  <EditableContent 
                    as="p" 
                    id="journey_p2" 
                    defaultValue="We operate at the intersection of Finance, Regulation, and Energy Engineering, providing boardroom-level cost intelligence to industrial decision-makers." 
                    className="text-slate-600 leading-relaxed"
                    multiline 
                  />
                  <EditableContent 
                    as="p" 
                    id="journey_p3" 
                    defaultValue="VPESCO is currently under incorporation, building a strong foundation of analytical excellence and multi-state regulatory expertise." 
                    className="text-slate-600 leading-relaxed"
                    multiline 
                  />
                  <EditableContent 
                    as="p" 
                    id="journey_p4" 
                    defaultValue="Our roadmap is focused on becoming the leading independent advisor for electricity cost risk management across India's industrial hubs." 
                    className="text-slate-600 leading-relaxed font-semibold text-emerald-700"
                    multiline 
                  />
                  <EditableContent 
                    as="p" 
                    id="journey_p5" 
                    defaultValue="We prioritize measurable financial results, independent advisory, and long-term client partnerships over equipment sales." 
                    className="text-slate-600 leading-relaxed"
                    multiline 
                  />
                </div>

                <div className="grid grid-cols-2 gap-4 pt-6">
                  {trustPoints.map((point, i) => (
                    <div key={i} className="flex items-center gap-3 p-4 rounded-xl bg-white border border-slate-100 shadow-sm group hover:border-emerald-200 transition-colors">
                      <point.icon className="w-4 h-4 text-emerald-500" />
                      <span className="text-xs font-bold text-slate-800 tracking-tight">
                        <EditableContent id={point.id} defaultValue={point.title} />
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="lg:col-span-5">
                <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm h-full">
                  <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest mb-8">
                    <EditableContent id="roadmap_title" defaultValue="Growth Roadmap" />
                  </h3>
                  <div className="space-y-8 relative">
                    {/* Timeline Line */}
                    <div className="absolute left-[11px] top-2 bottom-2 w-0.5 bg-slate-100" />
                    
                    {phases.map((phase, i) => (
                      <div key={i} className="relative flex gap-6">
                        <div className={`w-6 h-6 rounded-full border-4 border-white shadow-sm z-10 shrink-0 ${
                          phase.status === 'Completed' ? 'bg-emerald-500' : 
                          phase.status === 'In Progress' ? 'bg-amber-400' : 'bg-slate-200'
                        }`} />
                        <div>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none mb-1">
                            <EditableContent id={`${phase.id}_title`} defaultValue={phase.title} />
                          </p>
                          <p className="text-sm font-bold text-slate-800 leading-tight">
                            <EditableContent id={`${phase.id}_subtitle`} defaultValue={phase.subtitle} />
                          </p>
                          <p className={`text-[10px] font-bold mt-1 ${
                            phase.status === 'Completed' ? 'text-emerald-600' : 
                            phase.status === 'In Progress' ? 'text-amber-600' : 'text-slate-400'
                          }`}>
                            <EditableContent id={`${phase.id}_status`} defaultValue={phase.status} />
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-12 pt-8 border-t border-slate-100">
              <div className="flex items-center gap-2 text-slate-400">
                <ShieldCheck className="w-4 h-4" />
                <p className="text-[11px] font-medium tracking-wide">
                  <span className="font-bold text-slate-500">Business Status:</span> 
                  <EditableContent id="business_status_note" defaultValue="VPESCO is currently under incorporation. Formal business registration is aligned with our upcoming expansion phase." />
                </p>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
