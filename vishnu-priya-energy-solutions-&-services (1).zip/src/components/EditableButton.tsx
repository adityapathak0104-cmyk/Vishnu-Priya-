import React, { useState } from 'react';
import { useEdit } from '../context/EditContext';
import { Edit2, ExternalLink, Save, X } from 'lucide-react';

interface EditableButtonProps {
  id: string;
  defaultText: string;
  defaultUrl: string;
  className?: string;
  icon?: React.ElementType;
}

export const EditableButton: React.FC<EditableButtonProps> = ({
  id,
  defaultText,
  defaultUrl,
  className = "",
  icon: Icon
}) => {
  const { isEditMode, getContent, setContent, isAdmin } = useEdit();
  const [isEditing, setIsEditing] = useState(false);
  const [text, setText] = useState(getContent(`${id}_text`, defaultText));
  const [url, setUrl] = useState(getContent(`${id}_url`, defaultUrl));

  const savedText = getContent(`${id}_text`, defaultText);
  const savedUrl = getContent(`${id}_url`, defaultUrl);

  const handleSave = async () => {
    await Promise.all([
      setContent(`${id}_text`, text),
      setContent(`${id}_url`, url)
    ]);
    setIsEditing(false);
  };

  if (isEditMode && isEditing) {
    return (
      <div className="relative inline-flex flex-col gap-2 p-4 bg-slate-900/90 backdrop-blur-xl border border-emerald-500/50 rounded-2xl z-50 shadow-2xl min-w-[240px]">
        <div className="space-y-3">
          <div>
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1 block">Button Text</label>
            <input
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:border-emerald-500 outline-none"
              placeholder="Button Text"
            />
          </div>
          <div>
            <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1 block">Button URL</label>
            <input
              type="text"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              className="w-full bg-slate-800 border border-white/10 rounded-lg px-3 py-2 text-white text-sm focus:border-emerald-500 outline-none"
              placeholder="https://..."
            />
          </div>
        </div>
        <div className="flex gap-2 mt-2">
          <button
            onClick={handleSave}
            className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors"
          >
            <Save className="w-3 h-3" /> Save
          </button>
          <button
            onClick={() => setIsEditing(false)}
            className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors"
          >
            <X className="w-3 h-3" /> Cancel
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative group/btn inline-block">
      <a
        href={savedUrl}
        className={`${className} flex items-center justify-center gap-2`}
        onClick={(e) => {
          if (isEditMode) e.preventDefault();
        }}
      >
        {Icon && <Icon className="w-5 h-5" />}
        {savedText}
      </a>

      {isEditMode && isAdmin && (
        <button
          onClick={() => {
            setText(savedText);
            setUrl(savedUrl);
            setIsEditing(true);
          }}
          className="absolute -top-2 -right-2 w-8 h-8 bg-emerald-500 text-white rounded-full flex items-center justify-center shadow-lg hover:bg-emerald-400 transition-all z-20 scale-0 group-hover/btn:scale-100"
          title="Edit Button & Link"
        >
          <Edit2 className="w-4 h-4" />
        </button>
      )}
    </div>
  );
};
