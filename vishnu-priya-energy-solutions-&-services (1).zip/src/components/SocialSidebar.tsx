import React from 'react';
import { Facebook, Twitter, Linkedin, Instagram, Share2 } from 'lucide-react';
import { motion } from 'motion/react';
import { EditableSocialIcon } from './EditableSocialIcon';

interface SocialLink {
  id: string;
  icon: any;
  label: string;
  defaultUrl: string;
  color: string;
}

const SOCIAL_LINKS: SocialLink[] = [
  { id: 'facebook', icon: Facebook, label: 'Facebook', defaultUrl: 'https://facebook.com', color: 'hover:bg-[#1877F2]' },
  { id: 'twitter', icon: Twitter, label: 'Twitter', defaultUrl: 'https://twitter.com', color: 'hover:bg-[#1DA1F2]' },
  { id: 'linkedin', icon: Linkedin, label: 'LinkedIn', defaultUrl: 'https://linkedin.com', color: 'hover:bg-[#0A66C2]' },
  { id: 'instagram', icon: Instagram, label: 'Instagram', defaultUrl: 'https://instagram.com', color: 'hover:bg-[#E4405F]' },
];

export default function SocialSidebar() {
  return (
    <div className="fixed right-0 top-1/2 -translate-y-1/2 z-[60] flex flex-col items-end gap-2 pr-4 pointer-events-none">
      <div className="flex flex-col gap-2 pointer-events-auto">
        {SOCIAL_LINKS.map((social, index) => (
          <motion.div
            key={social.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: index * 0.1 }}
            className="relative group flex items-center justify-end"
          >
            <EditableSocialIcon
              id={social.id}
              icon={social.icon}
              label={social.label}
              defaultUrl={social.defaultUrl}
              className={`w-12 h-12 rounded-2xl bg-slate-900/80 backdrop-blur-xl border border-white/10 flex items-center justify-center text-white transition-all shadow-xl group-hover:scale-110 group-hover:shadow-emerald-500/20 ${social.color}`}
            />
            
            {/* Tooltip */}
            <span className="absolute right-14 px-3 py-1.5 rounded-lg bg-slate-900 text-white text-xs font-bold opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none whitespace-nowrap border border-white/5 shadow-xl">
              {social.label}
            </span>
          </motion.div>
        ))}
      </div>
      
      {/* Share Button */}
      <motion.button
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ delay: 0.5 }}
        onClick={() => {
          if (navigator.share) {
            navigator.share({
              title: 'VPESCO - Energy Solutions',
              url: window.location.href
            });
          } else {
            navigator.clipboard.writeText(window.location.href);
            alert('Link copied to clipboard!');
          }
        }}
        className="w-12 h-12 rounded-full bg-emerald-600 text-white flex items-center justify-center shadow-[0_0_20px_rgba(16,185,129,0.4)] hover:bg-emerald-500 transition-all mt-4 pointer-events-auto hover:scale-110 active:scale-95"
      >
        <Share2 className="w-5 h-5" />
      </motion.button>
    </div>
  );
}

