import React, { useState, useEffect, useRef } from 'react';
import { useEdit } from '../context/EditContext';
import { Edit2, Check, X } from 'lucide-react';

interface EditableContentProps {
  id: string;
  defaultValue: string;
  as?: 'h1' | 'h2' | 'h3' | 'h4' | 'p' | 'span' | 'div';
  className?: string;
  multiline?: boolean;
}

export const EditableContent: React.FC<EditableContentProps> = ({ 
  id, 
  defaultValue, 
  as: Component = 'span', 
  className = '',
  multiline = false
}) => {
  const { isEditMode, getContent, setContent, isAdmin, highlightMode } = useEdit();
  const [isEditing, setIsEditing] = useState(false);
  const [tempValue, setTempValue] = useState('');
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);

  const currentContent = getContent(id, defaultValue);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isEditing]);

  const handleStartEdit = (e: React.MouseEvent) => {
    if (!isEditMode || !isAdmin) return;
    e.stopPropagation();
    setTempValue(currentContent);
    setIsEditing(true);
  };

  const handleSave = async () => {
    if (!isAdmin) return;
    await setContent(id, tempValue);
    setIsEditing(false);
  };

  const handleCancel = () => {
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !multiline) {
      handleSave();
    }
    if (e.key === 'Escape') {
      handleCancel();
    }
  };

  if (isEditing) {
    return (
      <span className="relative inline-block w-full group/edit">
        {multiline ? (
          <textarea
            ref={inputRef as React.RefObject<HTMLTextAreaElement>}
            value={tempValue}
            onChange={(e) => setTempValue(e.target.value)}
            onKeyDown={handleKeyDown}
            className={`w-full bg-slate-800 text-white border-2 border-emerald-500 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-emerald-400/50 ${className}`}
            rows={4}
          />
        ) : (
          <input
            ref={inputRef as React.RefObject<HTMLInputElement>}
            type="text"
            value={tempValue}
            onChange={(e) => setTempValue(e.target.value)}
            onKeyDown={handleKeyDown}
            className={`w-full bg-slate-800 text-white border-2 border-emerald-500 rounded-lg px-3 py-1 focus:outline-none focus:ring-2 focus:ring-emerald-400/50 ${className}`}
          />
        )}
        <span className="absolute top-full right-0 mt-2 flex gap-2 z-50">
          <button 
            onClick={handleSave}
            className="p-2 bg-emerald-500 text-white rounded-full hover:bg-emerald-400 shadow-lg"
            title="Save"
          >
            <Check className="w-4 h-4" />
          </button>
          <button 
            onClick={handleCancel}
            className="p-2 bg-slate-700 text-white rounded-full hover:bg-slate-600 shadow-lg"
            title="Cancel"
          >
            <X className="w-4 h-4" />
          </button>
        </span>
      </span>
    );
  }

  return (
    <Component 
      className={`relative ${className} ${isEditMode ? 'cursor-pointer hover:bg-emerald-500/10 rounded px-1 transition-colors border border-transparent hover:border-emerald-500/30 group/view' : ''} ${highlightMode && isEditMode ? 'bg-emerald-500/10 border-emerald-500/50' : ''}`}
      onClick={handleStartEdit}
    >
      {currentContent}
      {isEditMode && (
        <span className="absolute -top-3 -right-3 opacity-0 group-hover/view:opacity-100 transition-opacity bg-emerald-500 text-white p-1 rounded-full shadow-lg z-10">
          <Edit2 className="w-3 h-3" />
        </span>
      )}
    </Component>
  );
};
