import React from 'react';
import { Mail, Phone, MapPin, Facebook, Twitter, Linkedin, Instagram, Zap, Lock, Users } from 'lucide-react';
import { Logo } from './Navbar';
import { EditableContent } from './EditableContent';
import { useEdit } from '../context/EditContext';
import { EditableSocialIcon } from './EditableSocialIcon';

interface FooterProps {
  setActivePage?: (page: string) => void;
}

export default function Footer({ setActivePage }: FooterProps) {
  const { getContent, login, isAdmin } = useEdit();
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-white pt-24 pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="space-y-6">
            <button onClick={() => window.scrollTo(0, 0)} className="block">
              <Logo light />
            </button>
            <div className="text-slate-400 leading-relaxed font-serif italic text-sm">
              <EditableContent id="footer_about" defaultValue="Vishnu Priya Energy Solutions & Services (VPESCO) is a specialized advisory platform focused on industrial electricity cost optimization, tariff intelligence, and regulatory analysis." multiline />
            </div>
            <div className="flex items-center gap-4">
              <EditableSocialIcon 
                id="facebook" 
                icon={Facebook} 
                label="Facebook" 
                defaultUrl="https://facebook.com" 
                className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-emerald-600 transition-all"
              />
              <EditableSocialIcon 
                id="twitter" 
                icon={Twitter} 
                label="Twitter" 
                defaultUrl="https://twitter.com" 
                className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-emerald-600 transition-all"
              />
              <EditableSocialIcon 
                id="linkedin" 
                icon={Linkedin} 
                label="LinkedIn" 
                defaultUrl="https://linkedin.com" 
                className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-emerald-600 transition-all"
              />
              <EditableSocialIcon 
                id="instagram" 
                icon={Instagram} 
                label="Instagram" 
                defaultUrl="https://instagram.com" 
                className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-emerald-600 transition-all"
              />
            </div>
            
            <div className="pt-6 space-y-3 border-t border-slate-800">
              <h4 className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 mb-4">Admin Access</h4>
              <div className="flex flex-col gap-3">
                <a 
                  href="/vpesco-admin.html" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-[10px] font-bold text-slate-400 hover:text-emerald-500 transition-colors uppercase tracking-widest"
                >
                  <Lock className="w-3 h-3" />
                  Admin Dashboard
                </a>

                {isAdmin && setActivePage && (
                  <button 
                    onClick={() => setActivePage('visitors-data')}
                    className="inline-flex items-center gap-2 text-[10px] font-bold text-slate-400 hover:text-emerald-500 transition-colors uppercase tracking-widest"
                  >
                    <Users className="w-3 h-3" />
                    Visitors Data
                  </button>
                )}
                
                <button 
                  onClick={login}
                  className="inline-flex items-center gap-2 text-[10px] font-bold text-slate-400 hover:text-emerald-500 transition-colors uppercase tracking-widest"
                >
                  <Zap className="w-3 h-3" />
                  Login to Edit Website
                </button>
              </div>
            </div>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-8">
              <EditableContent id="footer_links_title" defaultValue="Quick Links" />
            </h3>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_link_home" defaultValue="Home" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_link_about" defaultValue="About Us" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_link_services" defaultValue="Services" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_link_audits" defaultValue="Audit Methodology" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_link_projects" defaultValue="Energy Intelligence" /></a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-8">
              <EditableContent id="footer_services_title" defaultValue="Services" />
            </h3>
            <ul className="space-y-4 text-slate-400">
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_service_1" defaultValue="Open Access Advisory" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_service_2" defaultValue="Energy Invoice Analysis" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_service_3" defaultValue="Regulatory Advisory" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_service_4" defaultValue="Power Procurement Strategy" /></a></li>
              <li><a href="#" className="hover:text-emerald-500 transition-colors"><EditableContent id="footer_service_5" defaultValue="Cost Optimization" /></a></li>
            </ul>
          </div>

          <div>
            <h3 className="text-lg font-bold mb-8">
              <EditableContent id="footer_contact_title" defaultValue="Contact Us" />
            </h3>
            <ul className="space-y-6 text-slate-400">
              <li className="flex items-start gap-4">
                <MapPin className="w-6 h-6 text-emerald-500 shrink-0" />
                <span><EditableContent id="footer_address" defaultValue="123 Energy Plaza, Industrial Area, Hyderabad, India" multiline /></span>
              </li>
              <li className="flex items-center gap-4">
                <Phone className="w-6 h-6 text-emerald-500 shrink-0" />
                <span><EditableContent id="footer_phone" defaultValue="+91 123 456 7890" /></span>
              </li>
              <li className="flex items-center gap-4">
                <Mail className="w-6 h-6 text-emerald-500 shrink-0" />
                <span><EditableContent id="footer_email" defaultValue="info@vpesc.in" /></span>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-12 border-t border-slate-800 flex flex-col md:row justify-between items-center gap-6 text-slate-500 text-sm">
          <p>© {currentYear} <EditableContent id="footer_copyright" defaultValue="Vishnu Priya Energy Solutions & Services (VPESCO). All rights reserved." /></p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white transition-colors"><EditableContent id="footer_privacy" defaultValue="Privacy Policy" /></a>
            <a href="#" className="hover:text-white transition-colors"><EditableContent id="footer_terms" defaultValue="Terms of Service" /></a>
            <a href="#" className="hover:text-white transition-colors"><EditableContent id="footer_cookie" defaultValue="Cookie Policy" /></a>
          </div>
        </div>
      </div>
    </footer>
  );
}
