import React, { useState, useRef, useEffect } from 'react';
import { 
  Upload, 
  FileText, 
  AlertCircle, 
  CheckCircle, 
  TrendingDown, 
  Zap, 
  BarChart3, 
  PieChart, 
  Loader2, 
  Download, 
  ArrowRight, 
  Copy, 
  ExternalLink,
  Share2
} from 'lucide-react';
import { GoogleGenAI } from "@google/genai";
import { motion, AnimatePresence } from 'motion/react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart as RePieChart, Pie } from 'recharts';
import { toast } from 'sonner';

import { useEdit } from '../context/EditContext';
import { db } from '../firebase';
import { doc, setDoc, getDoc, serverTimestamp, collection, addDoc } from 'firebase/firestore';

const SYSTEM_INSTRUCTION = `ROLE: Energy Audit AI Orchestrator & CFO Dashboard Generator

OBJECTIVE:
Perform a forensic electricity bill audit and identify cost-saving opportunities for industrial and commercial consumers.

INPUT:
- Electricity Bill Data (Image/PDF)
- Visitor Provided Location: [Passed in prompt]
- State: [Extracted from bill or provided location]
- Industry: [Extracted from bill]
- Voltage Level: [LT/HT/EHT - Extracted from bill]

TASK PIPELINE:
1. Analyze input electricity bill data (OCR & Extraction).
2. Use the provided "Visitor Location" to determine the specific Indian State (e.g., Maharashtra, Gujarat, Tamil Nadu).
3. Apply State-Specific Electricity Regulations (SERC/CERC):
   - Use specific tariff structures for that state.
   - Consider state-specific Open Access rules (Additional Surcharge, Cross Subsidy Surcharge).
   - Check for state-specific rebates (e.g., Power Factor incentives, Night usage rebates).
4. Categorize the consumer correctly:
   - Industrial (Continuous/Non-continuous)
   - Commercial
   - Domestic
   - Others (Public Water Works, Street Light, etc.)
5. Break into:
   - Tariff validation (SERC/CERC regulations)
   - Demand optimization (Contract Demand vs Actual)
   - Penalty analysis (Power Factor, Reactive Charges)
   - Open access feasibility (CSS, Wheeling, Transmission)
6. Perform deep forensic analysis to identify billing errors and inefficiencies.
7. Generate a CFO-level dashboard output.

OUTPUT MUST BE A VALID JSON OBJECT WITH THE FOLLOWING STRUCTURE:

{
  "status": "success",
  "utility_info": {
    "provider": "string",
    "consumer_number": "string",
    "billing_period": "string",
    "state": "string",
    "industry_type": "string",
    "voltage_level": "string"
  },
  "technical_data": {
    "units_kwh": 0,
    "billed_demand": 0,
    "power_factor": 0.0,
    "load_factor": 0.0,
    "contract_demand": 0
  },
  "financial_analysis": {
    "total_amount": 0,
    "pf_penalty": 0,
    "other_penalties": 0,
    "demand_charges": 0,
    "energy_charges": 0,
    "optimized_cost": 0,
    "savings_potential": 0
  },
  "audit_results": {
    "efficiency_score": 0, // 0-100
    "load_factor_category": "Poor/Average/Excellent",
    "is_leakage_detected": true/false,
    "risk_flags": ["string"]
  },
  "savings_opportunities": [
    {
      "action": "string",
      "savings_amount": 0,
      "effort": "Low/Medium/High",
      "priority": "Immediate/Medium-term/Strategic"
    }
  ],
  "recommendations": ["string"],
  "action_plan": {
    "immediate": ["string"],
    "medium_term": ["string"],
    "strategic": ["string"]
  }
}

SCORING LOGIC:
- Savings impact (40%)
- Compliance (30%)
- Efficiency (30%)

If data is missing, make conservative assumptions and clearly state them in recommendations.
Return ONLY the JSON object.`;

interface AuditResult {
  status: string;
  error?: string;
  utility_info: {
    provider: string;
    consumer_number: string;
    billing_period: string;
    state: string;
    industry_type: string;
    voltage_level: string;
  };
  technical_data: {
    units_kwh: number;
    billed_demand: number;
    power_factor: number;
    load_factor: number;
    contract_demand: number;
  };
  financial_analysis: {
    total_amount: number;
    pf_penalty: number;
    other_penalties: number;
    demand_charges: number;
    energy_charges: number;
    optimized_cost: number;
    savings_potential: number;
  };
  audit_results: {
    efficiency_score: number;
    load_factor_category: string;
    is_leakage_detected: boolean;
    risk_flags: string[];
  };
  savings_opportunities: {
    action: string;
    savings_amount: number;
    effort: string;
    priority: string;
  }[];
  recommendations: string[];
  action_plan: {
    immediate: string[];
    medium_term: string[];
    strategic: string[];
  };
}

function parseAIResponse(rawAIResponse: string): any {
  try {
    // 1. Remove Markdown code blocks (```json and ```) using Regex
    const jsonRegex = /({[\s\S]*})/;
    const match = rawAIResponse.match(jsonRegex);

    if (match && match[0]) {
      const cleanJsonString = match[0].trim();
      return JSON.parse(cleanJsonString);
    }

    // 2. If no backticks, try parsing the whole string after trimming
    return JSON.parse(rawAIResponse.trim());
  } catch (error: any) {
    console.error("Critical Parsing Error:", error);
    console.log("Raw Response was:", rawAIResponse);
    return {
      status: "error",
      message: "Data extraction failed. Please ensure the bill is legible.",
      technical_error: error.message
    };
  }
}

function PromptSection() {
  const [copied, setCopied] = useState(false);
  const promptText = `Role: You are a Senior Energy Consultant and Forensic Utility Auditor. Your goal is to find errors, hidden costs, and savings opportunities in this industrial/commercial electricity bill.
Task: Perform a deep-dive analysis of the attached bill and provide the following:
Executive Summary: A 3-sentence overview of the billing period, total cost, and the "Cost per kWh" (Total Bill ÷ Total kWh).
Data Extraction Table: Create a clean Markdown table with every line item found on the bill, including:
Energy Charges (On-Peak, Off-Peak, etc.)
Demand Charges (kW or kVA)
Fixed/Service Charges
Taxes and Regulatory Levies
Forensic Audit Check: Scan specifically for these red flags:
Power Factor Penalty: Check for "kVAR" or "Reactive Power" charges. Tell me if the Power Factor is below 0.90.
Demand Peaks: Is the "Peak Demand" unusually high compared to average usage?
Tariff Check: Does the rate category (e.g., TOU-8, Industrial-Medium) seem appropriate for the usage volume?
Actionable Savings Plan: List 3 specific ways this business can reduce this bill next month (e.g., shifting loads, installing capacitors for power factor, or disputing a specific charge).
Constraint: If any data is blurry or missing, note it as "Unable to verify." Use professional, technical language.`;

  const handleCopy = () => {
    navigator.clipboard.writeText(promptText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="mt-24 max-w-5xl mx-auto">
      <div className="bg-slate-900 rounded-[3rem] p-10 md:p-16 text-white relative overflow-hidden shadow-2xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2" />
        
        <div className="relative z-10">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
            <div>
              <h3 className="text-3xl font-bold mb-3 tracking-tight">The "Forensic Audit" Prompt</h3>
              <p className="text-slate-400 text-lg">Use this advanced prompt with Gemini 3.1 Pro for manual deep-dives.</p>
            </div>
            <button 
              onClick={handleCopy}
              className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold text-sm transition-all shrink-0 ${
                copied ? 'bg-emerald-500 text-white' : 'bg-white/10 text-white hover:bg-white/20 border border-white/10'
              }`}
            >
              {copied ? <CheckCircle className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? 'Copied to Clipboard' : 'Copy Prompt'}
            </button>
          </div>

          <div className="bg-black/40 rounded-2xl p-8 font-mono text-sm text-emerald-100/80 leading-relaxed border border-white/5 mb-12 whitespace-pre-wrap">
            {promptText}
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h4 className="text-emerald-400 font-bold uppercase tracking-widest text-xs mb-6">Why this works better</h4>
              <ul className="space-y-6">
                <li className="flex gap-4">
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  </div>
                  <div>
                    <p className="font-bold text-white mb-1 text-sm">Contextual Intelligence</p>
                    <p className="text-slate-400 text-xs leading-relaxed">Unlike automated tools, Gemini understands that a high "Demand Charge" often means machines were all turned on at once.</p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  </div>
                  <div>
                    <p className="font-bold text-white mb-1 text-sm">Math Capabilities</p>
                    <p className="text-slate-400 text-xs leading-relaxed">It calculates your "Effective Rate" (total cost divided by usage), helping you compare your bill to market averages.</p>
                  </div>
                </li>
                <li className="flex gap-4">
                  <div className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center shrink-0">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  </div>
                  <div>
                    <p className="font-bold text-white mb-1 text-sm">Visual Reading</p>
                    <p className="text-slate-400 text-xs leading-relaxed">Gemini 3.1 Pro can "see" usage graphs and identify exactly when you are wasting the most money.</p>
                  </div>
                </li>
              </ul>
            </div>

            <div className="bg-white/5 rounded-3xl p-8 border border-white/10">
              <h4 className="text-blue-400 font-bold uppercase tracking-widest text-xs mb-6">Pro-Tip for AI Studio</h4>
              <div className="space-y-6">
                <div>
                  <p className="font-bold text-white mb-2 text-sm">Use the "Gemini 3.1 Pro" model</p>
                  <p className="text-slate-400 text-xs leading-relaxed">Ensure "Gemini 3.1 Pro" is selected in AI Studio. It is much better at reading complex documents than the "Flash" model.</p>
                </div>
                <div>
                  <p className="font-bold text-white mb-2 text-sm">Upload multiple bills</p>
                  <p className="text-slate-400 text-xs leading-relaxed">Upload bills from the last 3 months at once! Then ask: "Compare these 3 months and tell me why my costs are trending up."</p>
                </div>
                <a 
                  href="https://aistudio.google.com/" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-emerald-400 font-bold text-sm hover:text-emerald-300 transition-colors pt-4"
                >
                  Open Google AI Studio <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function BillAudit() {
  const { isAdmin } = useEdit();
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<AuditResult | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [email, setEmail] = useState('');
  const [location, setLocation] = useState('');
  const [uploadingToDrive, setUploadingToDrive] = useState(false);
  const [activeTab, setActiveTab] = useState<'summary' | 'details'>('summary');
  const [auditId, setAuditId] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Load audit from URL if present
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const id = params.get('auditId');
    if (id) {
      loadAudit(id);
    }
  }, []);

  const loadAudit = async (id: string) => {
    try {
      setLoading(true);
      const docRef = doc(db, 'audits', id);
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        setResult(docSnap.data() as AuditResult);
        setAuditId(id);
      } else {
        toast.error("Audit not found");
      }
    } catch (error) {
      console.error("Error loading audit:", error);
      toast.error("Failed to load audit");
    } finally {
      setLoading(false);
    }
  };

  const saveAudit = async (data: AuditResult) => {
    if (!isAdmin) return;
    try {
      const id = auditId || Math.random().toString(36).substring(2, 15);
      await setDoc(doc(db, 'audits', id), {
        ...data,
        updatedAt: serverTimestamp()
      });
      setAuditId(id);
      
      // Update URL without refreshing
      const newUrl = new URL(window.location.href);
      newUrl.searchParams.set('auditId', id);
      window.history.pushState({}, '', newUrl);
      
      toast.success("Audit saved successfully");
    } catch (error) {
      console.error("Error saving audit:", error);
      toast.error("Failed to save audit");
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
      setError(null);
    }
  };

  const handleEditChange = (path: string, value: any) => {
    if (!result) return;
    const newResult = { ...result };
    const keys = path.split('.');
    let current: any = newResult;
    for (let i = 0; i < keys.length - 1; i++) {
      current = current[keys[i]];
    }
    current[keys[keys.length - 1]] = value;

    // Recalculate derived fields if necessary
    if (path.includes('technical_data') || path.includes('financial_analysis')) {
      const { units_kwh, billed_demand, power_factor } = newResult.technical_data;
      const loadFactor = units_kwh / (billed_demand * 30 * 24);
      newResult.technical_data.load_factor = isFinite(loadFactor) ? loadFactor : 0;
      
      newResult.audit_results.load_factor_category = 
        newResult.technical_data.load_factor > 0.75 ? 'Excellent' : 
        newResult.technical_data.load_factor > 0.5 ? 'Average' : 'Poor';
      
      const pfPenalty = power_factor < 0.95 ? (0.95 - power_factor) * 100 * (newResult.financial_analysis.energy_charges * 0.01) : 0;
      newResult.financial_analysis.pf_penalty = pfPenalty;
      
      newResult.financial_analysis.savings_potential = (newResult.financial_analysis.pf_penalty + newResult.financial_analysis.other_penalties) * 12;
      newResult.financial_analysis.optimized_cost = newResult.financial_analysis.total_amount - (newResult.financial_analysis.savings_potential / 12);
      
      // Update efficiency score based on load factor and power factor
      const lfScore = Math.min(newResult.technical_data.load_factor * 100, 100);
      const pfScore = Math.min(newResult.technical_data.power_factor * 100, 100);
      newResult.audit_results.efficiency_score = Math.round((lfScore + pfScore) / 2);
    }

    setResult(newResult);
  };

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const base64String = (reader.result as string).split(',')[1];
        resolve(base64String);
      };
      reader.onerror = (error) => reject(error);
    });
  };

  const runAudit = async () => {
    if (!file) return;
    if (!email) {
      toast.error("Please enter your email to proceed");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const base64 = await fileToBase64(file);
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
      const model = ai.models.generateContent({
        model: "gemini-3.1-pro-preview",
        contents: [
          {
            parts: [
              { text: `Analyze this bill. Visitor Location: ${location}. Use this location to apply specific state regulations (Industrial/Commercial/Domestic) for a deep forensic audit. Provide the Audit Report in the requested JSON format.` },
              {
                inlineData: {
                  data: base64,
                  mimeType: file.type
                }
              }
            ]
          }
        ],
        config: {
          systemInstruction: SYSTEM_INSTRUCTION,
          responseMimeType: "application/json"
        }
      });

      const response = await model;
      const text = response.text;
      if (text) {
        const parsedResult = parseAIResponse(text);
        if (parsedResult.status === "success") {
          setResult(parsedResult as AuditResult);
          
          // Automatically upload to Google Drive after successful analysis
          await uploadToDrive(parsedResult as AuditResult);

          if (isAdmin) {
            await saveAudit(parsedResult as AuditResult);
          }
        } else if (parsedResult.error) {
          setError(parsedResult.error);
        } else {
          setError(parsedResult.message || "Failed to analyze the bill. Please ensure the file is a clear image or PDF of an electricity bill.");
        }
      } else {
        throw new Error("Empty response from AI");
      }
    } catch (err: any) {
      console.error("Audit error:", err);
      setError("Failed to analyze the bill. Please ensure the file is a clear image or PDF of an electricity bill.");
    } finally {
      setLoading(false);
    }
  };

  const uploadToDrive = async (auditData: AuditResult) => {
    if (!file) return;
    
    setUploadingToDrive(true);
    const formData = new FormData();
    formData.append('bill', file);
    formData.append('email', email);
    formData.append('location', location);
    formData.append('clientName', auditData.utility_info.provider || 'Unknown Client');
    formData.append('auditData', JSON.stringify(auditData));

    try {
      const response = await fetch('/api/upload-bill', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();
      if (data.success) {
        toast.success("Bill securely saved to Google Drive and logged.");
        
        // Save to visitors_data collection in Firestore
        try {
          await addDoc(collection(db, 'visitor_submissions'), {
            email,
            location,
            clientName: auditData.utility_info.provider || 'Unknown Client',
            driveLink: data.link,
            auditData: auditData,
            timestamp: serverTimestamp()
          });
        } catch (fsError) {
          console.error("Error saving to Firestore visitor_submissions:", fsError);
        }
      } else {
        console.error("Drive upload failed:", data.error);
        toast.error("Analysis complete, but failed to save to Drive.");
      }
    } catch (err) {
      console.error("Error uploading to Drive:", err);
      toast.error("Analysis complete, but network error saving to Drive.");
    } finally {
      setUploadingToDrive(false);
    }
  };

  const resetAudit = () => {
    setFile(null);
    setResult(null);
    setError(null);
    setActiveTab('summary');
  };

  const downloadCSV = () => {
    if (!result) return;
    const rows = [
      ['Parameter', 'Current Value', 'Target', 'Impact'],
      ['Power Factor', result.technical_data.power_factor.toFixed(3), '0.950', result.financial_analysis.pf_penalty],
      ['Load Factor', `${(result.technical_data.load_factor * 100).toFixed(1)}%`, '> 75%', result.audit_results.demand_saving_opportunity],
      ['Contract Demand', result.technical_data.contract_demand || 0, 'Optimized', result.financial_analysis.demand_charges],
      ['Energy Consumption', result.technical_data.units_kwh, 'N/A', result.financial_analysis.energy_charges],
    ];

    const csvContent = "data:text/csv;charset=utf-8," 
      + rows.map(e => e.join(",")).join("\n");

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `audit_report_${result.utility_info.consumer_number}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        {!result && (
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-slate-900 mb-4 tracking-tight">Automated Electricity Bill Audit</h1>
            <p className="text-lg text-slate-600 max-w-2xl mx-auto">
              Upload your industrial or commercial electricity bill to receive an instant, AI-powered forensic audit and cost-saving analysis.
            </p>
          </div>
        )}

        {!result ? (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-3xl shadow-xl p-8 md:p-12 border border-slate-100 max-w-3xl mx-auto"
          >
            <div className="max-w-md mx-auto">
              <div 
                onClick={() => fileInputRef.current?.click()}
                className={`border-2 border-dashed rounded-2xl p-12 text-center cursor-pointer transition-all ${
                  file ? 'border-emerald-500 bg-emerald-50' : 'border-slate-200 hover:border-emerald-400 hover:bg-slate-50'
                }`}
              >
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileChange} 
                  className="hidden" 
                  accept="image/*,application/pdf"
                />
                <div className="flex flex-col items-center">
                  {file ? (
                    <>
                      <FileText className="w-16 h-16 text-emerald-500 mb-4" />
                      <p className="text-emerald-700 font-semibold mb-1">{file.name}</p>
                      <p className="text-emerald-600/60 text-sm">Click to change file</p>
                    </>
                  ) : (
                    <>
                      <Upload className="w-16 h-16 text-slate-300 mb-4" />
                      <p className="text-slate-900 font-semibold mb-1">Upload Bill (PDF or Image)</p>
                      <p className="text-slate-500 text-sm">Drag and drop or click to browse</p>
                    </>
                  )}
                </div>
              </div>

              <div className="mt-8 space-y-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Email Address (Required for report)</label>
                  <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your@email.com"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Business Location (Optional)</label>
                  <input 
                    type="text" 
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    placeholder="City, State"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all"
                  />
                </div>
              </div>

              {error && (
                <div className="mt-6 p-4 bg-red-50 border border-red-100 rounded-xl flex items-start gap-3 text-red-700 text-sm">
                  <AlertCircle className="w-5 h-5 shrink-0" />
                  <p>{error}</p>
                </div>
              )}

              <button
                onClick={runAudit}
                disabled={!file || loading}
                className={`w-full mt-8 py-4 rounded-xl font-bold text-lg transition-all flex items-center justify-center gap-3 ${
                  !file || loading 
                    ? 'bg-slate-100 text-slate-400 cursor-not-allowed' 
                    : 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-lg shadow-emerald-600/20'
                }`}
              >
                {loading ? (
                  <>
                    <Loader2 className="w-6 h-6 animate-spin" />
                    Analyzing Bill...
                  </>
                ) : (
                  <>
                    Analyze Bill Now
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex flex-col lg:flex-row gap-8"
          >
            {/* Sidebar Navigation */}
            <div className="lg:w-64 shrink-0 space-y-2">
              <div className="p-6 bg-slate-900 rounded-3xl mb-6">
                <div className="flex items-center gap-3 text-white mb-2">
                  <Zap className="w-5 h-5 text-emerald-400" />
                  <span className="font-bold text-sm">Vishnu Priya AI</span>
                </div>
                <p className="text-[10px] text-slate-400 uppercase tracking-widest font-bold">Audit Engine v2.4</p>
              </div>

              <button 
                onClick={() => setActiveTab('summary')}
                className={`w-full flex items-center gap-3 px-6 py-4 rounded-2xl font-bold text-sm transition-all ${
                  activeTab === 'summary' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20' : 'bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                <BarChart3 className="w-5 h-5" />
                CFO Dashboard
              </button>
              <button 
                onClick={() => setActiveTab('details')}
                className={`w-full flex items-center gap-3 px-6 py-4 rounded-2xl font-bold text-sm transition-all ${
                  activeTab === 'details' ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-600/20' : 'bg-white text-slate-600 hover:bg-slate-50'
                }`}
              >
                <PieChart className="w-5 h-5" />
                Detailed Analysis
              </button>
              
              <div className="pt-8">
                <button 
                  onClick={resetAudit}
                  className="w-full flex items-center gap-3 px-6 py-4 rounded-2xl font-bold text-sm bg-white text-slate-400 hover:text-red-500 hover:bg-red-50 transition-all border border-slate-100"
                >
                  <Upload className="w-5 h-5" />
                  Upload New Bill
                </button>
              </div>
            </div>

            {/* Main Content Area */}
            <div className="flex-grow space-y-8">
              {/* Top Header Bar */}
              <div className="bg-white rounded-3xl shadow-sm border border-slate-100 p-8 flex flex-col md:row justify-between items-center gap-6">
                <div>
                  <h2 className="text-2xl font-bold text-slate-900 mb-1">{result.utility_info.provider}</h2>
                  <div className="flex items-center gap-4 text-slate-500 text-sm">
                    <span className="flex items-center gap-1"><FileText className="w-4 h-4" /> {result.utility_info.consumer_number}</span>
                    <span className="flex items-center gap-1"><CheckCircle className="w-4 h-4" /> {result.utility_info.billing_period}</span>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Last Updated</p>
                    <p className="text-sm font-bold text-slate-900">{new Date().toLocaleDateString()} • {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</p>
                  </div>
                  <button 
                    onClick={() => {
                      const url = window.location.href;
                      navigator.clipboard.writeText(url);
                      toast.success("Share link copied to clipboard");
                    }}
                    className="flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold text-sm hover:bg-emerald-700 transition-all"
                  >
                    <Share2 className="w-4 h-4" />
                    Share Live Audit
                  </button>
                  <button 
                    onClick={() => {
                      const url = window.location.href;
                      navigator.clipboard.writeText(url);
                      toast.success("Share link copied to clipboard");
                    }}
                    className="flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold text-sm hover:bg-emerald-700 transition-all"
                  >
                    <Share2 className="w-4 h-4" />
                    Share Live Audit
                  </button>
                  <button 
                    onClick={downloadCSV}
                    className="flex items-center gap-2 px-6 py-3 bg-slate-900 text-white rounded-xl font-bold text-sm hover:bg-slate-800 transition-all"
                  >
                    <Download className="w-4 h-4" />
                    Download Audit Data (CSV)
                  </button>
                </div>
              </div>

              {activeTab === 'summary' ? (
                <div className="space-y-8">
                  {/* Executive Summary Section */}
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-2xl font-bold text-slate-900">Executive Summary: Energy Cost Optimization</h3>
                      <p className="text-slate-500">Audit findings identifying systemic wastage and financial recovery potential.</p>
                    </div>
                    <div className="px-4 py-2 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-emerald-100">
                      Immediate ROI Potential
                    </div>
                  </div>

                  {/* Summary Cards Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <SummaryCard 
                      label="Total Bill" 
                      value={`₹${result.financial_analysis.total_amount.toLocaleString()}`} 
                      subValue="Current Month"
                      icon={FileText}
                      color="blue"
                    />
                    <SummaryCard 
                      label="Savings Potential" 
                      value={`₹${result.financial_analysis.savings_potential.toLocaleString()}`} 
                      subValue={`${((result.financial_analysis.savings_potential / (result.financial_analysis.total_amount * 12)) * 100).toFixed(1)}% Potential`}
                      icon={TrendingDown}
                      color="emerald"
                    />
                    <SummaryCard 
                      label="Optimized Cost" 
                      value={`₹${Math.round(result.financial_analysis.optimized_cost).toLocaleString()}`} 
                      subValue="Target Monthly"
                      icon={Zap}
                      color="emerald"
                    />
                    <SummaryCard 
                      label="Efficiency Score" 
                      value={`${result.audit_results.efficiency_score}/100`} 
                      subValue={result.audit_results.load_factor_category}
                      icon={CheckCircle}
                      color={result.audit_results.efficiency_score > 80 ? 'emerald' : result.audit_results.efficiency_score > 50 ? 'amber' : 'blue'}
                    />
                  </div>

                  <div className="grid lg:grid-cols-3 gap-8">
                    {/* Savings Opportunities Table */}
                    <div className="lg:col-span-2 bg-white rounded-[2.5rem] p-10 shadow-sm border border-slate-100">
                      <div className="flex items-center justify-between mb-8">
                        <h4 className="text-xl font-bold text-slate-900">Savings Opportunities</h4>
                        <div className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-[10px] font-black uppercase tracking-widest border border-blue-100">
                          Prioritized Actions
                        </div>
                      </div>
                      <div className="overflow-x-auto">
                        <table className="w-full text-left">
                          <thead>
                            <tr className="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
                              <th className="pb-4">Action</th>
                              <th className="pb-4">Savings (₹)</th>
                              <th className="pb-4">Effort</th>
                              <th className="pb-4">Priority</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-50">
                            {result.savings_opportunities.map((opp, index) => (
                              <tr key={index} className="group">
                                <td className="py-4 text-sm font-bold text-slate-900">{opp.action}</td>
                                <td className="py-4 text-sm font-black text-emerald-600">₹{opp.savings_amount.toLocaleString()}</td>
                                <td className="py-4">
                                  <span className={`text-[10px] font-bold px-2 py-1 rounded-md ${
                                    opp.effort === 'Low' ? 'bg-emerald-50 text-emerald-600' : 
                                    opp.effort === 'Medium' ? 'bg-blue-50 text-blue-600' : 'bg-amber-50 text-amber-600'
                                  }`}>
                                    {opp.effort}
                                  </span>
                                </td>
                                <td className="py-4">
                                  <span className={`text-[10px] font-black tracking-widest ${
                                    opp.priority === 'Immediate' ? 'text-red-500' : 
                                    opp.priority === 'Medium-term' ? 'text-amber-500' : 'text-blue-500'
                                  }`}>
                                    {opp.priority}
                                  </span>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>

                    {/* Cost Breakdown Pie */}
                    <div className="bg-white rounded-[2.5rem] p-10 shadow-sm border border-slate-100">
                      <h4 className="text-xl font-bold text-slate-900 mb-8">Cost Breakdown</h4>
                      <div className="h-64 w-full mb-8">
                        <ResponsiveContainer width="100%" height="100%">
                          <RePieChart>
                            <Pie
                              data={[
                                { name: 'Energy Charges', value: result.financial_analysis.energy_charges },
                                { name: 'Fixed Charges', value: result.financial_analysis.demand_charges },
                                { name: 'Penalties', value: result.financial_analysis.pf_penalty + result.financial_analysis.other_penalties },
                                { name: 'Other', value: Math.max(0, result.financial_analysis.total_amount - (result.financial_analysis.energy_charges + result.financial_analysis.demand_charges + result.financial_analysis.pf_penalty + result.financial_analysis.other_penalties)) },
                              ]}
                              cx="50%"
                              cy="50%"
                              innerRadius={60}
                              outerRadius={80}
                              paddingAngle={5}
                              dataKey="value"
                            >
                              <Cell fill="#10b981" />
                              <Cell fill="#3b82f6" />
                              <Cell fill="#ef4444" />
                              <Cell fill="#94a3b8" />
                            </Pie>
                          </RePieChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="space-y-3">
                        <BreakdownItem label="Energy Charges" value={`₹${result.financial_analysis.energy_charges.toLocaleString()}`} color="bg-emerald-500" />
                        <BreakdownItem label="Fixed Charges" value={`₹${result.financial_analysis.demand_charges.toLocaleString()}`} color="bg-blue-500" />
                        <BreakdownItem label="Penalties" value={`₹${(result.financial_analysis.pf_penalty + result.financial_analysis.other_penalties).toLocaleString()}`} color="bg-red-500" />
                      </div>
                    </div>
                  </div>

                  <div className="grid lg:grid-cols-2 gap-8">
                    {/* Action Plan Section */}
                    <div className="bg-white rounded-[2.5rem] p-10 shadow-sm border border-slate-100">
                      <div className="flex items-center gap-3 mb-8">
                        <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                          <BarChart3 className="w-5 h-5" />
                        </div>
                        <h4 className="text-xl font-bold text-slate-900">Recommended Action Plan</h4>
                      </div>
                      <div className="space-y-6">
                        <ActionStep title="1. Immediate Actions" items={result.action_plan.immediate} color="red" />
                        <ActionStep title="2. Medium-term Strategy" items={result.action_plan.medium_term} color="amber" />
                        <ActionStep title="3. Strategic Long-term" items={result.action_plan.strategic} color="blue" />
                      </div>
                    </div>

                    {/* Risk Flags & Recommendations */}
                    <div className="bg-white rounded-[2.5rem] p-10 shadow-sm border border-slate-100">
                      <div className="flex items-center gap-3 mb-8">
                        <div className="w-10 h-10 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
                          <AlertCircle className="w-5 h-5" />
                        </div>
                        <h4 className="text-xl font-bold text-slate-900">Risk Flags & Issues</h4>
                      </div>
                      <div className="space-y-4 mb-8">
                        {result.audit_results.risk_flags.map((flag, index) => (
                          <div key={index} className="flex items-center gap-3 p-4 rounded-2xl bg-red-50 border border-red-100 text-red-700 text-sm font-bold">
                            <AlertCircle className="w-4 h-4 shrink-0" />
                            {flag}
                          </div>
                        ))}
                      </div>
                      <h4 className="text-sm font-black text-slate-400 uppercase tracking-widest mb-4">Key Recommendations</h4>
                      <div className="space-y-3">
                        {result.recommendations.slice(0, 3).map((rec, index) => (
                          <div key={index} className="flex items-start gap-3 text-sm text-slate-600">
                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                            {rec}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
                ) : (
                <div className="space-y-8">
                  {/* Detailed Calculations View */}
                  <div className="bg-white rounded-[2.5rem] shadow-sm border border-slate-100 overflow-hidden">
                    <div className="p-8 border-b border-slate-100 bg-slate-50/50">
                      <h3 className="text-xl font-bold text-slate-900">Detailed Forensic Audit Log</h3>
                      <p className="text-sm text-slate-500">Line-by-line analysis of billing parameters and detected inefficiencies.</p>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-left">
                        <thead>
                          <tr className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100">
                            <th className="px-8 py-4">Parameter</th>
                            <th className="px-8 py-4">Current Value</th>
                            <th className="px-8 py-4">Target / Benchmark</th>
                            <th className="px-8 py-4">Financial Impact</th>
                            <th className="px-8 py-4">Status</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-50">
                          <AuditRow 
                            label="Power Factor" 
                            value={result.technical_data.power_factor.toFixed(3)} 
                            target="0.950" 
                            impact={`₹${result.financial_analysis.pf_penalty.toLocaleString()}`}
                            status={result.technical_data.power_factor >= 0.95 ? 'OPTIMAL' : 'INEFFICIENT'}
                            isEditing={isEditing}
                            onEdit={(val) => handleEditChange('technical_data.power_factor', parseFloat(val))}
                          />
                          <AuditRow 
                            label="Load Factor" 
                            value={`${(result.technical_data.load_factor * 100).toFixed(1)}%`} 
                            target="> 75%" 
                            impact={`₹${Math.round(result.audit_results.demand_saving_opportunity).toLocaleString()}`}
                            status={result.technical_data.load_factor >= 0.75 ? 'OPTIMAL' : 'INEFFICIENT'}
                            isEditing={isEditing}
                            onEdit={(val) => handleEditChange('technical_data.load_factor', parseFloat(val) / 100)}
                          />
                          <AuditRow 
                            label="Contract Demand" 
                            value={`${result.technical_data.contract_demand || 0} kW`} 
                            target="Optimized" 
                            impact={`₹${result.financial_analysis.demand_charges.toLocaleString()}`}
                            status={result.technical_data.load_factor >= 0.6 ? 'OPTIMAL' : 'INEFFICIENT'}
                            isEditing={isEditing}
                            onEdit={(val) => handleEditChange('technical_data.contract_demand', parseFloat(val))}
                          />
                          <AuditRow 
                            label="Energy Consumption" 
                            value={`${result.technical_data.units_kwh.toLocaleString()} kWh`} 
                            target="N/A" 
                            impact={`₹${result.financial_analysis.energy_charges.toLocaleString()}`}
                            status="OPTIMAL"
                            isEditing={isEditing}
                            onEdit={(val) => handleEditChange('technical_data.units_kwh', parseFloat(val))}
                          />
                        </tbody>
                      </table>
                    </div>
                    <div className="p-8 bg-slate-900 text-white flex justify-between items-center">
                      <div className="flex gap-12">
                        <div>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Potential</p>
                          <p className="text-2xl font-black text-emerald-400">₹{result.financial_analysis.savings_potential.toLocaleString()}</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Avg Efficiency</p>
                          <p className="text-2xl font-black">{result.audit_results.efficiency_score}%</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        {isAdmin && (
                          <button 
                            onClick={async () => {
                              if (isEditing) {
                                await saveAudit(result!);
                              }
                              setIsEditing(!isEditing);
                            }}
                            className={`px-6 py-3 rounded-xl font-bold text-sm transition-all ${
                              isEditing ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-300 hover:text-white'
                            }`}
                          >
                            {isEditing ? 'Save Changes' : 'Edit Audit Data'}
                          </button>
                        )}
                        <div className="text-right">
                          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Audit Status</p>
                          <p className="text-sm font-bold uppercase tracking-widest text-emerald-400">Full Audit Period Complete</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Logic Cards */}
                  <div className="grid md:grid-cols-3 gap-6">
                    <LogicCard 
                      title="LF LOGIC"
                      desc="Imagine renting a 100-seat bus (Contract Demand). If you only put 15 people on it most of the time (Low Load Factor), your cost per passenger is huge. If you fill the bus to 50 or 60 seats consistently, the cost per passenger drops significantly."
                    />
                    <LogicCard 
                      title="PF PENALTY LOGIC"
                      desc="Low Power Factor is like foam on a beer. You pay for the whole glass, but you're only getting the liquid. The utility charges you for the foam (Reactive Power) because it clogs up their distribution lines."
                    />
                    <LogicCard 
                      title="TOD LOGIC"
                      desc="Electricity is like Uber—it has Surge Pricing. During Peak Hours (early morning or evening), the utility charges a massive premium. During Off-Peak Hours (night), they might give a discount."
                    />
                  </div>
                </div>
              )}
            </div>
          </motion.div>
        )}

        {!result && <PromptSection />}
      </div>
    </div>
  );
}

function ActionStep({ title, items, color }: { title: string, items: string[], color: 'red' | 'amber' | 'blue' }) {
  const colors = {
    red: 'text-red-600 bg-red-50',
    amber: 'text-amber-600 bg-amber-50',
    blue: 'text-blue-600 bg-blue-50'
  };

  return (
    <div>
      <h5 className={`text-xs font-black uppercase tracking-widest mb-3 px-3 py-1 rounded-md inline-block ${colors[color]}`}>{title}</h5>
      <ul className="space-y-2">
        {items.map((item, index) => (
          <li key={index} className="flex items-center gap-3 text-sm text-slate-600">
            <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${color === 'red' ? 'bg-red-500' : color === 'amber' ? 'bg-amber-500' : 'bg-blue-500'}`} />
            {item}
          </li>
        ))}
      </ul>
    </div>
  );
}

function SummaryCard({ label, value, subValue, icon: Icon, color }: { label: string, value: string, subValue: string, icon: any, color: 'emerald' | 'blue' | 'amber' }) {
  const colors = {
    emerald: 'bg-emerald-50 text-emerald-600',
    blue: 'bg-blue-50 text-blue-600',
    amber: 'bg-amber-50 text-amber-600'
  };

  return (
    <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 hover:shadow-md transition-all">
      <div className={`w-12 h-12 rounded-2xl ${colors[color]} flex items-center justify-center mb-6`}>
        <Icon className="w-6 h-6" />
      </div>
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">{label}</p>
      <p className="text-3xl font-black text-slate-900 mb-1">{value}</p>
      <p className="text-xs font-bold text-slate-400">{subValue}</p>
    </div>
  );
}

function BreakdownItem({ label, value, color }: { label: string, value: string, color: string }) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className={`w-3 h-3 rounded-full ${color}`} />
        <span className="text-xs font-bold text-slate-600">{label}</span>
      </div>
      <span className="text-xs font-black text-slate-900">{value}</span>
    </div>
  );
}

function AuditRow({ label, value, target, impact, status, isEditing, onEdit }: { label: string, value: string, target: string, impact: string, status: 'OPTIMAL' | 'INEFFICIENT', isEditing?: boolean, onEdit?: (val: string) => void }) {
  return (
    <tr className="hover:bg-slate-50 transition-colors">
      <td className="px-8 py-6 font-bold text-slate-900">{label}</td>
      <td className="px-8 py-6 text-slate-600 font-mono">
        {isEditing ? (
          <input 
            type="text" 
            defaultValue={value.replace(/[^0-9.]/g, '')} 
            onChange={(e) => onEdit?.(e.target.value)}
            className="w-24 px-2 py-1 border border-slate-200 rounded bg-white text-slate-900 focus:ring-2 focus:ring-emerald-500 outline-none"
          />
        ) : (
          value
        )}
      </td>
      <td className="px-8 py-6 text-slate-400 text-sm">{target}</td>
      <td className="px-8 py-6 font-black text-slate-900">{impact}</td>
      <td className="px-8 py-6">
        <span className={`px-3 py-1 rounded-md text-[10px] font-black tracking-widest ${status === 'OPTIMAL' ? 'bg-emerald-50 text-emerald-600' : 'bg-red-50 text-red-600'}`}>
          {status}
        </span>
      </td>
    </tr>
  );
}

function LogicCard({ title, desc }: { title: string, desc: string }) {
  return (
    <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
      <h5 className="text-[10px] font-black text-slate-300 uppercase tracking-[0.2em] mb-4">{title}</h5>
      <p className="text-xs text-slate-500 leading-relaxed italic">"{desc}"</p>
    </div>
  );
}

function MetricCard({ label, value, icon: Icon, status = 'default' }: { label: string, value: string | number, icon: any, status?: 'default' | 'success' | 'warning' | 'danger' }) {
  const statusColors = {
    default: 'text-slate-400',
    success: 'text-emerald-500',
    warning: 'text-amber-500',
    danger: 'text-red-500'
  };

  return (
    <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm">
      <div className={`mb-4 ${statusColors[status]}`}>
        <Icon className="w-6 h-6" />
      </div>
      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">{label}</p>
      <p className="text-xl font-bold text-slate-900">{value}</p>
    </div>
  );
}
