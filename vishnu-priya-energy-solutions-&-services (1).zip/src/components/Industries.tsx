import React from 'react';
import { Factory, Hospital, Building2, Database, Hotel, Landmark } from 'lucide-react';
import { motion } from 'motion/react';
import { EditableContent } from './EditableContent';
import { EditableImage } from './EditableImage';

export default function IndustriesSection() {
  const industries = [
    { id: 'ind_1', name: 'Industrial', icon: Factory, description: 'Manufacturing, Textiles, Cement, Steel' },
    { id: 'ind_2', name: 'Commercial', icon: Building2, description: 'Hotels, Hospitals, IT Parks, Malls' },
    { id: 'ind_3', name: 'Residential', icon: Landmark, description: 'Large townships and residential complexes' },
  ];

  return (
    <section className="py-24 bg-slate-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="text-emerald-600 font-bold uppercase tracking-widest text-sm mb-4">
            <EditableContent id="industries_tag" defaultValue="Sector Expertise" />
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
            <EditableContent id="industries_title" defaultValue="Industries We Serve" />
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            <EditableContent id="industries_description" defaultValue="VPESCO provides specialized energy optimization solutions across diverse sectors, ensuring maximum efficiency and sustainability." multiline />
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {industries.map((industry, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              className="bg-white p-10 rounded-[3rem] shadow-sm border border-slate-100 hover:shadow-xl hover:border-emerald-200 transition-all text-center group"
            >
              <div className="w-20 h-20 bg-emerald-50 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-8 transition-transform group-hover:scale-110 group-hover:bg-emerald-600 group-hover:text-white">
                <industry.icon className="w-10 h-10" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-4">
                <EditableContent id={`${industry.id}_name`} defaultValue={industry.name} />
              </h3>
              <p className="text-slate-500 text-sm leading-relaxed">
                <EditableContent id={`${industry.id}_desc`} defaultValue={industry.description} />
              </p>
            </motion.div>
          ))}
        </div>

        <div className="mt-20 relative rounded-3xl overflow-hidden aspect-[21/9] shadow-2xl">
          <EditableImage 
            id="industries_main_image"
            defaultUrl="https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&q=80&w=2000" 
            alt="Modern industrial skyline" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900/80 to-transparent flex items-center px-12 pointer-events-none">
            <div className="max-w-md pointer-events-auto">
              <h3 className="text-3xl font-bold text-white mb-4">
                <EditableContent id="industries_cta_title" defaultValue="Understand Your Electricity Cost Better" />
              </h3>
              <p className="text-white/80 mb-8">
                <EditableContent id="industries_cta_description" defaultValue="Join industrial leaders who have optimized their energy expenditure with VPESCO's structured analytical approach." multiline />
              </p>
              <button className="bg-emerald-600 text-white px-8 py-3 rounded-full font-bold hover:bg-emerald-700 transition-all">
                <EditableContent id="industries_cta_button" defaultValue="Request Review" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
