import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, Loader2 } from 'lucide-react';
import { motion } from 'motion/react';
import { EditableContent } from './EditableContent';
import { toast } from 'sonner';

export default function Contact() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    service: 'Electricity Cost Risk Audit',
    message: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const data = await response.json();

      if (response.ok) {
        toast.success('Message sent successfully!');
        setFormData({
          name: '',
          email: '',
          phone: '',
          service: 'Electricity Cost Risk Audit',
          message: ''
        });
      } else {
        toast.error(data.error || 'Failed to send message');
      }
    } catch (error) {
      console.error('Error submitting form:', error);
      toast.error('An error occurred. Please try again later.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <section className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="text-emerald-600 font-bold uppercase tracking-widest text-sm mb-4">
            <EditableContent id="contact_tag" defaultValue="Connect with VPESCO" />
          </div>
          <h2 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-6">
            <EditableContent id="contact_title" defaultValue="Optimize Your Electricity Costs" />
          </h2>
          <div className="text-lg text-slate-600 max-w-2xl mx-auto">
            <EditableContent id="contact_desc" defaultValue="Our advisors are ready to help you navigate the complexities of industrial electricity tariffs and regulations. Request a review today." multiline />
          </div>
        </div>

        <div className="grid lg:grid-cols-3 gap-12">
          <div className="lg:col-span-1 space-y-8">
            <div className="bg-slate-50 p-8 rounded-3xl border border-slate-100">
              <h3 className="text-xl font-bold text-slate-900 mb-8">
                <EditableContent id="contact_info_title" defaultValue="Contact Information" />
              </h3>
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="bg-emerald-100 p-3 rounded-xl text-emerald-600">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-bold text-slate-900">
                      <EditableContent id="contact_office_label" defaultValue="Our Office" />
                    </div>
                    <div className="text-slate-600 text-sm">
                      <EditableContent id="contact_office_address" defaultValue="123 Energy Plaza, Industrial Area, Hyderabad, India" multiline />
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-emerald-100 p-3 rounded-xl text-emerald-600">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-bold text-slate-900">
                      <EditableContent id="contact_phone_label" defaultValue="Phone Number" />
                    </div>
                    <div className="text-slate-600 text-sm">
                      <EditableContent id="contact_phone_value" defaultValue="+91 123 456 7890" />
                    </div>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="bg-emerald-100 p-3 rounded-xl text-emerald-600">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <div className="font-bold text-slate-900">
                      <EditableContent id="contact_email_label" defaultValue="Email Address" />
                    </div>
                    <div className="text-slate-600 text-sm">
                      <EditableContent id="contact_email_value" defaultValue="info@vpesc.in" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-emerald-600 p-8 rounded-3xl text-white shadow-xl shadow-emerald-200">
              <h3 className="text-xl font-bold mb-4">
                <EditableContent id="contact_hours_title" defaultValue="Business Hours" />
              </h3>
              <ul className="space-y-3 opacity-90 text-sm">
                <li className="flex justify-between">
                  <span><EditableContent id="hours_mon_fri_label" defaultValue="Monday - Friday:" /></span> 
                  <span><EditableContent id="hours_mon_fri_value" defaultValue="9:00 AM - 6:00 PM" /></span>
                </li>
                <li className="flex justify-between">
                  <span><EditableContent id="hours_sat_label" defaultValue="Saturday:" /></span> 
                  <span><EditableContent id="hours_sat_value" defaultValue="10:00 AM - 2:00 PM" /></span>
                </li>
                <li className="flex justify-between">
                  <span><EditableContent id="hours_sun_label" defaultValue="Sunday:" /></span> 
                  <span><EditableContent id="hours_sun_value" defaultValue="Closed" /></span>
                </li>
              </ul>
            </div>
          </div>

          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="bg-white p-10 rounded-3xl shadow-xl border border-slate-100 space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Full Name</label>
                  <input 
                    type="text" 
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    placeholder="John Doe"
                    className="w-full px-5 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Email Address</label>
                  <input 
                    type="email" 
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    placeholder="john@example.com"
                    className="w-full px-5 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Phone Number</label>
                  <input 
                    type="tel" 
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="+91 12345 67890"
                    className="w-full px-5 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Service Interested In</label>
                  <select 
                    name="service"
                    value={formData.service}
                    onChange={handleChange}
                    className="w-full px-5 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all bg-white"
                  >
                    <option>Electricity Cost Risk Audit</option>
                    <option>Contract Demand Optimization</option>
                    <option>Tariff & Regulatory Advisory</option>
                    <option>Power Billing Forensics</option>
                    <option>Solar & Open Access Financial Modeling</option>
                    <option>Other</option>
                  </select>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-bold text-slate-700">Message</label>
                <textarea 
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={4}
                  placeholder="Tell us about your requirements..."
                  className="w-full px-5 py-3 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
                ></textarea>
              </div>
              <button 
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-emerald-600 text-white py-4 rounded-xl font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-200 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <Loader2 className="w-5 h-5 animate-spin" />
                ) : (
                  <Send className="w-5 h-5" />
                )}
                {isSubmitting ? 'Sending...' : 'Send Message'}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
