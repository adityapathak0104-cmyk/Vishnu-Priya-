import React, { useState } from 'react';
import { FileText, ClipboardCheck, CheckCircle2, Zap, Wind, Droplets, Thermometer, FileCheck, Leaf, X, Upload, Image as ImageIcon, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useEdit } from '../context/EditContext';
import { EditableContent } from './EditableContent';
import { EditableImage } from './EditableImage';

const phase1Services = [
  { id: 'p1_s1', default: 'Open Access Advisory (State & Inter-state)' },
  { id: 'p1_s2', default: 'Energy Invoice Analysis & Tariff Breakdown' },
  { id: 'p1_s3', default: 'Regulatory Advisory (ERC Compliance)' },
  { id: 'p1_s4', default: 'Power Procurement Strategy (LTA/MTOA/STA)' },
  { id: 'p1_s5', default: 'Electricity Cost Optimization' },
  { id: 'p1_s6', default: 'Independent Financial Modeling' },
];

const phase2Audits = [
  { 
    id: 'p2_a1',
    title: 'Power Quality Audit', 
    icon: Zap,
    description: 'Comprehensive analysis of electrical systems to improve efficiency, reliability, and identify harmonics.',
    images: [
      'https://images.unsplash.com/photo-1558494949-ef010cbdcc51?auto=format&fit=crop&q=80&w=800'
    ]
  },
  { 
    id: 'p2_a2',
    title: 'HVAC System Audit', 
    icon: Wind,
    description: 'Optimizing heating, ventilation, and air conditioning for maximum energy savings and thermal comfort.',
    images: [
      'https://images.unsplash.com/photo-1504328345606-18bbc8c9d7d1?auto=format&fit=crop&q=80&w=800'
    ]
  },
  { 
    id: 'p2_a3',
    title: 'Water System Audit', 
    icon: Droplets,
    description: 'Efficiency assessment of water pumping and distribution networks to reduce energy and water waste.',
    images: [
      'https://images.unsplash.com/photo-1581094288338-2314dddb7ecb?auto=format&fit=crop&q=80&w=800'
    ]
  },
  { 
    id: 'p2_a4',
    title: 'Thermography & Safety', 
    icon: Thermometer,
    description: 'Infrared inspections to identify hotspots, ensure operational safety, and prevent equipment failure.',
    images: [
      'https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&q=80&w=800'
    ]
  },
  { 
    id: 'p2_a5',
    title: 'PAT Compliance', 
    icon: FileCheck,
    description: 'Assisting industries in achieving Perform Achieve Trade (PAT) targets and regulatory compliance.',
    images: [
      'https://images.unsplash.com/photo-1454165833767-027ff33027ef?auto=format&fit=crop&q=80&w=800'
    ]
  },
  { 
    id: 'p2_a6',
    title: 'Green Energy Audit', 
    icon: Leaf,
    description: 'Evaluating renewable energy integration, carbon footprint, and sustainability practices.',
    images: [
      'https://images.unsplash.com/photo-1509391366360-fe5bb58583bb?auto=format&fit=crop&q=80&w=800'
    ]
  },
];

export default function ServicesSection() {
  const [selectedAudit, setSelectedAudit] = useState<null | typeof phase2Audits[0]>(null);
  const [uploadedImages, setUploadedImages] = useState<Record<string, string[]>>({});
  const { isAdmin } = useEdit();

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (selectedAudit && e.target.files) {
      const files = Array.from(e.target.files);
      const newUrls = files.map(file => URL.createObjectURL(file as Blob));
      setUploadedImages(prev => ({
        ...prev,
        [selectedAudit.title]: [...(prev[selectedAudit.title] || []), ...newUrls]
      }));
    }
  };

  return (
    <section className="py-32 bg-[#fcfcf9] overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-24 gap-8">
          <div className="max-w-2xl">
            <div className="text-[#15803d] font-bold uppercase tracking-[0.3em] text-xs mb-6">
              <EditableContent id="services_tag" defaultValue="Specialized Advisory" />
            </div>
            <h2 className="text-6xl lg:text-8xl font-serif text-slate-900 leading-[0.9] tracking-tight">
              <EditableContent id="services_title" defaultValue="What We Do" multiline />
            </h2>
          </div>
          <div className="text-xl text-slate-500 max-w-md font-serif italic border-l-2 border-emerald-100 pl-8">
            <EditableContent id="services_subtitle" defaultValue="VPESCO provides a suite of specialized services designed to optimize industrial electricity costs through deep analytical and regulatory insights." multiline />
          </div>
        </div>

        <div className="flex flex-col gap-24 relative">
          {/* Decorative background numbers */}
          <div className="absolute top-0 -left-24 text-[300px] font-serif font-black text-slate-50 opacity-[0.03] select-none pointer-events-none">01</div>
          <div className="absolute bottom-0 -right-24 text-[300px] font-serif font-black text-slate-50 opacity-[0.03] select-none pointer-events-none">02</div>

          {/* Phase 1 Card - Clean White (Now First) */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="group relative bg-white rounded-[4rem] p-12 md:p-20 shadow-[0_32px_64px_-16px_rgba(0,0,0,0.05)] border border-slate-100 flex flex-col lg:flex-row gap-16 hover:shadow-[0_48px_80px_-16px_rgba(0,0,0,0.08)] transition-all duration-500"
          >
            <div className="lg:w-1/2 space-y-8">
              <div className="inline-flex px-6 py-2 rounded-full bg-slate-50 text-slate-400 text-xs font-black uppercase tracking-[0.3em] border border-slate-100">
                <EditableContent id="phase1_step" defaultValue="Step 01" />
              </div>
              <h3 className="text-5xl lg:text-6xl font-serif text-slate-900 leading-tight">
                <EditableContent id="phase1_title" defaultValue="Energy Advisory & Analytics" multiline />
              </h3>
              <p className="text-emerald-600 font-bold text-sm uppercase tracking-[0.4em]">
                <EditableContent id="phase1_badge" defaultValue="Strategic Advisory Stage" />
              </p>
              <div className="text-xl text-slate-500 leading-relaxed font-light">
                <EditableContent id="phase1_desc" defaultValue="We operate at the intersection of energy markets and financial analysis, helping organizations manage electricity cost as a strategic financial variable." multiline />
              </div>
              <div className="bg-slate-50 p-8 rounded-3xl inline-block group-hover:bg-emerald-50 transition-colors duration-500">
                <FileText className="w-12 h-12 text-slate-300 group-hover:text-emerald-400 transition-colors duration-500" />
              </div>
            </div>

            <div className="lg:w-1/2 space-y-12">
              <div>
                <h4 className="text-xs font-black text-slate-300 uppercase tracking-[0.4em] mb-10">
                  <EditableContent id="phase1_services_title" defaultValue="Key Services" />
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {phase1Services.map((service, i) => (
                    <div key={i} className="flex items-center gap-4 group/item">
                      <div className="w-2 h-2 rounded-full bg-emerald-200 group-hover/item:bg-emerald-500 transition-colors" />
                      <span className="text-slate-700 font-medium tracking-tight text-lg">
                        <EditableContent id={service.id} defaultValue={service.default} />
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-[#fcfcf9] p-12 rounded-[3rem] border border-slate-100 relative overflow-hidden">
                <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-50 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
                <h4 className="text-[#15803d] font-black text-xs uppercase tracking-[0.3em] mb-6 relative z-10">
                  <EditableContent id="phase1_outcome_title" defaultValue="Outcome" />
                </h4>
                <div className="text-slate-900 font-serif italic text-2xl leading-relaxed relative z-10">
                  <EditableContent id="phase1_outcome_text" defaultValue='"A data-driven roadmap and ROI projection for high-impact energy investments."' multiline />
                </div>
              </div>
            </div>
          </motion.div>

          {/* Phase 2 Card - Attractive Deep Blue/Teal (Now Second) */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="group relative bg-[#0f172a] rounded-[4rem] p-12 md:p-20 shadow-[0_32px_64px_-16px_rgba(15,23,42,0.3)] flex flex-col lg:flex-row gap-16 hover:shadow-[0_48px_80px_-16px_rgba(15,23,42,0.4)] transition-all duration-500 overflow-hidden"
          >
            {/* Background decorative glow */}
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-emerald-500/10 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2" />
            
            <div className="lg:w-1/2 space-y-8 relative z-10">
              <div className="inline-flex px-6 py-2 rounded-full bg-white/5 text-white/40 text-xs font-black uppercase tracking-[0.3em] border border-white/10">
                <EditableContent id="phase2_step" defaultValue="Step 02" />
              </div>
              <h3 className="text-5xl lg:text-6xl font-serif text-white leading-tight">
                <EditableContent id="phase2_title" defaultValue="Regulatory & Procurement Strategy" multiline />
              </h3>
              <p className="text-emerald-400 font-bold text-sm uppercase tracking-[0.4em]">
                <EditableContent id="phase2_badge" defaultValue="Compliance & Market Access Stage" />
              </p>
              <div className="text-xl text-slate-400 leading-relaxed font-light">
                <EditableContent id="phase2_desc" defaultValue="Navigating complex power procurement mechanisms including LTA, MTOA, and STA while ensuring compliance with evolving state and central regulations." multiline />
              </div>
              
              <div className="grid grid-cols-1 gap-4 mt-8">
                <div className="flex items-center gap-4 p-4 rounded-2xl bg-white/5 border border-white/10">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <div className="text-white font-bold text-sm">
                      <EditableContent id="phase2_feature1_title" defaultValue="Advanced Instrumentation" />
                    </div>
                    <div className="text-slate-500 text-xs">
                      <EditableContent id="phase2_feature1_desc" defaultValue="High-precision data logging & analysis" />
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-4 p-4 rounded-2xl bg-white/5 border border-white/10">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/20 flex items-center justify-center">
                    <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  </div>
                  <div>
                    <div className="text-white font-bold text-sm">
                      <EditableContent id="phase2_feature2_title" defaultValue="IoT Integration" />
                    </div>
                    <div className="text-slate-500 text-xs">
                      <EditableContent id="phase2_feature2_desc" defaultValue="Real-time monitoring & verification" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="lg:w-1/2 space-y-12 relative z-10">
              <div>
                <h4 className="text-xs font-black text-slate-500 uppercase tracking-[0.4em] mb-10">
                  <EditableContent id="phase2_audits_title" defaultValue="In-Depth Audit Types" />
                </h4>
                <div className="grid grid-cols-2 gap-6">
                  {phase2Audits.map((audit, i) => (
                    <div 
                      key={i} 
                      onClick={() => setSelectedAudit(audit)}
                      className="flex items-center gap-4 p-5 rounded-3xl bg-white/5 border border-white/10 hover:bg-white/10 transition-all group/audit cursor-pointer"
                    >
                      <audit.icon className="w-5 h-5 text-emerald-400 group-hover/audit:scale-110 transition-transform" />
                      <span className="text-white text-base font-semibold tracking-tight">
                        <EditableContent id={`${audit.id}_title`} defaultValue={audit.title} />
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-white/5 backdrop-blur-sm p-12 rounded-[3rem] border border-white/10 relative overflow-hidden">
                <h4 className="text-emerald-400 font-black text-xs uppercase tracking-[0.3em] mb-8">
                  <EditableContent id="phase2_deliverables_title" defaultValue="Deliverables" />
                </h4>
                <ul className="space-y-6">
                  {[
                    { id: 'p2_d1', default: 'Detailed engineering report' },
                    { id: 'p2_d2', default: 'Implementation roadmap & CAPEX analysis' },
                    { id: 'p2_d3', default: 'Energy savings calculation certificates' }
                  ].map((item, i) => (
                    <li key={i} className="text-white font-serif italic text-lg flex items-start gap-4">
                      <div className="w-2 h-2 rounded-full bg-emerald-500 mt-2 shrink-0" />
                      <EditableContent id={item.id} defaultValue={item.default} />
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Detailed Audit Process Section */}
        <div className="mt-48 border-t border-slate-100 pt-32">
          <div className="text-[#15803d] font-bold uppercase tracking-[0.3em] text-xs mb-6">
            <EditableContent id="methodology_tag" defaultValue="Strategic Methodology" />
          </div>
          <h2 className="text-5xl lg:text-7xl font-serif text-slate-900 leading-[0.9] tracking-tight mb-16">
            <EditableContent id="methodology_title" defaultValue="Detailed Audit Process" multiline />
          </h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="space-y-8">
              <div className="p-10 rounded-[3rem] bg-white border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-500 group">
                <div className="w-16 h-16 rounded-2xl bg-emerald-50 flex items-center justify-center mb-8 group-hover:bg-[#15803d] transition-colors duration-500">
                  <span className="text-2xl font-black text-[#15803d] group-hover:text-white">01</span>
                </div>
                <h4 className="text-2xl font-bold text-slate-900 mb-4">
                  <EditableContent id="step1_title" defaultValue="Data Collection & Site Survey" />
                </h4>
                <div className="text-slate-500 leading-relaxed font-light">
                  <EditableContent id="step1_desc" defaultValue="Our engineers conduct a thorough physical inspection of the facility, mapping all energy-consuming assets and collecting historical billing data for a baseline analysis." multiline />
                </div>
                <ul className="mt-6 space-y-3">
                  {[
                    { id: 'step1_i1', default: 'Asset Inventory' },
                    { id: 'step1_i2', default: 'Historical Data Mining' },
                    { id: 'step1_i3', default: 'Operational Interviews' }
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-sm font-semibold text-slate-700">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      <EditableContent id={item.id} defaultValue={item.default} />
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="space-y-8">
              <div className="p-10 rounded-[3rem] bg-[#0f172a] border border-white/5 shadow-2xl hover:shadow-emerald-500/10 transition-all duration-500 group">
                <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mb-8 group-hover:bg-emerald-500 transition-colors duration-500">
                  <span className="text-2xl font-black text-white">02</span>
                </div>
                <h4 className="text-2xl font-bold text-white mb-4">
                  <EditableContent id="step2_title" defaultValue="Advanced Measurement" />
                </h4>
                <div className="text-slate-400 leading-relaxed font-light">
                  <EditableContent id="step2_desc" defaultValue="Using high-precision IoT sensors and data loggers, we capture real-time power quality, thermal patterns, and flow rates to identify hidden inefficiencies." multiline />
                </div>
                <ul className="mt-6 space-y-3">
                  {[
                    { id: 'step2_i1', default: 'Thermal Imaging' },
                    { id: 'step2_i2', default: 'Harmonic Analysis' },
                    { id: 'step2_i3', default: 'Flow Rate Logging' }
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-sm font-semibold text-emerald-400">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                      <EditableContent id={item.id} defaultValue={item.default} />
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="space-y-8">
              <div className="p-10 rounded-[3rem] bg-white border border-slate-100 shadow-sm hover:shadow-xl transition-all duration-500 group">
                <div className="w-16 h-16 rounded-2xl bg-emerald-50 flex items-center justify-center mb-8 group-hover:bg-[#15803d] transition-colors duration-500">
                  <span className="text-2xl font-black text-[#15803d] group-hover:text-white">03</span>
                </div>
                <h4 className="text-2xl font-bold text-slate-900 mb-4">
                  <EditableContent id="step3_title" defaultValue="Strategic Reporting" />
                </h4>
                <div className="text-slate-500 leading-relaxed font-light">
                  <EditableContent id="step3_desc" defaultValue="We translate complex data into a clear financial roadmap, providing CAPEX/OPEX analysis and guaranteed ROI projections for decision-makers." multiline />
                </div>
                <ul className="mt-6 space-y-3">
                  {[
                    { id: 'step3_i1', default: 'ROI Projections' },
                    { id: 'step3_i2', default: 'Implementation Roadmap' },
                    { id: 'step3_i3', default: 'Compliance Certification' }
                  ].map((item, i) => (
                    <li key={i} className="flex items-center gap-3 text-sm font-semibold text-slate-700">
                      <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                      <EditableContent id={item.id} defaultValue={item.default} />
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div className="mt-24 bg-emerald-50 rounded-[4rem] p-12 md:p-20 flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/2">
              <h3 className="text-4xl lg:text-5xl font-serif text-slate-900 leading-tight mb-8">
                <EditableContent id="insights_title" defaultValue="Executive Insights for Stakeholders" multiline />
              </h3>
              <div className="space-y-6">
                <div className="flex gap-6">
                  <div className="shrink-0 w-12 h-12 rounded-full bg-white flex items-center justify-center shadow-sm">
                    <CheckCircle2 className="w-6 h-6 text-[#15803d]" />
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-900 mb-2">
                      <EditableContent id="insight1_title" defaultValue="For CFOs & Investors" />
                    </h5>
                    <div className="text-slate-600 text-sm leading-relaxed">
                      <EditableContent id="insight1_desc" defaultValue="Detailed financial modeling with Internal Rate of Return (IRR) and Payback Period analysis for every proposed energy investment." multiline />
                    </div>
                  </div>
                </div>
                <div className="flex gap-6">
                  <div className="shrink-0 w-12 h-12 rounded-full bg-white flex items-center justify-center shadow-sm">
                    <CheckCircle2 className="w-6 h-6 text-[#15803d]" />
                  </div>
                  <div>
                    <h5 className="font-bold text-slate-900 mb-2">
                      <EditableContent id="insight2_title" defaultValue="For Directors & Plant Managers" />
                    </h5>
                    <div className="text-slate-600 text-sm leading-relaxed">
                      <EditableContent id="insight2_desc" defaultValue="Operational risk assessment and non-disruptive implementation strategies that ensure zero downtime during efficiency upgrades." multiline />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="lg:w-1/2 relative">
              <div className="rounded-[3rem] overflow-hidden shadow-2xl rotate-2">
                <EditableImage 
                  id="insights_image"
                  defaultUrl="https://images.unsplash.com/photo-1454165833767-027ff33027ef?auto=format&fit=crop&q=80&w=1000" 
                  alt="Executive meeting" 
                  className="w-full h-full object-cover aspect-video"
                />
              </div>
              <div className="absolute -bottom-6 -left-6 bg-white p-6 rounded-2xl shadow-xl border border-slate-100 max-w-[240px] -rotate-3">
                <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">
                  <EditableContent id="guarantee_badge" defaultValue="Guaranteed Results" />
                </p>
                <div className="text-lg font-serif italic text-slate-900">
                  <EditableContent id="guarantee_text" defaultValue='"Average 15-30% reduction in annual energy spend."' multiline />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Audit Detail Modal */}
      <AnimatePresence>
        {selectedAudit && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedAudit(null)}
              className="absolute inset-0 bg-slate-900/60 backdrop-blur-sm"
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="relative w-full max-w-4xl bg-white rounded-[3rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
            >
              <div className="p-8 sm:p-12 overflow-y-auto">
                <div className="flex justify-between items-start mb-12">
                  <div className="space-y-4">
                    <div className="inline-flex items-center gap-3 px-4 py-2 rounded-full bg-emerald-50 text-emerald-600 text-xs font-black uppercase tracking-widest border border-emerald-100">
                      <selectedAudit.icon className="w-4 h-4" />
                      <EditableContent id="modal_tag" defaultValue="Detailed Audit" />
                    </div>
                    <h3 className="text-4xl sm:text-5xl font-serif text-slate-900 leading-tight">
                      <EditableContent id={`${selectedAudit.id}_modal_title`} defaultValue={selectedAudit.title} /> <span className="italic text-[#15803d]">Analysis</span>
                    </h3>
                  </div>
                  <button 
                    onClick={() => setSelectedAudit(null)}
                    className="p-3 rounded-full bg-slate-50 text-slate-400 hover:bg-slate-100 hover:text-slate-900 transition-all"
                  >
                    <X className="w-6 h-6" />
                  </button>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <div className="space-y-8">
                    <div className="text-xl text-slate-600 leading-relaxed font-light">
                      <EditableContent id={`${selectedAudit.id}_modal_desc`} defaultValue={selectedAudit.description} multiline />
                    </div>
                    
                    <div className="space-y-6">
                      <h4 className="text-xs font-black text-slate-300 uppercase tracking-[0.4em]">Audit Images</h4>
                      <div className="grid grid-cols-2 gap-4">
                        {selectedAudit.images.map((img, i) => (
                          <div key={i} className="rounded-2xl overflow-hidden aspect-video shadow-md relative group">
                            <EditableImage 
                              id={`audit_${selectedAudit.id}_image_${i}`}
                              defaultUrl={img}
                              alt={`${selectedAudit.title} audit`}
                              className="w-full h-full object-cover"
                            />
                          </div>
                        ))}
                        {(uploadedImages[selectedAudit.title] || []).map((img, i) => (
                          <div key={`uploaded-${i}`} className="rounded-2xl overflow-hidden aspect-video shadow-md relative group">
                            <img src={img} alt="Uploaded audit" className="w-full h-full object-cover" />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <span className="text-white text-xs font-bold uppercase tracking-widest">User Upload</span>
                            </div>
                          </div>
                        ))}
                        {isAdmin && (
                          <label className="rounded-2xl border-2 border-dashed border-slate-200 aspect-video flex flex-col items-center justify-center gap-3 cursor-pointer hover:border-emerald-400 hover:bg-emerald-50 transition-all group">
                            <input type="file" className="hidden" multiple accept="image/*" onChange={handleImageUpload} />
                            <Upload className="w-6 h-6 text-slate-300 group-hover:text-emerald-500 transition-colors" />
                            <span className="text-xs font-bold text-slate-400 group-hover:text-emerald-600 uppercase tracking-widest">Upload Image</span>
                          </label>
                        )}
                      </div>
                    </div>
                  </div>

                  <div className="space-y-8">
                    <div className="p-8 rounded-[2rem] bg-slate-50 border border-slate-100">
                      <h4 className="text-[#15803d] font-black text-xs uppercase tracking-[0.3em] mb-6">
                        <EditableContent id="modal_procedures_title" defaultValue="Standard Procedures" />
                      </h4>
                      <ul className="space-y-4">
                        {[
                          { id: 'proc_1', default: 'Initial site survey and data collection' },
                          { id: 'proc_2', default: 'Advanced sensor installation and monitoring' },
                          { id: 'proc_3', default: 'Data modeling and inefficiency identification' },
                          { id: 'proc_4', default: 'Custom solution engineering and ROI analysis' },
                          { id: 'proc_5', default: 'Final reporting and implementation roadmap' }
                        ].map((step, i) => (
                          <li key={i} className="flex items-start gap-3 text-slate-600 text-sm leading-relaxed">
                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-1.5 shrink-0" />
                            <EditableContent id={step.id} defaultValue={step.default} />
                          </li>
                        ))}
                      </ul>
                    </div>
                    <button className="w-full py-6 rounded-full bg-[#15803d] text-white font-bold hover:bg-emerald-800 transition-all shadow-xl shadow-emerald-100 flex items-center justify-center gap-3 group">
                      <EditableContent id="modal_cta" defaultValue="Request This Audit" />
                      <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
