import React from 'react';
import { Zap, BarChart3, Factory, Flame, Snowflake, Settings, CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';
import { EditableContent } from './EditableContent';

const analysisCards = [
  {
    id: 'pa_card_1',
    title: 'Power Quality & Harmonics',
    icon: Zap,
    description: 'Evaluation of electrical supply quality to detect disturbances, harmonics, and voltage imbalance that affect equipment reliability.',
    measurements: ['Voltage stability', 'Current behavior', 'Harmonic distortion', 'Power factor performance'],
    outcome: 'Improved system stability and reduced electrical losses.',
    color: 'text-yellow-500',
    bgColor: 'bg-yellow-50',
  },
  {
    id: 'pa_card_2',
    title: 'Load Factor & Demand Patterns',
    icon: BarChart3,
    description: 'Detailed monitoring of load patterns helps identify peak demand behavior and opportunities for demand optimization.',
    measurements: ['Peak demand evaluation', 'Load factor calculation', 'Operational load scheduling'],
    outcome: 'Reduced electricity demand charges.',
    color: 'text-blue-500',
    bgColor: 'bg-blue-50',
  },
  {
    id: 'pa_card_3',
    title: 'Thermal Loss Detection',
    icon: Flame,
    description: 'Infrared thermography is used to detect abnormal heat generation in electrical panels, motors, and distribution systems.',
    measurements: ['Electrical panel inspection', 'Cable joint analysis', 'Motor overheating detection'],
    outcome: 'Prevention of failures and reduction of energy losses.',
    color: 'text-red-500',
    bgColor: 'bg-red-50',
  },
  {
    id: 'pa_card_4',
    title: 'HVAC System Efficiency',
    icon: Snowflake,
    description: 'VPESCO evaluates HVAC systems to determine operational efficiency and identify opportunities for energy savings.',
    measurements: ['Chiller performance', 'Air handling unit efficiency', 'Cooling load analysis'],
    outcome: 'Lower cooling energy consumption.',
    color: 'text-cyan-500',
    bgColor: 'bg-cyan-50',
  },
  {
    id: 'pa_card_5',
    title: 'Pump & Motor Performance',
    icon: Settings,
    description: 'Evaluating operational performance of motors and pumps to identify efficiency improvements and mechanical losses.',
    measurements: ['Motor load analysis', 'Pump efficiency evaluation', 'Alignment and mechanical losses'],
    outcome: 'Reduced energy consumption and improved equipment lifespan.',
    color: 'text-slate-600',
    bgColor: 'bg-slate-100',
  },
  {
    id: 'pa_card_6',
    title: 'Compressed Air Systems',
    icon: Factory,
    description: 'Analysis of compressed air generation and distribution to identify leaks and optimize pressure settings.',
    measurements: ['Compressor efficiency', 'Leakage detection', 'Pressure optimization'],
    outcome: 'Significant reduction in air generation costs.',
    color: 'text-emerald-500',
    bgColor: 'bg-emerald-50',
  },
];

export default function PerformanceAnalysis() {
  return (
    <section className="py-32 bg-slate-50 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-24">
          <div className="text-[#15803d] font-bold uppercase tracking-[0.3em] text-xs mb-6">
            <EditableContent id="pa_tag" defaultValue="Phase 2: Technical Audit" />
          </div>
          <h2 className="text-5xl lg:text-7xl font-serif text-slate-900 leading-[0.9] tracking-tight mb-8">
            <EditableContent id="pa_title" defaultValue="On-Site Technical & Engineering Audit" multiline />
          </h2>
          <p className="text-xl text-slate-600 leading-relaxed font-light">
            <EditableContent id="pa_description" defaultValue="VPESCO engineers use advanced diagnostic instruments and data analytics to evaluate electrical quality, equipment performance, and operational efficiency across critical energy systems." multiline />
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {analysisCards.map((card, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-white rounded-[2.5rem] p-10 shadow-sm border border-slate-100 hover:shadow-xl hover:border-emerald-100 transition-all duration-500 group flex flex-col"
            >
              <div className={`w-16 h-16 rounded-2xl ${card.bgColor} flex items-center justify-center mb-8 group-hover:scale-110 transition-transform duration-500`}>
                <card.icon className={`w-8 h-8 ${card.color}`} />
              </div>
              
              <h3 className="text-2xl font-bold text-slate-900 mb-4 leading-tight">
                <EditableContent id={`${card.id}_title`} defaultValue={card.title} />
              </h3>
              <p className="text-slate-500 text-sm leading-relaxed mb-8 flex-grow">
                <EditableContent id={`${card.id}_desc`} defaultValue={card.description} multiline />
              </p>

              <div className="space-y-6">
                <div>
                  <div className="text-[10px] font-black text-slate-300 uppercase tracking-[0.2em] mb-4">
                    <EditableContent id={`${card.id}_param_label`} defaultValue="Key Parameters / Tools" />
                  </div>
                  <ul className="space-y-3">
                    {card.measurements.map((item, i) => (
                      <li key={i} className="flex items-center gap-3 text-sm font-semibold text-slate-700">
                        <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                        <EditableContent id={`${card.id}_meas_${i}`} defaultValue={item} />
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-6 border-t border-slate-50">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-emerald-50 flex items-center justify-center shrink-0">
                      <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    </div>
                    <div>
                      <div className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">
                        <EditableContent id={`${card.id}_outcome_label`} defaultValue="Outcome" />
                      </div>
                      <div className="text-sm font-bold text-slate-900">
                        <EditableContent id={`${card.id}_outcome_val`} defaultValue={card.outcome} />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-24 bg-[#0f172a] rounded-[4rem] p-12 md:p-20 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-emerald-500/10 rounded-full blur-[120px] -translate-y-1/2 translate-x-1/2" />
          
          <div className="relative z-10 flex flex-col lg:flex-row items-center gap-16">
            <div className="lg:w-1/2">
              <h3 className="text-4xl lg:text-5xl font-serif text-white leading-tight mb-8">
                <EditableContent id="pa_bottom_title" defaultValue="Data-Driven Engineering Insights" multiline />
              </h3>
              <p className="text-xl text-slate-400 leading-relaxed font-light">
                <EditableContent id="pa_bottom_description" defaultValue="By combining electrical diagnostics, thermal imaging, and operational performance analysis, VPESCO delivers accurate engineering insights that help organizations reduce energy losses and improve system reliability." multiline />
              </p>
            </div>
            <div className="lg:w-1/2 grid grid-cols-2 gap-6 w-full">
              {[
                { id: 'pa_stat_1', label: 'Electrical Reliability', value: '99.9%' },
                { id: 'pa_stat_2', label: 'Energy Savings', value: '15-30%' },
                { id: 'pa_stat_3', label: 'Asset Lifespan', value: '+40%' },
                { id: 'pa_stat_4', label: 'ROI Period', value: '<18 mo' },
              ].map((stat, i) => (
                <div key={i} className="bg-white/5 border border-white/10 p-8 rounded-3xl backdrop-blur-sm">
                  <div className="text-3xl font-bold text-white mb-2">
                    <EditableContent id={`${stat.id}_val`} defaultValue={stat.value} />
                  </div>
                  <div className="text-xs font-black text-slate-500 uppercase tracking-widest">
                    <EditableContent id={`${stat.id}_label`} defaultValue={stat.label} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
