import React from 'react';
import { Menu, X, Zap, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { EditableContent } from './EditableContent';
import { useEdit } from '../context/EditContext';

interface NavbarProps {
  activePage: string;
  setActivePage: (page: string) => void;
}

export const Logo = ({ light = false }: { light?: boolean }) => (
  <div className="flex items-center gap-4 group flex-nowrap shrink-0">
    <div className="relative flex flex-col items-center shrink-0">
      {/* Main bulb body */}
      <div className="relative w-14 h-14 bg-[#82d14d] rounded-full flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform z-10">
        <span className="text-white font-black text-2xl leading-none tracking-tighter">VP</span>
        
        {/* Yellow badge with white bolt */}
        <div className="absolute -top-1 -right-1 w-7 h-7 bg-[#ffcc29] rounded-xl flex items-center justify-center shadow-sm border-2 border-white/20">
          <Zap className="text-white w-4 h-4 fill-current" />
        </div>
      </div>
      
      {/* Dark green base */}
      <div className="w-10 h-2 bg-[#1b3d1b] rounded-full mt-1 shadow-sm z-0" />
    </div>
    
    <div className="flex flex-col whitespace-nowrap">
      <span className={`text-3xl font-black tracking-tight leading-none ${light ? 'text-white' : 'text-[#2b4ea2]'}`}>
        Vishnu Priya
      </span>
      <span className={`text-xs font-black uppercase tracking-[0.15em] mt-1.5 ${light ? 'text-emerald-400' : 'text-[#388e3c]'}`}>
        ENERGY SOLUTIONS & SERVICES
      </span>
    </div>
  </div>
);

export default function Navbar({ activePage, setActivePage }: NavbarProps) {
  const [isOpen, setIsOpen] = React.useState(false);
  const { isAdmin } = useEdit();

  const navLinks = [
    { name: 'Home', id: 'home' },
    { name: 'About Us', id: 'about' },
    { name: 'Services', id: 'services' },
    { name: 'Audit Methodology', id: 'audits' },
    { name: 'Energy Intelligence', id: 'intelligence' },
    { name: 'Our Team', id: 'team' },
    { name: 'Bill Audit', id: 'bill-audit' },
    { name: 'Industries', id: 'industries' },
    { name: 'Contact', id: 'contact' },
  ];

  return (
    <nav className="fixed w-full z-50 bg-white/80 backdrop-blur-md border-b border-slate-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          <div 
            className="flex items-center gap-2 cursor-pointer group"
            onClick={() => setActivePage('home')}
          >
            <Logo />
          </div>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-6">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => setActivePage(link.id)}
                className={`text-base font-bold transition-colors whitespace-nowrap ${
                  activePage === link.id 
                    ? 'text-emerald-600' 
                    : 'text-slate-600 hover:text-emerald-600'
                }`}
              >
                {link.name}
              </button>
            ))}
            <button 
              onClick={() => setActivePage('contact')}
              className="bg-emerald-600 text-white px-6 py-3 rounded-full text-base font-bold hover:bg-emerald-700 transition-all shadow-md whitespace-nowrap ml-2"
            >
              <EditableContent id="nav_cta" defaultValue="Request Review" />
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="p-2 text-slate-600 hover:text-emerald-600 transition-colors"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-white border-b border-slate-100 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-1">
              {navLinks.map((link) => (
                <button
                  key={link.id}
                  onClick={() => {
                    setActivePage(link.id);
                    setIsOpen(false);
                  }}
                  className={`block w-full text-left px-4 py-3 rounded-xl text-base font-medium transition-colors ${
                    activePage === link.id 
                      ? 'bg-emerald-50 text-emerald-600' 
                      : 'text-slate-600 hover:bg-slate-50 hover:text-emerald-600'
                  }`}
                >
                  {link.name}
                </button>
              ))}
              <div className="pt-4">
                <button 
                  onClick={() => {
                    setActivePage('contact');
                    setIsOpen(false);
                  }}
                  className="w-full bg-emerald-600 text-white px-5 py-3 rounded-xl text-center font-semibold"
                >
                  <EditableContent id="nav_cta_mobile" defaultValue="Request Review" />
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
