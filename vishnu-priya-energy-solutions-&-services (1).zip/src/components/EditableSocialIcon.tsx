import React, { useState } from 'react';
import { Edit2, Check, X, Link as LinkIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useEdit } from '../context/EditContext';

interface EditableSocialIconProps {
  id: string;
  icon: any;
  label: string;
  defaultUrl: string;
  className?: string;
  iconClassName?: string;
}

export const EditableSocialIcon: React.FC<EditableSocialIconProps> = ({
  id,
  icon: Icon,
  label,
  defaultUrl,
  className = '',
  iconClassName = 'w-5 h-5'
}) => {
  const { getContent, setContent, isAdmin, isEditMode } = useEdit();
  const [isEditing, setIsEditing] = useState(false);
  const [tempUrl, setTempUrl] = useState('');

  const currentUrl = getContent(`social_link_${id}`, defaultUrl);

  const handleStartEdit = (e: React.MouseEvent) => {
    if (!isEditMode || !isAdmin) return;
    e.preventDefault();
    e.stopPropagation();
    setTempUrl(currentUrl);
    setIsEditing(true);
  };

  const handleSave = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    await setContent(`social_link_${id}`, tempUrl);
    setIsEditing(false);
  };

  const handleCancel = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsEditing(false);
  };

  return (
    <div className="relative group">
      <AnimatePresence>
        {isEditing && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 10 }}
            className="absolute bottom-full left-1/2 -translate-x-1/2 mb-4 bg-slate-900 border border-emerald-500/50 rounded-2xl p-4 shadow-2xl flex flex-col gap-3 min-w-[280px] z-[100]"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center gap-2 text-xs font-bold text-emerald-400 uppercase tracking-widest">
              <LinkIcon className="w-3 h-3" />
              Edit {label} Link
            </div>
            <input
              type="text"
              value={tempUrl}
              onChange={(e) => setTempUrl(e.target.value)}
              className="w-full bg-slate-800 border border-white/10 rounded-xl px-4 py-2.5 text-white text-sm focus:outline-none focus:border-emerald-500 transition-colors"
              placeholder="https://..."
              autoFocus
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSave(e as any);
                if (e.key === 'Escape') handleCancel(e as any);
              }}
            />
            <div className="flex gap-2">
              <button
                onClick={handleSave}
                className="flex-1 bg-emerald-600 hover:bg-emerald-500 text-white py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-600/20"
              >
                <Check className="w-4 h-4" /> Save
              </button>
              <button
                onClick={handleCancel}
                className="flex-1 bg-slate-700 hover:bg-slate-600 text-white py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2"
              >
                <X className="w-4 h-4" /> Cancel
              </button>
            </div>
            {/* Arrow */}
            <div className="absolute top-full left-1/2 -translate-x-1/2 w-4 h-4 bg-slate-900 border-r border-b border-emerald-500/50 rotate-45 -mt-2" />
          </motion.div>
        )}
      </AnimatePresence>

      <a
        href={isEditing ? undefined : currentUrl}
        target="_blank"
        rel="noopener noreferrer"
        className={`relative ${className} ${isEditMode && isAdmin ? 'cursor-pointer' : ''}`}
        onClick={isEditMode && isAdmin ? handleStartEdit : undefined}
      >
        <Icon className={iconClassName} />
        
        {isEditMode && isAdmin && !isEditing && (
          <span className="absolute -top-2 -right-2 bg-emerald-500 text-white p-1 rounded-lg shadow-lg opacity-0 group-hover:opacity-100 transition-all scale-75 group-hover:scale-100">
            <Edit2 className="w-3 h-3" />
          </span>
        )}
      </a>
    </div>
  );
};
