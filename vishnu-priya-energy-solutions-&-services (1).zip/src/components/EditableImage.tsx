import React, { useRef, useState } from 'react';
import { Image as ImageIcon, Upload, X, Loader2 } from 'lucide-react';
import { useEdit } from '../context/EditContext';
import { toast } from 'sonner';

interface EditableImageProps {
  id: string;
  defaultUrl: string;
  className?: string;
  alt?: string;
}

const compressImage = (dataUrl: string, maxWidth = 1200, quality = 0.7): Promise<string> => {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.src = dataUrl;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      if (width > maxWidth) {
        height = (maxWidth / width) * height;
        width = maxWidth;
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Failed to get canvas context'));
        return;
      }
      ctx.drawImage(img, 0, 0, width, height);
      resolve(canvas.toDataURL('image/jpeg', quality));
    };
    img.onerror = () => reject(new Error('Failed to load image'));
  });
};

export const EditableImage: React.FC<EditableImageProps> = ({ id, defaultUrl, className, alt }) => {
  const { isEditMode, getImage, setImage, isAdmin, highlightMode } = useEdit();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isUploading, setIsUploading] = useState(false);
  const currentUrl = getImage(id, defaultUrl);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!isAdmin) return;
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast.error('Please upload an image file');
        return;
      }

      setIsUploading(true);
      const toastId = toast.loading('Processing and uploading image...');

      const reader = new FileReader();
      reader.onloadend = async () => {
        try {
          const compressedDataUrl = await compressImage(reader.result as string);
          await setImage(id, compressedDataUrl);
          toast.success('Image updated successfully', { id: toastId });
        } catch (error) {
          console.error("Image processing failed", error);
          toast.error('Failed to process image. It might be too large.', { id: toastId });
        } finally {
          setIsUploading(false);
        }
      };
      reader.onerror = () => {
        toast.error('Failed to read file', { id: toastId });
        setIsUploading(false);
      };
      reader.readAsDataURL(file);
    }
  };

  const resetImage = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!isAdmin) return;
    await setImage(id, defaultUrl);
    toast.success('Image reset to default');
  };

  if (!isEditMode) {
    return <img src={currentUrl} alt={alt} className={className} referrerPolicy="no-referrer" />;
  }

  return (
    <div className={`relative group ${className} overflow-hidden ${highlightMode && isEditMode ? 'ring-4 ring-emerald-500/50' : ''}`}>
      <img src={currentUrl} alt={alt} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
      
      <div className={`absolute inset-0 bg-black/40 transition-opacity flex flex-col items-center justify-center gap-4 z-20 ${isUploading ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`}>
        {isUploading ? (
          <div className="flex flex-col items-center gap-2 text-white">
            <Loader2 className="w-8 h-8 animate-spin" />
            <span className="text-sm font-bold">Uploading...</span>
          </div>
        ) : (
          <>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="bg-emerald-600 text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2 hover:bg-emerald-500 transition-all shadow-lg"
            >
              <Upload className="w-4 h-4" />
              Change Image
            </button>
            
            {currentUrl !== defaultUrl && (
              <button
                onClick={resetImage}
                className="bg-white/10 text-white px-4 py-2 rounded-lg font-bold flex items-center gap-2 hover:bg-white/20 transition-all backdrop-blur-md"
              >
                <X className="w-4 h-4" />
                Reset to Default
              </button>
            )}
            
            <div className="text-[10px] text-white/60 uppercase tracking-widest font-bold">
              Click to Upload
            </div>
          </>
        )}
      </div>

      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept="image/*"
        className="hidden"
      />
    </div>
  );
};
