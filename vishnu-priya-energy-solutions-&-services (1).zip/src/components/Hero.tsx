import React, { useState, useEffect, useRef, useCallback } from 'react';
import { ArrowRight, Zap, Activity, Shield, BarChart3, Globe, Cpu, Gauge, ChevronLeft, ChevronRight, Sun, Wind, Droplets, Flame, Atom, Factory, Edit2, Check, X, Upload, Image as ImageIcon, Settings } from 'lucide-react';
import { motion, useScroll, useTransform, useInView, AnimatePresence } from 'motion/react';
import { useEdit } from '../context/EditContext';
import { EditableContent } from './EditableContent';
import { EditableImage } from './EditableImage';
import { EditableButton } from './EditableButton';

interface HeroProps {
  setActivePage: (page: string) => void;
}

interface StatItem {
  id: string;
  label: string;
  value: number;
  suffix: string;
  prefix: string;
  icon: any;
}

const Counter = ({ value, suffix = "", prefix = "", decimals = 0 }: { value: number, suffix?: string, prefix?: string, decimals?: number }) => {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const prevValue = useRef(value);

  useEffect(() => {
    if (isInView) {
      let start = count;
      const end = value;
      const duration = 1000; // Faster animation
      const startTime = performance.now();
      
      const animate = (currentTime: number) => {
        const elapsed = currentTime - startTime;
        const progress = Math.min(elapsed / duration, 1);
        
        // Ease out quad
        const easeProgress = progress * (2 - progress);
        const currentCount = start + (end - start) * easeProgress;
        
        setCount(currentCount);
        
        if (progress < 1) {
          requestAnimationFrame(animate);
        } else {
          setCount(end);
        }
      };
      
      requestAnimationFrame(animate);
    } else {
      setCount(value);
    }
  }, [isInView, value]);

  return (
    <span ref={ref}>
      {prefix}{count.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}{suffix}
    </span>
  );
};

const HERO_IMAGES = [
  {
    id: 'solar',
    title: 'Solar Power Plant',
    url: 'https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&q=80&w=2000',
    icon: Sun,
    label: 'Solar'
  },
  {
    id: 'wind',
    title: 'Wind Turbines',
    url: 'https://images.unsplash.com/photo-1466611653911-95281773ad90?auto=format&fit=crop&q=80&w=2000',
    icon: Wind,
    label: 'Wind'
  },
  {
    id: 'thermal',
    title: 'Industrial Thermal Power Plant',
    url: 'https://images.unsplash.com/photo-1513828583688-c52646db42da?auto=format&fit=crop&q=80&w=2000',
    icon: Flame,
    label: 'Thermal'
  },
  {
    id: 'hydro',
    title: 'Hydroelectric Dam',
    url: 'https://images.unsplash.com/photo-1518005020250-675f04031729?auto=format&fit=crop&q=80&w=2000',
    icon: Droplets,
    label: 'Hydro'
  },
  {
    id: 'nuclear',
    title: 'Nuclear Power Plant',
    url: 'https://images.unsplash.com/photo-1517089596392-fb9a9033e05b?auto=format&fit=crop&q=80&w=2000',
    icon: Atom,
    label: 'Nuclear'
  },
  {
    id: 'green-future',
    title: 'Futuristic Renewable Smart Energy City',
    url: 'https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?auto=format&fit=crop&q=80&w=2000',
    icon: Factory,
    label: 'Green Future'
  }
];

const FileCheck = ({ className }: { className?: string }) => (
  <svg className={className} fill="none" viewBox="0 0 24 24" stroke="currentColor">
    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export default function Hero({ setActivePage }: HeroProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const [showBgManager, setShowBgManager] = useState(false);
  const { isEditMode, getContent, setContent, isAdmin } = useEdit();
  const [editingStatId, setEditingStatId] = useState<string | null>(null);
  const [editingValue, setEditingValue] = useState<string>("");
  const [editingPrefix, setEditingPrefix] = useState<string>("");
  const [editingSuffix, setEditingSuffix] = useState<string>("");
  
  const defaultStats: StatItem[] = [
    { id: 'audits', label: 'Energy Audits', value: 500, suffix: '+', prefix: '', icon: FileCheck },
    { id: 'clients', label: 'Industrial Clients', value: 120, suffix: '+', prefix: '', icon: Shield },
    { id: 'saved', label: 'Energy Saved', value: 25, suffix: 'M kWh', prefix: '', icon: Zap },
    { id: 'carbon', label: 'Carbon Reduction', value: 18000, suffix: ' Tons', prefix: '', icon: Globe },
    { id: 'cost', label: 'Cost Savings', value: 12, suffix: ' Cr+', prefix: '₹', icon: BarChart3 },
    { id: 'load', label: 'Load Factor', value: 78, suffix: '%', prefix: '', icon: Activity },
  ];

  const [stats, setStats] = useState<StatItem[]>(defaultStats);
  const [layout, setLayout] = useState<'split' | 'centered'>(getContent('hero_layout', 'split') as 'split' | 'centered');

  const toggleLayout = async () => {
    const newLayout = layout === 'split' ? 'centered' : 'split';
    setLayout(newLayout);
    await setContent('hero_layout', newLayout);
  };

  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 200]);

  const nextSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % HERO_IMAGES.length);
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + HERO_IMAGES.length) % HERO_IMAGES.length);
  }, []);

  useEffect(() => {
    if (isAutoPlaying) {
      const interval = setInterval(nextSlide, 5000);
      return () => clearInterval(interval);
    }
  }, [isAutoPlaying, nextSlide]);

  // Sync stats with Firestore
  useEffect(() => {
    const updated = defaultStats.map(stat => {
      const savedValue = getContent(`hero_stat_value_${stat.id}`, stat.value.toString());
      const savedPrefix = getContent(`hero_stat_prefix_${stat.id}`, stat.prefix);
      const savedSuffix = getContent(`hero_stat_suffix_${stat.id}`, stat.suffix);
      return {
        ...stat,
        value: Number(savedValue) || stat.value,
        prefix: savedPrefix,
        suffix: savedSuffix
      };
    });
    setStats(updated);
  }, [getContent]);

  const updateStat = async (id: string, newValue: number, newPrefix: string, newSuffix: string) => {
    if (isNaN(newValue) || !isAdmin) return;
    
    await Promise.all([
      setContent(`hero_stat_value_${id}`, newValue.toString()),
      setContent(`hero_stat_prefix_${id}`, newPrefix),
      setContent(`hero_stat_suffix_${id}`, newSuffix)
    ]);
    
    const updated = stats.map(s => s.id === id ? { ...s, value: newValue, prefix: newPrefix, suffix: newSuffix } : s);
    setStats(updated);
    setEditingStatId(null);
    setEditingValue("");
    setEditingPrefix("");
    setEditingSuffix("");
  };

  const startEditing = (stat: StatItem) => {
    setEditingStatId(stat.id);
    setEditingValue(stat.value.toString());
    setEditingPrefix(stat.prefix);
    setEditingSuffix(stat.suffix);
  };

  return (
    <section 
      className="relative min-h-screen flex flex-col justify-center overflow-hidden bg-[#020617]"
      onMouseEnter={() => setIsAutoPlaying(false)}
      onMouseLeave={() => setIsAutoPlaying(true)}
    >
      {/* Layout Toggle (Admin only) */}
      {isEditMode && isAdmin && (
        <div className="fixed top-32 left-8 z-50 flex flex-col gap-2">
          <button
            onClick={toggleLayout}
            className="flex items-center gap-2 px-4 py-2 bg-slate-900/80 backdrop-blur-md border border-white/10 rounded-xl text-white text-xs font-bold hover:bg-white/10 transition-all shadow-xl"
          >
            <Settings className="w-4 h-4 text-emerald-400" />
            {layout === 'split' ? 'Switch to Centered' : 'Switch to Split'}
          </button>
        </div>
      )}

      {/* Background Image Slider */}
      <div className="absolute inset-0 z-0">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, scale: 1.1 }}
            animate={{ opacity: 1, scale: 1.05 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className="absolute inset-0"
          >
            <EditableImage
              id={`hero_image_${HERO_IMAGES[currentIndex].id}`}
              defaultUrl={HERO_IMAGES[currentIndex].url}
              alt={HERO_IMAGES[currentIndex].title}
              className="w-full h-full object-cover"
            />
          </motion.div>
        </AnimatePresence>
        <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-[1px]" />
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/40 via-transparent to-slate-950" />
      </div>

      {/* SCADA Style Overlay */}
      <div className="absolute inset-0 z-1 pointer-events-none opacity-20">
        <div className="absolute inset-0" style={{ backgroundImage: 'radial-gradient(circle, #10b981 1px, transparent 1px)', backgroundSize: '40px 40px' }} />
        <svg className="w-full h-full">
          <defs>
            <pattern id="grid" width="100" height="100" patternUnits="userSpaceOnUse">
              <path d="M 100 0 L 0 0 0 100" fill="none" stroke="#10b981" strokeWidth="0.5" strokeOpacity="0.3" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid)" />
          
          <motion.path
            d="M 100 100 L 300 100 L 300 300"
            fill="none"
            stroke="#10b981"
            strokeWidth="1"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          />
          <motion.circle
            r="3"
            fill="#10b981"
            animate={{ cx: [100, 300, 300], cy: [100, 100, 300] }}
            transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
          />
        </svg>
      </div>

      {/* Energy Particles */}
      <div className="absolute inset-0 z-1 pointer-events-none">
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-1 h-1 bg-emerald-400 rounded-full shadow-[0_0_10px_#10b981]"
            initial={{ 
              x: Math.random() * 100 + "%", 
              y: Math.random() * 100 + "%",
              opacity: 0 
            }}
            animate={{ 
              y: [null, "-10%"],
              opacity: [0, 1, 0]
            }}
            transition={{ 
              duration: Math.random() * 5 + 5, 
              repeat: Infinity, 
              delay: Math.random() * 5 
            }}
          />
        ))}
      </div>

      {/* Admin Background Manager Button */}
      {isEditMode && (
        <div className="absolute top-24 right-8 z-40">
          <button
            onClick={() => setShowBgManager(true)}
            className="flex items-center gap-3 px-6 py-3 rounded-2xl bg-emerald-600 text-white font-bold shadow-[0_0_30px_rgba(16,185,129,0.4)] hover:bg-emerald-500 transition-all border border-emerald-400/50 group"
          >
            <div className="p-1.5 bg-white/20 rounded-lg group-hover:rotate-12 transition-transform">
              <Upload className="w-4 h-4" />
            </div>
            <span className="uppercase tracking-widest text-xs">Manage All Backgrounds</span>
          </button>
        </div>
      )}

      {/* Manual Controls */}
      <div className="absolute inset-y-0 left-4 flex items-center z-30">
        <button 
          onClick={prevSlide}
          className="p-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white transition-all backdrop-blur-md"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
      </div>
      <div className="absolute inset-y-0 right-4 flex items-center z-30">
        <button 
          onClick={nextSlide}
          className="p-2 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-white transition-all backdrop-blur-md"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
      </div>

      {/* Indicator Dots */}
      <div className="absolute bottom-24 left-1/2 -translate-x-1/2 flex gap-3 z-30">
        {HERO_IMAGES.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentIndex(i)}
            className={`h-1 transition-all duration-500 rounded-full ${currentIndex === i ? 'w-8 bg-emerald-500' : 'w-2 bg-white/30 hover:bg-white/50'}`}
          />
        ))}
      </div>

      {/* Energy Tabs Interaction (Ribbon Navigation) */}
      <div className="absolute top-28 left-1/2 -translate-x-1/2 z-30 w-full max-w-4xl px-4">
        <div className="flex items-center gap-2 p-1.5 bg-slate-900/60 backdrop-blur-2xl border border-white/10 rounded-2xl overflow-x-auto no-scrollbar shadow-2xl shadow-black/50">
          {HERO_IMAGES.map((tab, i) => (
            <button
              key={tab.id}
              onClick={() => {
                setCurrentIndex(i);
                setIsAutoPlaying(false); // Pause autoplay when user interacts
              }}
              className={`flex flex-col items-start gap-1 px-5 py-3 rounded-xl transition-all shrink-0 border ${
                currentIndex === i 
                  ? 'bg-emerald-600/20 text-white shadow-[0_0_20px_rgba(16,185,129,0.2)] border-emerald-500/50' 
                  : 'text-slate-400 hover:text-white hover:bg-white/5 border-transparent'
              }`}
            >
              <div className="flex items-center gap-2">
                <tab.icon className={`w-4 h-4 ${currentIndex === i ? 'text-emerald-400' : 'text-emerald-500/50'}`} />
                <span className="text-[10px] sm:text-xs font-black uppercase tracking-widest">{tab.label}</span>
              </div>
              <div className="flex items-center gap-1.5">
                <div className={`w-1.5 h-1.5 rounded-full ${currentIndex === i ? 'bg-emerald-400 animate-pulse' : 'bg-slate-700'}`} />
                <span className="text-[8px] font-mono opacity-60">SYSTEM_READY</span>
              </div>
            </button>
          ))}
          
          {isEditMode && (
            <button
              onClick={() => setShowBgManager(true)}
              className="ml-auto flex items-center gap-2 px-4 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 hover:bg-emerald-500/30 transition-all shrink-0"
              title="Manage All Backgrounds"
            >
              <ImageIcon className="w-4 h-4" />
              Manage
            </button>
          )}
        </div>
      </div>

      <div className={`max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full pt-56 pb-20 ${layout === 'centered' ? 'text-center' : ''}`}>
        <div className={`grid gap-16 items-center ${layout === 'centered' ? 'grid-cols-1 max-w-4xl mx-auto' : 'lg:grid-cols-2'}`}>
          <motion.div
            key={`content-${currentIndex}-${layout}`}
            initial={{ opacity: 0, x: layout === 'centered' ? 0 : -50, y: layout === 'centered' ? 20 : 0 }}
            animate={{ opacity: 1, x: 0, y: 0 }}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 backdrop-blur-sm ${layout === 'centered' ? 'mx-auto' : ''}`}>
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-xs font-bold tracking-[0.2em] text-emerald-400 uppercase">
                <EditableContent id="hero_platform_tag" defaultValue="Vishnu Priya Energy Solutions & Services (VPESCO)" />
              </span>
            </div>

            <h1 className="text-6xl lg:text-8xl font-bold text-white leading-[1.1] tracking-tight">
              <EditableContent id="hero_title" defaultValue="Powering a Sustainable Future" multiline />
            </h1>

            <p className="text-2xl text-emerald-100/80 font-medium leading-relaxed">
              <EditableContent id="hero_subtitle" defaultValue="Advanced Energy Audit & Optimization Solutions" />
            </p>

            <span className={`text-lg text-slate-400 leading-relaxed max-w-xl block ${layout === 'centered' ? 'mx-auto' : ''}`}>
              <EditableContent id="hero_description" defaultValue="Vishnu Priya Energy Saving Company (VPESCO) provides cutting-edge energy optimization and sustainability solutions for a greener tomorrow." multiline />
            </span>
            
            <div className={`flex flex-col sm:flex-row gap-6 pt-4 ${layout === 'centered' ? 'justify-center' : ''}`}>
              <EditableButton 
                id="hero_cta_audit"
                defaultText="Request Energy Audit"
                defaultUrl="#contact"
                className="relative group overflow-hidden bg-emerald-600 text-white px-10 py-5 rounded-xl font-bold transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] flex items-center justify-center gap-3 text-lg"
                icon={ArrowRight}
              />
              <EditableButton 
                id="hero_cta_platform"
                defaultText="View Intelligence Platform"
                defaultUrl="#intelligence"
                className="bg-white/5 backdrop-blur-md text-white border border-white/10 px-10 py-5 rounded-xl font-bold hover:bg-white/10 transition-all flex items-center justify-center text-lg"
              />
            </div>
          </motion.div>

          {/* Live Data Counters Grid */}
          <motion.div 
            initial={{ opacity: 0, x: layout === 'centered' ? 0 : 50, y: layout === 'centered' ? 20 : 0 }}
            animate={{ opacity: 1, x: 0, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className={`grid grid-cols-2 gap-4 ${layout === 'centered' ? 'mt-12' : ''}`}
          >
            {stats.map((stat, i) => (
              <div key={i} className="relative p-6 rounded-2xl bg-slate-900/40 backdrop-blur-md border border-white/5 hover:border-emerald-500/30 transition-all group overflow-hidden">
                {isEditMode && (
                  <div className="absolute top-2 right-2 z-20">
                    <button 
                      onClick={() => startEditing(stat)}
                      className="p-1.5 bg-emerald-500 rounded-md text-white hover:bg-emerald-400 transition-colors"
                    >
                      <Edit2 className="w-3 h-3" />
                    </button>
                  </div>
                )}

                <stat.icon className="w-6 h-6 text-emerald-500 mb-4 group-hover:scale-110 transition-transform" />
                
                {editingStatId === stat.id ? (
                  <div className="flex flex-col gap-2">
                    <div className="flex items-center gap-2">
                      <input 
                        type="text"
                        value={editingPrefix}
                        onChange={(e) => setEditingPrefix(e.target.value)}
                        placeholder="Prefix"
                        className="w-12 bg-slate-800 border border-emerald-500/30 rounded px-1 py-1 text-[10px] text-white"
                      />
                      <input 
                        type="number"
                        value={editingValue}
                        onChange={(e) => setEditingValue(e.target.value)}
                        autoFocus
                        className="w-full bg-slate-800 border border-emerald-500 rounded px-2 py-1 text-white font-bold"
                      />
                      <input 
                        type="text"
                        value={editingSuffix}
                        onChange={(e) => setEditingSuffix(e.target.value)}
                        placeholder="Suffix"
                        className="w-12 bg-slate-800 border border-emerald-500/30 rounded px-1 py-1 text-[10px] text-white"
                      />
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => updateStat(stat.id, Number(editingValue), editingPrefix, editingSuffix)}
                        className="flex-1 bg-emerald-600 py-1 rounded text-[10px] font-bold uppercase"
                      >
                        Save
                      </button>
                      <button 
                        onClick={() => {
                          setEditingStatId(null);
                          setEditingValue("");
                        }}
                        className="flex-1 bg-slate-700 py-1 rounded text-[10px] font-bold uppercase"
                      >
                        Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="text-3xl font-bold text-white mb-1">
                    <Counter value={stat.value} prefix={stat.prefix} suffix={stat.suffix} />
                  </div>
                )}
                
                <span className="text-xs uppercase tracking-widest text-slate-500 font-bold block">
                  <EditableContent id={`hero_stat_label_${stat.id}`} defaultValue={stat.label} />
                </span>
              </div>
            ))}
          </motion.div>
        </div>
      </div>

      {/* Carbon Reduction Ticker */}
      <div className="absolute bottom-0 left-0 w-full bg-slate-950/80 backdrop-blur-xl border-t border-white/5 py-4 overflow-hidden z-20">
        <div className="flex whitespace-nowrap animate-marquee">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="flex items-center gap-12 px-6">
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <EditableContent id="ticker_label_1" defaultValue="Carbon Saved Today:" />
                </span>
                <span className="text-sm font-mono text-emerald-400">
                  <EditableContent id="ticker_value_1" defaultValue="+2.4 Tons CO₂" />
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <EditableContent id="ticker_label_2" defaultValue="Energy Optimized:" />
                </span>
                <span className="text-sm font-mono text-blue-400">
                  <EditableContent id="ticker_value_2" defaultValue="+18,500 kWh" />
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
                  <EditableContent id="ticker_label_3" defaultValue="Savings Generated:" />
                </span>
                <span className="text-sm font-mono text-amber-400">
                  <EditableContent id="ticker_value_3" defaultValue="₹3,25,000" />
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Background Manager Modal */}
      <AnimatePresence>
        {showBgManager && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-xl"
          >
            <motion.div
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-slate-900 border border-white/10 rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl"
            >
              <div className="p-6 border-bottom border-white/5 flex items-center justify-between bg-slate-800/50">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-emerald-500/20 rounded-lg">
                    <ImageIcon className="w-6 h-6 text-emerald-500" />
                  </div>
                  <div>
                    <h2 className="text-xl font-bold text-white">Hero Background Manager</h2>
                    <p className="text-sm text-slate-400">Upload custom images for each energy sector ribbon</p>
                  </div>
                </div>
                <button 
                  onClick={() => setShowBgManager(false)}
                  className="p-2 hover:bg-white/5 rounded-full text-slate-400 hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="p-6 overflow-y-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {HERO_IMAGES.map((category) => (
                  <div key={category.id} className="space-y-3">
                    <div className="flex items-center gap-2 text-sm font-bold text-emerald-400 uppercase tracking-wider">
                      <category.icon className="w-4 h-4" />
                      {category.label}
                    </div>
                    <div className="aspect-video rounded-xl overflow-hidden border border-white/10 bg-slate-800 relative group">
                      <EditableImage
                        id={`hero_image_${category.id}`}
                        defaultUrl={category.url}
                        alt={category.title}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <p className="text-[10px] text-slate-500 uppercase font-bold tracking-widest">
                      ID: hero_image_{category.id}
                    </p>
                  </div>
                ))}
              </div>

              <div className="p-6 border-t border-white/5 bg-slate-800/30 flex justify-end">
                <button
                  onClick={() => setShowBgManager(false)}
                  className="bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-emerald-500 transition-all shadow-lg shadow-emerald-600/20"
                >
                  Done Managing
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-33.33%); }
        }
        .animate-marquee {
          animation: marquee 30s linear infinite;
        }
        .animate-spin-slow {
          animation: spin 8s linear infinite;
        }
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .no-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}} />
    </section>
  );
}
