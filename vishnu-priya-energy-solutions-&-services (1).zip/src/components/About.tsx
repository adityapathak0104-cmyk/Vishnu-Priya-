import React from 'react';
import { CheckCircle2 } from 'lucide-react';
import { motion } from 'motion/react';
import { EditableContent } from './EditableContent';
import { EditableImage } from './EditableImage';

export default function AboutSection() {
  const benefits = [
    { id: 'benefit_1', default: 'Finance-driven electricity cost analysis' },
    { id: 'benefit_2', default: 'Independent advisory (no equipment sales)' },
    { id: 'benefit_3', default: 'Structured analytical methodology' },
    { id: 'benefit_4', default: 'Regulatory awareness and tariff expertise' },
    { id: 'benefit_5', default: 'Focus on long-term cost optimization' },
    { id: 'benefit_6', default: 'Boardroom-level strategic insights' },
  ];

  return (
    <section className="py-32 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-24 items-center">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="text-[#15803d] font-black uppercase tracking-[0.3em] text-xs mb-8">
              <EditableContent id="about_tag" defaultValue="About VPESCO" />
            </div>
            <h2 className="text-5xl lg:text-7xl font-serif text-slate-900 mb-10 leading-[1.1] tracking-tight">
              <EditableContent id="about_title" defaultValue="Boardroom-Level Energy Advisory" multiline />
            </h2>
            <div className="space-y-6 text-lg text-slate-600 leading-relaxed font-light">
              <EditableContent 
                as="p" 
                id="about_p1" 
                defaultValue="Vishnu Priya Energy Solutions & Services (VPESCO) is a specialized energy advisory firm focused on electricity cost optimization, regulatory strategy, and power procurement advisory for industrial and commercial consumers. (Under Incorporation)" 
                multiline 
              />
              <EditableContent 
                as="p" 
                id="about_p2" 
                defaultValue="VPESCO operates at the intersection of energy markets, regulatory frameworks, and financial analysis, enabling organizations to manage electricity cost as a strategic financial variable rather than a routine expense." 
                multiline 
              />
              <EditableContent 
                as="p" 
                id="about_p3" 
                defaultValue="We assist clients in navigating complex power procurement mechanisms including Open Access, and provide structured advisory on Long-Term Access (LTA), Medium-Term Open Access (MTOA), and Short-Term Access (STA) power sourcing strategies. Our services include detailed energy invoice analysis, tariff interpretation, and regulatory assessment to identify cost-saving opportunities and ensure compliance with evolving electricity regulations across multiple states." 
                multiline 
              />
              <div className="font-serif italic text-slate-900 border-l-4 border-emerald-100 pl-6 py-2">
                <EditableContent 
                  id="about_quote" 
                  defaultValue='"Managing Electricity Cost as a Financial Risk, Not Just an Expense."' 
                  multiline 
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-8 gap-y-4 mt-12">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-center gap-4 group cursor-default">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 group-hover:scale-150 transition-transform" />
                  <span className="font-bold text-slate-900 text-sm tracking-tight">
                    <EditableContent id={benefit.id} defaultValue={benefit.default} />
                  </span>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            <div className="relative rounded-3xl overflow-hidden shadow-2xl aspect-[4/3]">
              <EditableImage 
                id="about_main_image"
                defaultUrl="https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?auto=format&fit=crop&q=80&w=1000" 
                alt="Industrial facility engineering" 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-emerald-600/10 pointer-events-none" />
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -bottom-8 -right-8 w-48 h-48 bg-emerald-600/5 rounded-full blur-2xl" />
            <div className="absolute -top-8 -left-8 w-32 h-32 bg-blue-600/5 rounded-full blur-xl" />
          </motion.div>
        </div>

      </div>
    </section>
  );
}
