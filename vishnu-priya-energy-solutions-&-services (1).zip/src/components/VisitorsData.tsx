import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Mail, 
  FileText, 
  ExternalLink, 
  Calendar, 
  MapPin, 
  Search, 
  Download,
  Filter,
  ArrowUpDown,
  Loader2,
  Trash2,
  Paperclip
} from 'lucide-react';
import { db, auth } from '../firebase';
import { collection, query, orderBy, onSnapshot, deleteDoc, doc, Timestamp } from 'firebase/firestore';
import { useEdit } from '../context/EditContext';
import { toast } from 'sonner';
import { motion, AnimatePresence } from 'motion/react';

interface VisitorSubmission {
  id: string;
  email: string;
  location: string;
  clientName: string;
  driveLink: string;
  timestamp: Timestamp;
  auditData?: any;
}

export default function VisitorsData() {
  const { isAdmin } = useEdit();
  const [submissions, setSubmissions] = useState<VisitorSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  useEffect(() => {
    if (!isAdmin) return;

    const q = query(collection(db, 'visitor_submissions'), orderBy('timestamp', sortOrder));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const data = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as VisitorSubmission[];
      setSubmissions(data);
      setLoading(false);
    }, (error) => {
      console.error("Error fetching visitor submissions:", error);
      toast.error("Failed to load visitor data");
      setLoading(false);
    });

    return () => unsubscribe();
  }, [isAdmin, sortOrder]);

  const handleDelete = async (id: string) => {
    if (!window.confirm("Are you sure you want to delete this record?")) return;
    
    try {
      await deleteDoc(doc(db, 'visitor_submissions', id));
      toast.success("Record deleted successfully");
    } catch (error) {
      console.error("Error deleting record:", error);
      toast.error("Failed to delete record");
    }
  };

  const filteredSubmissions = submissions.filter(sub => 
    sub.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sub.clientName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    sub.location?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="text-center p-8 bg-white rounded-3xl shadow-xl border border-slate-100 max-w-md">
          <Users className="w-16 h-16 text-slate-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-slate-900 mb-2">Access Restricted</h2>
          <p className="text-slate-600">Only administrators can view visitor data.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#f8fafc] py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
          <div>
            <h1 className="text-4xl font-bold text-slate-900 mb-2 tracking-tight flex items-center gap-3">
              <Users className="w-10 h-10 text-emerald-600" />
              Visitors Data
            </h1>
            <p className="text-lg text-slate-600">
              Manage and track all electricity bill submissions from your visitors.
            </p>
          </div>
          
          <div className="flex flex-wrap items-center gap-4">
            {/* Quick Access Links */}
            <div className="flex items-center gap-3 mr-4">
              <a 
                href="https://drive.google.com/drive/folders/1gniSSv_o9L0-PtAJwVRJf1RzsHUQwOg7" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-3 bg-white border border-slate-200 rounded-2xl text-slate-700 font-bold hover:bg-slate-50 transition-all shadow-sm group"
              >
                <div className="w-8 h-8 rounded-lg bg-blue-50 flex items-center justify-center text-blue-600 group-hover:bg-blue-100">
                  <Download className="w-4 h-4" />
                </div>
                Drive Folder (Bills & Sheets)
                <ExternalLink className="w-3 h-3 text-slate-400" />
              </a>
            </div>

            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input 
                type="text" 
                placeholder="Search by email or client..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-12 pr-6 py-3 bg-white border border-slate-200 rounded-2xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 transition-all w-full md:w-80 shadow-sm"
              />
            </div>
            <button 
              onClick={() => setSortOrder(prev => prev === 'asc' ? 'desc' : 'asc')}
              className="p-3 bg-white border border-slate-200 rounded-2xl hover:bg-slate-50 transition-all shadow-sm"
              title="Toggle Sort Order"
            >
              <ArrowUpDown className="w-5 h-5 text-slate-600" />
            </button>
          </div>
        </div>

        {loading ? (
          <div className="flex flex-col items-center justify-center py-32">
            <Loader2 className="w-12 h-12 text-emerald-600 animate-spin mb-4" />
            <p className="text-slate-500 font-medium">Loading visitor submissions...</p>
          </div>
        ) : filteredSubmissions.length === 0 ? (
          <div className="text-center py-32 bg-white rounded-[3rem] border border-slate-100 shadow-sm">
            <Users className="w-20 h-20 text-slate-200 mx-auto mb-6" />
            <h3 className="text-2xl font-bold text-slate-900 mb-2">No Submissions Found</h3>
            <p className="text-slate-500">When visitors upload bills, they will appear here.</p>
          </div>
        ) : (
          <div className="bg-white rounded-[3rem] shadow-xl border border-slate-100 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-100">
                    <th className="px-8 py-6 text-xs font-black text-slate-400 uppercase tracking-widest">Visitor Info</th>
                    <th className="px-8 py-6 text-xs font-black text-slate-400 uppercase tracking-widest">Client / Location</th>
                    <th className="px-8 py-6 text-xs font-black text-slate-400 uppercase tracking-widest">Submission Date</th>
                    <th className="px-8 py-6 text-xs font-black text-slate-400 uppercase tracking-widest">Drive Attachment</th>
                    <th className="px-8 py-6 text-xs font-black text-slate-400 uppercase tracking-widest text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-50">
                  <AnimatePresence mode="popLayout">
                    {filteredSubmissions.map((sub) => (
                      <motion.tr 
                        key={sub.id}
                        layout
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        className="hover:bg-slate-50/50 transition-colors group"
                      >
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600">
                              <Mail className="w-5 h-5" />
                            </div>
                            <div>
                              <p className="font-bold text-slate-900">{sub.email}</p>
                              <p className="text-xs text-slate-500">Visitor Email</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div>
                            <p className="font-bold text-slate-900">{sub.clientName}</p>
                            <p className="text-xs text-slate-500 flex items-center gap-1">
                              <MapPin className="w-3 h-3" /> {sub.location}
                            </p>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <div className="flex items-center gap-2 text-slate-600">
                            <Calendar className="w-4 h-4" />
                            <span className="text-sm">
                              {sub.timestamp?.toDate().toLocaleDateString()}
                            </span>
                          </div>
                        </td>
                        <td className="px-8 py-6">
                          <a 
                            href={sub.driveLink} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-600 rounded-xl text-xs font-bold hover:bg-blue-100 transition-all border border-blue-100"
                          >
                            <Paperclip className="w-3 h-3" />
                            Drive Attachment
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </td>
                        <td className="px-8 py-6 text-right">
                          <button 
                            onClick={() => handleDelete(sub.id)}
                            className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                            title="Delete Record"
                          >
                            <Trash2 className="w-5 h-5" />
                          </button>
                        </td>
                      </motion.tr>
                    ))}
                  </AnimatePresence>
                </tbody>
              </table>
            </div>
            
            <div className="p-8 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
              <p className="text-sm text-slate-500">
                Showing <span className="font-bold text-slate-900">{filteredSubmissions.length}</span> submissions
              </p>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">Real-time Sync Active</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
