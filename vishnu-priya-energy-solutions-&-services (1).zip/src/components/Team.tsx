import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Search, UserX, Edit2, Users } from 'lucide-react';
import { EditableContent } from './EditableContent';
import { EditableImage } from './EditableImage';
import { useEdit } from '../context/EditContext';
import { collection, onSnapshot, query, orderBy, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db, auth, handleFirestoreError, OperationType } from '../firebase';
import { toast } from 'sonner';

interface TeamMember {
  id: string;
  name: string;
  role: string;
  category: string;
  description: string;
  focus?: string[];
  image: string;
  order?: number;
  email?: string;
}

const defaultTeam: TeamMember[] = [
  {
    id: '1',
    name: 'Aditya Pathak',
    role: 'FOUNDER – VISHNU PRIYA ENERGY SOLUTIONS & SERVICES (VPESCO)',
    category: 'Board Members',
    description: 'Aditya Pathak is an Industrial Electricity Cost & Tariff Advisory Professional with a strong foundation in audit, financial analysis, and regulatory exposure across the power and manufacturing sectors.\n\nHe began his professional journey as an Audit & Accounts Associate at a Chartered Accountancy firm, where he worked on concurrent and internal audits for PSUs and manufacturing entities. During this period, he developed expertise in financial reporting, cost analysis, variance analysis, and efficiency evaluation, while also managing audit engagements end-to-end.\n\nHis exposure to power sector operations and industrial cost structures led him to identify a critical gap — lack of structured electricity cost optimization for industries.\n\nWith this insight, he founded Vishnu Priya Energy Solutions & Services (VPESCO), with a focus on helping industrial and commercial consumers reduce electricity expenditure through power billing analysis, forensic review, tariff optimization, and contract demand strategy.\n\nHis approach combines financial discipline with technical understanding of electricity billing systems, enabling businesses to achieve measurable and sustainable cost savings.',
    focus: [
      'Power billing analysis & forensic review',
      'Electricity tariff optimization',
      'Contract demand strategy',
      'Billing inefficiencies & cost leakages'
    ],
    image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=400',
    order: 1,
    email: 'adityapathak0104@gmail.com'
  },
  {
    id: '2',
    name: 'Abhishek',
    role: 'Board Member',
    category: 'Board Members',
    description: 'Strategic advisor focusing on operational excellence and regulatory compliance.',
    focus: ['Operations', 'Regulatory Strategy', 'Compliance'],
    image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=400',
    order: 2
  },
  {
    id: '3',
    name: 'Kartvya Kumar Biswas',
    role: 'Board Member',
    category: 'Board Members',
    description: 'Expert in technical implementation and energy audit methodologies.',
    focus: ['Energy Audit', 'Technical Analysis', 'Implementation'],
    image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=400',
    order: 3
  },
  {
    id: '4',
    name: 'Elena Rodriguez',
    role: 'Sustainability Consultant',
    category: 'Team Staff',
    description: 'Helping commercial clients achieve net-zero targets through innovative HVAC solutions.',
    image: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&q=80&w=400',
    order: 11
  },
  {
    id: '5',
    name: 'David Wilson',
    role: 'Technical Engineer',
    category: 'Team Staff',
    description: 'Expert in motor and pump efficiency optimization and preventive maintenance.',
    image: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=400',
    order: 12
  },
  {
    id: '6',
    name: 'Priya Sharma',
    role: 'Project Manager',
    category: 'Team Staff',
    description: 'Ensuring seamless delivery of energy audit projects across multiple industrial sites.',
    image: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&q=80&w=400',
    order: 13
  }
];

export default function TeamSection() {
  const [team, setTeam] = useState<TeamMember[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editForm, setEditForm] = useState<Partial<TeamMember>>({});
  const { isEditMode, isAdmin, user } = useEdit();

  const canEdit = (member: TeamMember) => isAdmin || (user?.email === member.email && user?.emailVerified);

  useEffect(() => {
    const q = query(collection(db, 'team'), orderBy('order', 'asc'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      if (snapshot.empty) {
        setTeam(defaultTeam);
      } else {
        const members = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        })) as TeamMember[];
        setTeam(members);
      }
    }, (error) => {
      console.error("Team Sync Error:", error);
      setTeam(defaultTeam);
    });

    return () => unsubscribe();
  }, []);

  const filteredTeam = team.filter(member => 
    member.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
    member.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (member.description && member.description.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const boardMembers = filteredTeam.filter(m => m.category === 'Board Members');
  const teamStaff = filteredTeam.filter(m => m.category === 'Team Staff');

  const handleSave = async () => {
    if (!selectedMember) return;
    const path = `team/${selectedMember.id}`;
    try {
      const memberRef = doc(db, 'team', selectedMember.id);
      
      // Ensure we don't send extra fields that might fail validation
      const { ...dataToSave } = {
        ...selectedMember,
        ...editForm,
        updatedAt: serverTimestamp()
      };
      
      await setDoc(memberRef, dataToSave, { merge: true });
      
      toast.success('Profile updated successfully');
      setIsEditing(false);
      setSelectedMember(prev => prev ? { ...prev, ...editForm } : null);
    } catch (error) {
      console.error("Failed to update profile", error);
      try {
        handleFirestoreError(error, OperationType.WRITE, path);
      } catch (e) {
        // The error is already logged to console as JSON by handleFirestoreError
        toast.error('Failed to update profile. You may not have permission.');
      }
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 800000) {
        toast.error("Image is too large. Please select an image under 800KB.");
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        setEditForm(prev => ({ ...prev, image: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <section id="team" className="py-24 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-5xl font-bold text-slate-900 mb-4">
            <EditableContent id="team_title" defaultValue="Our Board Members & Team Staff" />
          </h2>
          <p className="text-slate-500 text-lg max-w-2xl mx-auto">
            <EditableContent id="team_subtitle" defaultValue="Strategic leadership and dedicated professionals driving energy excellence" />
          </p>
          <div className="w-24 h-1.5 bg-emerald-500 mx-auto rounded-full mt-6" />
        </div>

        {/* Search Bar */}
        <div className="max-w-4xl mx-auto mb-20 flex flex-col md:flex-row gap-6 items-center">
          <div className="relative group flex-1 w-full">
            <div className="absolute inset-y-0 left-6 flex items-center pointer-events-none">
              <Search className="w-5 h-5 text-slate-400 group-focus-within:text-emerald-500 transition-colors" />
            </div>
            <input 
              type="text" 
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search for board members or team staff..." 
              className="w-full pl-16 pr-6 py-5 bg-white border border-slate-200 rounded-[2rem] shadow-sm focus:outline-none focus:ring-4 focus:ring-emerald-500/10 focus:border-emerald-500 transition-all text-lg"
            />
          </div>
          
          {isEditMode && isAdmin && (
            <a 
              href="/vpesco-admin.html"
              target="_blank"
              className="flex items-center gap-3 px-8 py-5 bg-emerald-600 text-white font-bold rounded-[2rem] shadow-lg shadow-emerald-900/20 hover:bg-emerald-500 transition-all shrink-0"
            >
              <Users className="w-5 h-5" />
              Manage Team Members
            </a>
          )}
        </div>

        {/* Board Members */}
        <div className="mb-32">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-slate-900 mb-4">Our Board Members</h3>
            <div className="w-16 h-1 bg-emerald-500 mx-auto rounded-full" />
          </div>
          
          <div className="space-y-16">
            {boardMembers.map((member) => (
              <motion.div 
                key={member.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="bg-white p-8 md:p-16 rounded-[4rem] shadow-sm border border-slate-100 flex flex-col lg:flex-row gap-12 items-center lg:items-start transition-all hover:shadow-xl hover:shadow-emerald-900/5"
              >
                <div className="flex-1 order-2 lg:order-1">
                  <p className="text-emerald-600 font-bold uppercase tracking-[0.3em] text-[10px] mb-4">The Leadership</p>
                  <h3 className="text-5xl md:text-6xl font-serif text-slate-900 mb-4 leading-tight">
                    <EditableContent id={`team_member_${member.id}_name`} defaultValue={member.name} />
                  </h3>
                  <p className="text-emerald-600 font-bold uppercase tracking-wider text-sm mb-8 leading-tight">
                    <EditableContent id={`team_member_${member.id}_role`} defaultValue={member.role} />
                  </p>
                  
                  <div className="space-y-6 text-slate-500 leading-relaxed text-lg">
                    <EditableContent id={`team_member_${member.id}_desc`} defaultValue={member.description} multiline />
                  </div>

                  <button 
                    onClick={() => setSelectedMember(member)}
                    className="mt-8 px-8 py-3 bg-slate-900 text-white font-bold rounded-full hover:bg-emerald-600 transition-all flex items-center gap-2 group"
                  >
                    More Details
                    <motion.span
                      animate={{ x: [0, 5, 0] }}
                      transition={{ repeat: Infinity, duration: 1.5 }}
                    >
                      →
                    </motion.span>
                  </button>
                </div>
                
                <div className="w-full lg:w-[450px] order-1 lg:order-2 flex flex-col gap-8">
                  <div className="relative">
                    <div className="aspect-square rounded-full overflow-hidden border-[12px] border-white shadow-2xl relative z-10">
                      <EditableImage 
                        id={`team_member_${member.id}_image`}
                        defaultUrl={member.image}
                        alt={member.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="absolute inset-0 bg-emerald-500/10 rounded-full blur-3xl -z-10 translate-y-8" />
                  </div>

                  {member.focus && (
                    <div className="bg-slate-50 p-10 rounded-[2.5rem] border border-slate-100">
                      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-6">Core Focus Areas</p>
                      <ul className="space-y-4">
                        {member.focus.map((f, i) => (
                          <li key={i} className="flex items-start gap-3 text-slate-700 font-medium">
                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 shrink-0" />
                            <EditableContent id={`team_member_${member.id}_focus_${i}`} defaultValue={f} />
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Team Staff */}
        <div>
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-slate-900 mb-4">Our Team Staff</h3>
            <div className="w-16 h-1 bg-emerald-500 mx-auto rounded-full" />
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {teamStaff.map((member) => (
              <motion.div 
                key={member.id}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="group bg-white p-8 rounded-[2.5rem] shadow-xl border border-slate-100 transition-all hover:-translate-y-2 hover:shadow-2xl"
              >
                <div className="w-24 h-24 rounded-2xl overflow-hidden mb-6">
                  <EditableImage 
                    id={`team_member_${member.id}_image`}
                    defaultUrl={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover transition-transform group-hover:scale-110"
                  />
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-1">
                  <EditableContent id={`team_member_${member.id}_name`} defaultValue={member.name} />
                </h3>
                <p className="text-emerald-600 font-bold text-xs uppercase tracking-widest mb-4">
                  <EditableContent id={`team_member_${member.id}_role`} defaultValue={member.role} />
                </p>
                <p className="text-slate-500 text-sm leading-relaxed mb-6">
                  <EditableContent id={`team_member_${member.id}_desc`} defaultValue={member.description} multiline />
                </p>
                <button 
                  onClick={() => setSelectedMember(member)}
                  className="text-emerald-600 font-bold text-sm hover:text-emerald-700 transition-colors flex items-center gap-2"
                >
                  More Details →
                </button>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Empty State */}
        {searchTerm && filteredTeam.length === 0 && (
          <div className="text-center py-20">
            <UserX className="w-16 h-16 text-slate-200 mx-auto mb-4" />
            <p className="text-slate-400 text-xl">No members found matching "{searchTerm}"</p>
          </div>
        )}

        {/* Member Details Modal */}
        <AnimatePresence>
          {selectedMember && (
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6">
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                onClick={() => setSelectedMember(null)}
                className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm"
              />
              <motion.div
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.9, y: 20 }}
                className="relative w-full max-w-3xl bg-white rounded-[3rem] shadow-2xl overflow-hidden overflow-y-auto max-h-[90vh]"
              >
                <button 
                  onClick={() => setSelectedMember(null)}
                  className="absolute top-8 right-8 w-12 h-12 flex items-center justify-center rounded-full bg-slate-100 text-slate-500 hover:bg-emerald-500 hover:text-white transition-all z-10"
                >
                  ✕
                </button>

                <div className="p-8 md:p-12 lg:p-16">
                  <div className="flex flex-col md:flex-row justify-between items-start gap-8 mb-12">
                    <div className="flex items-center gap-6">
                      <div className="relative group">
                        <div className="w-24 h-24 md:w-32 md:h-32 rounded-full overflow-hidden border-4 border-white shadow-xl relative z-10 bg-slate-100">
                          <img 
                            src={isEditing ? editForm.image : selectedMember.image} 
                            alt={selectedMember.name}
                            className="w-full h-full object-cover"
                            referrerPolicy="no-referrer"
                          />
                          {isEditing && (
                            <label className="absolute inset-0 bg-slate-900/60 flex flex-col items-center justify-center text-white cursor-pointer opacity-0 group-hover:opacity-100 transition-opacity z-20">
                              <Edit2 className="w-4 h-4 mb-1" />
                              <span className="text-[8px] font-bold">Edit</span>
                              <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
                            </label>
                          )}
                        </div>
                        <div className="absolute inset-0 bg-emerald-500/10 rounded-full blur-2xl -z-10 translate-y-4" />
                      </div>
                      <div>
                        <p className="text-emerald-600 font-bold uppercase tracking-[0.3em] text-[10px] mb-1">
                          {selectedMember.name === 'Aditya Pathak' ? 'The Founder' : selectedMember.category}
                        </p>
                        <h3 className="text-3xl md:text-4xl font-serif text-slate-900 leading-tight">
                          {selectedMember.name}
                        </h3>
                      </div>
                    </div>

                    {canEdit(selectedMember) && !isEditing && (
                      <button 
                        onClick={() => {
                          setIsEditing(true);
                          setEditForm(selectedMember);
                        }}
                        className="flex items-center gap-2 px-4 py-2 bg-slate-50 text-slate-600 rounded-full text-xs font-bold hover:bg-emerald-50 hover:text-emerald-600 transition-all border border-slate-100"
                      >
                        <Edit2 className="w-3 h-3" />
                        Edit Profile
                      </button>
                    )}
                  </div>

                  {isEditing ? (
                    <div className="space-y-8">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 block">Full Name</label>
                          <input 
                            type="text" 
                            value={editForm.name || ''}
                            onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                          />
                        </div>
                        <div>
                          <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 block">Core Focus Areas (Comma separated)</label>
                          <input 
                            type="text" 
                            value={editForm.focus?.join(', ') || ''}
                            onChange={(e) => setEditForm({ ...editForm, focus: e.target.value.split(',').map(s => s.trim()).filter(s => s !== '') })}
                            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                            placeholder="e.g. Strategic Planning, Innovation"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-2 block">Detailed Bio / Description</label>
                        <textarea 
                          value={editForm.description || ''}
                          onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                          rows={10}
                          className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 resize-none"
                        />
                      </div>
                      <div className="flex gap-4 pt-4">
                        <button 
                          onClick={handleSave}
                          className="flex-1 py-4 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-500 transition-all shadow-lg shadow-emerald-900/20"
                        >
                          Save Changes
                        </button>
                        <button 
                          onClick={() => setIsEditing(false)}
                          className="flex-1 py-4 bg-slate-100 text-slate-600 font-bold rounded-xl hover:bg-slate-200 transition-all"
                        >
                          Cancel
                        </button>
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-12">
                      <div>
                        <p className="text-emerald-600 font-bold uppercase tracking-wider text-xs mb-6 leading-relaxed">
                          {selectedMember.role}
                        </p>
                        <div className="text-slate-600 leading-relaxed text-lg font-light whitespace-pre-wrap">
                          {selectedMember.description}
                        </div>
                      </div>

                      {selectedMember.focus && selectedMember.focus.length > 0 && (
                        <div className="bg-slate-50 p-8 md:p-10 rounded-[2rem] border border-slate-100">
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-[0.2em] mb-8">Core Focus Areas</p>
                          <ul className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-4">
                            {selectedMember.focus.map((f, i) => (
                              <li key={i} className="flex items-start gap-3 text-slate-700 font-medium">
                                <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 mt-2 shrink-0" />
                                <span className="text-sm">{f}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      <div className="pt-8 border-t border-slate-100">
                        <button 
                          onClick={() => setSelectedMember(null)}
                          className="w-full py-4 bg-slate-900 text-white font-bold rounded-2xl hover:bg-emerald-600 transition-all"
                        >
                          Close Details
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
