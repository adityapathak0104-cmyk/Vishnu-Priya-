import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import nodemailer from "nodemailer";
import dotenv from "dotenv";
import { google } from "googleapis";
import multer from "multer";
import fs from "fs";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Configure Multer for temporary file storage
const uploadDir = "uploads/";
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir);
}
const upload = multer({ dest: uploadDir });

// Google API Setup
const oauth2Client = new google.auth.OAuth2(
  process.env.GOOGLE_CLIENT_ID,
  process.env.GOOGLE_CLIENT_SECRET,
  process.env.GOOGLE_REDIRECT_URI || "https://developers.google.com/oauthplayground"
);

if (process.env.GOOGLE_REFRESH_TOKEN) {
  oauth2Client.setCredentials({
    refresh_token: process.env.GOOGLE_REFRESH_TOKEN,
  });
}

const drive = google.drive({ version: "v3", auth: oauth2Client });
const sheets = google.sheets({ version: "v4", auth: oauth2Client });

async function getOrCreateFolder(name: string, parentId?: string) {
  const query = `name = '${name}' and mimeType = 'application/vnd.google-apps.folder' and trashed = false${
    parentId ? ` and '${parentId}' in parents` : ""
  }`;
  
  const response = await drive.files.list({
    q: query,
    fields: "files(id, name)",
  });

  if (response.data.files && response.data.files.length > 0) {
    return response.data.files[0].id;
  }

  const fileMetadata = {
    name: name,
    mimeType: "application/vnd.google-apps.folder",
    parents: parentId ? [parentId] : [],
  };

  const folder = await drive.files.create({
    requestBody: fileMetadata,
    fields: "id",
  });

  return folder.data.id;
}

async function getOrCreateSheet(name: string, parentId?: string) {
  const query = `name = '${name}' and mimeType = 'application/vnd.google-apps.spreadsheet' and trashed = false${
    parentId ? ` and '${parentId}' in parents` : ""
  }`;
  const response = await drive.files.list({
    q: query,
    fields: "files(id, name)",
  });

  if (response.data.files && response.data.files.length > 0) {
    return response.data.files[0].id;
  }

  // Create the spreadsheet using Drive API to specify the parent folder
  const fileMetadata = {
    name: name,
    mimeType: "application/vnd.google-apps.spreadsheet",
    parents: parentId ? [parentId] : [],
  };

  const spreadsheetFile = await drive.files.create({
    requestBody: fileMetadata,
    fields: "id",
  });

  const spreadsheetId = spreadsheetFile.data.id;

  // Add headers if new
  await sheets.spreadsheets.values.append({
    spreadsheetId: spreadsheetId!,
    range: "Sheet1!A1",
    valueInputOption: "RAW",
    requestBody: {
      values: [
        [
          "Name Organization / Individual",
          "Category of Consumer (HT/LT)",
          "Gmail ID",
          "Location (Only City)",
          "Invoice month",
          "Net Payable Amount",
          "File Link",
          "Date Logged"
        ],
      ],
    },
  });

  return spreadsheetId;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API routes FIRST
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.post("/api/upload-bill", upload.single("bill"), async (req, res) => {
    try {
      const { email, location, clientName, auditData: rawAuditData } = req.body;
      const file = req.file;

      if (!file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      const auditData = rawAuditData ? JSON.parse(rawAuditData) : null;

      const parentFolderId = process.env.GOOGLE_ENERGY_BILL_FOLDER_ID || "1gniSSv_o9L0-PtAJwVRJf1RzsHUQwOg7";

      // 1. Get or create "Electricity Bill" folder
      const mainFolderId = await getOrCreateFolder("Electricity Bill", parentFolderId);

      // 3. Upload file to Drive directly into "Electricity Bill"
      const fileMetadata = {
        name: file.originalname,
        parents: [mainFolderId!],
      };
      const media = {
        mimeType: file.mimetype,
        body: fs.createReadStream(file.path),
      };

      const driveFile = await drive.files.create({
        requestBody: fileMetadata,
        media: media,
        fields: "id, webViewLink",
      });

      // 4. Log to Google Sheet
      const sheetId = process.env.GOOGLE_LOG_SHEET_ID || "1M297IPcgW0P5U3PGjcsAMp82MrMsk_xNP6R60LFaIJ4";
      
      const row = [
        clientName || auditData?.utility_info?.provider || "N/A",
        auditData?.utility_info?.voltage_level || "N/A",
        email || "Anonymous",
        location || auditData?.utility_info?.state || "N/A",
        auditData?.utility_info?.billing_period || "N/A",
        auditData?.financial_analysis?.total_amount || 0,
        driveFile.data.webViewLink,
        new Date().toISOString(),
      ];

      try {
        await sheets.spreadsheets.values.append({
          spreadsheetId: sheetId!,
          range: "Sheet1!A1",
          valueInputOption: "RAW",
          requestBody: {
            values: [row],
          },
        });
      } catch (sheetError: any) {
        console.error("Error appending to sheet:", sheetError);
        // If Sheet1 doesn't exist, try appending without range
        await sheets.spreadsheets.values.append({
          spreadsheetId: sheetId!,
          range: "A1",
          valueInputOption: "RAW",
          requestBody: {
            values: [row],
          },
        });
      }

      // Clean up temp file
      fs.unlinkSync(file.path);

      res.json({
        success: true,
        fileId: driveFile.data.id,
        link: driveFile.data.webViewLink,
      });
    } catch (error: any) {
      console.error("Error in upload-bill:", error);
      res.status(500).json({ error: error.message || "Failed to upload bill" });
    }
  });

  app.post("/api/contact", async (req, res) => {
    const { name, email, phone, service, message } = req.body;

    if (!name || !email || !message) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    const recipient = process.env.CONTACT_RECIPIENT || "adityapathak0104@gmail.com";

    // Create transporter
    // Note: If SMTP variables are not set, we'll log the data instead of sending
    const hasSmtp = process.env.SMTP_HOST && process.env.SMTP_USER && process.env.SMTP_PASS;

    if (!hasSmtp) {
      console.log("SMTP not configured. Form submission received:");
      console.log({ name, email, phone, service, message });
      return res.json({ success: true, message: "Form received (logged to console as SMTP is not configured)" });
    }

    try {
      const transporter = nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: parseInt(process.env.SMTP_PORT || "587"),
        secure: process.env.SMTP_PORT === "465",
        auth: {
          user: process.env.SMTP_USER,
          pass: process.env.SMTP_PASS,
        },
      });

      const mailOptions = {
        from: process.env.SMTP_USER,
        to: recipient,
        subject: `New Contact Form Submission from ${name}`,
        text: `
          Name: ${name}
          Email: ${email}
          Phone: ${phone || "N/A"}
          Service Interested In: ${service || "N/A"}
          
          Message:
          ${message}
        `,
        html: `
          <h3>New Contact Form Submission</h3>
          <p><strong>Name:</strong> ${name}</p>
          <p><strong>Email:</strong> ${email}</p>
          <p><strong>Phone:</strong> ${phone || "N/A"}</p>
          <p><strong>Service Interested In:</strong> ${service || "N/A"}</p>
          <p><strong>Message:</strong></p>
          <p>${message.replace(/\n/g, "<br>")}</p>
        `,
      };

      await transporter.sendMail(mailOptions);
      res.json({ success: true });
    } catch (error) {
      console.error("Error sending email:", error);
      res.status(500).json({ error: "Failed to send email" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
